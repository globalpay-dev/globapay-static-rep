package com.example.tokenpaydemo.model;

import lombok.Data;

@Data
public class User {

    private String merchant_id;
    private String sub_merchant_id;
    private String merchant_user_no;
}
