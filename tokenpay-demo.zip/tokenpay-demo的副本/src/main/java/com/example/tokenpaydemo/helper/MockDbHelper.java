package com.example.tokenpaydemo.helper;

import com.example.tokenpaydemo.model.CardToken;

import java.util.ArrayList;
import java.util.List;

public class MockDbHelper {

    private static final List<CardToken> cardTokenList = new ArrayList<>();


    // 本地存储的绑定卡记录
    static {
        cardTokenList.add(new CardToken("420000******0000","PAYMENT_TOKEN2024110103154059","PAYMENT_TOKEN"));
        cardTokenList.add(new CardToken("353011******0000","LIANLIAN_TOKEN2024110403160087","LIANLIAN_TOKEN"));
        cardTokenList.add(new CardToken("493873******0001","PAYMENT_TOKEN2024110403161248","PAYMENT_TOKEN"));
    }


    public static List<CardToken> queryCardTokenList(String userNo)
    {
        return cardTokenList;
    }
}
