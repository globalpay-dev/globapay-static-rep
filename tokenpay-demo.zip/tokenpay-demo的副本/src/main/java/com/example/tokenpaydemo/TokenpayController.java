package com.example.tokenpaydemo;

import com.example.tokenpaydemo.client.LianlianApiClient;
import com.example.tokenpaydemo.helper.MockDbHelper;
import com.example.tokenpaydemo.model.CardToken;
import com.lianpay.globalpay.domain.request.PaymentsRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Slf4j
@Controller
public class TokenpayController {

    @Autowired
    private LianlianApiClient lianlianApiClient;






    // 跳转到商户收银台
    @GetMapping("get_token_page")
    public String index(Model model) {
        // 模拟客户号为123456的操作，iframe模式下，携带iframe凭证到客户端
        model.addAttribute("iframe_token", getToken("123456"));
        return "get_token_page";
    }

    // 跳转到商户绑卡页面
    @GetMapping("bindCardPage")
    public String bindCard(Model model) {
        // 模拟客户号为123456的操作，iframe模式下，携带iframe凭证到客户端
        model.addAttribute("iframe_token", getToken("123456"));
        return "bind_card_page";
    }


    /**
     * 跳转到cardTokenList列表
     * @param model
     * @return
     */
    @GetMapping("cardTokenList")
    public String cardTokenList(Model model) {
        // 模拟客户号为123456的操作，iframe模式下，携带iframe凭证到客户端
        model.addAttribute("creditCards", MockDbHelper.queryCardTokenList("123456"));
        return "card_token_list";
    }


    // 跳转到payment_token收银台页面
    @GetMapping("payment_token_pay_checkout_page")
    public String payment_token_pay_checkout_page(Model model) {
        // 模拟客户号为123456的操作，iframe模式下，携带iframe凭证到客户端
        model.addAttribute("iframe_token", getToken("123456"));
        return "payment_token_pay_checkout_page";
    }


    // 跳转到lianlian_token收银台页面
    @GetMapping("lianlian_token_pay_checkout_page")
    public String lianlian_token_pay_checkout_page(Model model) {
        // 模拟客户号为123456的操作，iframe模式下，携带iframe凭证到客户端
        model.addAttribute("iframe_token", getToken("123456"));
        return "lianlian_token_pay_checkout_page";
    }


    /**
     * 解除信用卡绑定
     * @param
     * @return
     */
    @PostMapping("/unbindCard")
    public Object unbindCard(@RequestBody CardToken cardToken) {
        return lianlianApiClient.unbindCard(cardToken);
    }



    @GetMapping("/showPage")
    public String showPage(Model model) {
        // 你可以在这里添加模型属性
        model.addAttribute("message", "Hello from Spring Boot!");

        // 返回视图名称
        return "home"; // 这将渲染src/main/resources/templates/home.html
    }

    @GetMapping("/success")
    public String success(Model model) {
        return "success";
    }

    // 获取iframe凭证
    @GetMapping("getToken/{userNo}")
    public Object getToken(@PathVariable String userNo){
        return lianlianApiClient.getCardToken(userNo);
    }

    /**
     * @param paymentsRequest
     * @return
     */
    @PostMapping("/pay")
    public ResponseEntity<?> pay(@RequestBody PaymentsRequest paymentsRequest){
        return lianlianApiClient.pay(paymentsRequest);
    }
}
