package com.example.tokenpaydemo;

import com.lianpay.globalpay.domain.ImmutablePair;
import com.lianpay.globalpay.utils.SignUtil;

public class RsaPairKeyTest {
    public static void main(String[] args) throws Exception {
        ImmutablePair<String, String> rsaKeyPair = SignUtil.initRsaKey();
        System.out.println("获取Rsa公钥：" + rsaKeyPair.getLeft());
        System.out.println("获取Rsa私钥：" + rsaKeyPair.getRight());
    }
}
