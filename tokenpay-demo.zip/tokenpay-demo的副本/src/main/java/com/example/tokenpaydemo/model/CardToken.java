package com.example.tokenpaydemo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CardToken {

    private String cardNo;

    private String lianlianCardTokenId;

    private String cardTokenType;
}
