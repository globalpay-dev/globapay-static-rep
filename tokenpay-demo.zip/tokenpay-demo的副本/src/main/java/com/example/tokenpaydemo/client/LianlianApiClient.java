package com.example.tokenpaydemo.client;


import com.example.tokenpaydemo.model.CardToken;
import com.lianpay.globalpay.IFrameCardTokenService;
import com.lianpay.globalpay.MerchantUnbindTokenService;
import com.lianpay.globalpay.PaymentsService;
import com.lianpay.globalpay.domain.ApiResult;
import com.lianpay.globalpay.domain.request.CardTokenRequest;
import com.lianpay.globalpay.domain.request.PaymentsRequest;
import com.lianpay.globalpay.domain.response.PaymentsResponse;
import com.lianpay.globalpay.exception.HttpClientException;
import com.lianpay.globalpay.exception.ParamCheckFailException;
import com.lianpay.globalpay.exception.SignException;
import com.lianpay.globalpay.exception.VerifySignFailException;
import com.lianpay.globalpay.reader.MerchantPropertyReader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class LianlianApiClient {

    private final MerchantPropertyReader merchant = new MerchantPropertyReader("/globalpay-merchant.properties");
    private final IFrameCardTokenService iFrameCardTokenService = new IFrameCardTokenService();

    private MerchantUnbindTokenService merchantUnbindTokenService = new MerchantUnbindTokenService();

    private final PaymentsService payService = new PaymentsService();



    public ApiResult<?> unbindCard(CardToken cardToken){
        // 模拟客户号为123456的操作
        CardTokenRequest cardTokenRequest = new CardTokenRequest();
        cardTokenRequest.setMerchantUserNo("123456");
        cardTokenRequest.setLianlianCardTokenId(cardToken.getLianlianCardTokenId());
        ApiResult<?> iFrameTokenRes = null;
        try {
            iFrameTokenRes = merchantUnbindTokenService.sendUnbindCardTokenRequest(cardTokenRequest, merchant);
            log.info(iFrameTokenRes.toString());
        } catch (ParamCheckFailException e) {
            throw new RuntimeException(e);
        } catch (SignException e) {
            throw new RuntimeException(e);
        } catch (VerifySignFailException e) {
            throw new RuntimeException(e);
        } catch (HttpClientException e) {
            throw new RuntimeException(e);
        }
        if ("OBJECT_NOT_FOUND".equals(iFrameTokenRes.getReturnCode())){
            throw new RuntimeException("userNo 和 lianlianCardTokenId未查询到有效状态绑定卡");
        }
        if ("CARD_UPDATE_FAILED".equals(iFrameTokenRes.getReturnCode())){
            throw new RuntimeException("通用解绑失败，需联系服务商核实");
        }
        return iFrameTokenRes;
    }

    public Object getCardToken(String userNo){
        CardTokenRequest cardTokenRequest = new CardTokenRequest();
        cardTokenRequest.setMerchantUserNo(userNo);
        ApiResult<?> iFrameTokenRes = null;
        try {
            iFrameTokenRes = iFrameCardTokenService.sendCardTokenRequest(cardTokenRequest,merchant);
            log.info(iFrameTokenRes.toString());
        } catch (ParamCheckFailException e) {
            // 参数检查异常处理
            throw new RuntimeException(e);
        } catch (SignException e) {
            // 签名校验异常处理
            throw new RuntimeException(e);
        } catch (VerifySignFailException e) {
            // 返回参数签名校验处理
            throw new RuntimeException(e);
        } catch (HttpClientException e) {
            // http请求异常处理
            throw new RuntimeException(e);
        }
        if ("SUCCESS".equals(iFrameTokenRes.getReturnCode())){
            return iFrameTokenRes.getOrder();
        }
        throw new RuntimeException("获取token失败");
    }

    public ResponseEntity<?> pay(PaymentsRequest paymentsRequest){
        log.info("pay request: {}",paymentsRequest);
        ApiResult<PaymentsResponse> result = null;

        try {
            result = payService.sendPaymentRequest(paymentsRequest, merchant);
            log.info("pay result:{}",result.toString());
        } catch (ParamCheckFailException e) {
            throw new RuntimeException(e);
        } catch (SignException e) {
            throw new RuntimeException(e);
        } catch (VerifySignFailException e) {
            throw new RuntimeException(e);
        } catch (HttpClientException e) {
            throw new RuntimeException(e);
        }
        return ResponseEntity.ok(result);
    }

}
