package com.example.tokenpaydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TokenpayDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(TokenpayDemoApplication.class, args);
    }

}
