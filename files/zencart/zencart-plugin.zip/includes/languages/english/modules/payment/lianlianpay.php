<?php

define('MODULE_PAYMENT_LIANLIANPAY_TEXT_CATALOG_TITLE', 'LianLianPay');
define('MODULE_PAYMENT_LIANLIANPAY_TEXT_DESCRIPTION', '<strong>LianLianPay Checkout</strong>');
define('MODULE_PAYMENT_LIANLIANPAY_TEXT_CATALOG_LOGO', 'LianLianPay Checkout');
