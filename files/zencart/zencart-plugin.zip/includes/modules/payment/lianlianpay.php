<?php
/**
 * lianlianpay.php payment module class
 *
 * @author liuxf003@lianlianpay.com
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version 1.0.0
 */

require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Account.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Api.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Cryptography.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Request.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Helper.php');


class lianlianpay extends base
{

    /**
     * string representing the payment method
     *
     * @var string
     */
    var $code;
    /**
     * $title is the displayed name for this payment method
     *
     * @var string
     */
    var $title;
    /**
     * $description is a soft name for this payment method
     *
     * @var string
     */
    var $description;
    /**
     * $enabled determines whether this module shows or not... in catalog.
     *
     * @var boolean
     */
    var $enabled;
    /**
     * $form_action_url live or sandbox action_url.
     *
     * @var string
     */
    var $form_action_url;
    /**
     * $form_action_url live or sandbox action_url.
     *
     * @var boolean
     */
    var $testMode;
    /**
     * LianLian Pay - Payment gateway instance.
     *
     * @var Api
     */
    private static $apiInstance;
    /**
     * LianLian Pay - Checkout page url.
     *
     * @var string
     */
    var $orderPayUrl;

    /**
     * $payment_id generate by LianLian Pay use function create_guid().
     *
     * @var string
     */
    var $payment_id;

    /**
     * constructor
     *
     * @return lianlianpay
     */
    function __construct()
    {

        Helper::zcLog("INFO", "lianlianpay __construct()");

        global $order;
        $this->code = 'lianlianpay';
        $this->codeVersion = '1.0.0';
        $this->sort_order = defined('MODULE_PAYMENT_LIANLIANPAY_SORT_ORDER') ? MODULE_PAYMENT_LIANLIANPAY_SORT_ORDER : null;
        $this->enabled = (defined('MODULE_PAYMENT_LIANLIANPAY_STATUS') && MODULE_PAYMENT_LIANLIANPAY_STATUS == 'True');
        $this->title = MODULE_PAYMENT_LIANLIANPAY_TEXT_CATALOG_TITLE; // Payment Module title in Catalog

        if (null === $this->sort_order) return false;

        $this->description = MODULE_PAYMENT_LIANLIANPAY_TEXT_DESCRIPTION;
        if (defined('MODULE_PAYMENT_LIANLIANPAY_ORDER_STATUS_ID') && (int)MODULE_PAYMENT_LIANLIANPAY_ORDER_STATUS_ID > 0) {
            $this->order_status = MODULE_PAYMENT_LIANLIANPAY_ORDER_STATUS_ID;
        }

        if (is_object($order)) $this->update_status();

        Helper::zcLog("INFO", MODULE_PAYMENT_LIANLIANPAY_HANDLER);
        if (MODULE_PAYMENT_LIANLIANPAY_HANDLER == 'live' || !strstr(MODULE_PAYMENT_LIANLIANPAY_HANDLER, 'sandbox')) {
            $this->testMode = false;
        } else {
            $this->testMode = true;
        }

        if (PROJECT_VERSION_MAJOR != '1' && substr(PROJECT_VERSION_MINOR, 0, 3) != '5.6') $this->enabled = false;

    }

    /**
     * calculate zone matches and flag settings to determine whether this module should display to customers or not
     *
     */
    function update_status()
    {
        Helper::zcLog("INFO", "lianlianpay update_status()");
        global $order, $db;

        if ($this->enabled && (int)MODULE_PAYMENT_LIANLIANPAY_ZONE > 0 && isset($order->billing['country']['id'])) {
            $check_flag = false;
            $check_query = $db->Execute("SELECT zone_id FROM " . TABLE_ZONES_TO_GEO_ZONES . " WHERE geo_zone_id = '" . MODULE_PAYMENT_LIANLIANPAY_ZONE . "' AND zone_country_id = '" . (int)$order->billing['country']['id'] . "' ORDER BY zone_id");
            while (!$check_query->EOF) {
                if ($check_query->fields['zone_id'] < 1) {
                    $check_flag = true;
                    break;
                } elseif ($check_query->fields['zone_id'] == $order->billing['zone_id']) {
                    $check_flag = true;
                    break;
                }
                $check_query->MoveNext();
            }

            if ($check_flag == false) {
                $this->enabled = false;
            }
        }
    }

    /**
     * JS validation which does error-checking of data-entry if this module is selected for use
     * (Number, Owner, and CVV Lengths)
     *
     * @return string
     */
    function javascript_validation()
    {
        Helper::zcLog("INFO", "lianlianpay javascript_validation()");
        //重置订单号，仅在checkout_payment调用
        unset($_SESSION['order_number_created']);
        return false;
    }

    /**
     * Displays payment method name along with Credit Card Information Submission Fields (if any) on the Checkout Payment Page
     *
     * @return array
     */
    function selection()
    {
        Helper::zcLog("INFO", "lianlianpay selection()");
        //重置订单号，仅在checkout_payment调用
        unset($_SESSION['order_number_created']);
        return array('id' => $this->code,
            'module' => MODULE_PAYMENT_LIANLIANPAY_TEXT_CATALOG_LOGO
        );
    }

    /**
     * Normally evaluates the Credit Card Type for acceptance and the validity of the Credit Card Number & Expiration Date
     * Since lianlianpay module is not collecting info, it simply skips this step.
     *
     * @return boolean
     */
    function pre_confirmation_check()
    {
        Helper::zcLog("INFO", "lianlianpay pre_confirmation_check()");
        return false;
    }

    /**
     * Display Credit Card Information on the Checkout Confirmation Page
     * Since none is collected for lianlianpay before forwarding to lianlianpay site, this is skipped
     *
     * @return array
     */
    function confirmation()
    {
        global $order;
        Helper::zcLog("INFO", "lianlianpay confirmation()");

        $confirmation = array('title' => '', 'fields' => array());

        try {
            //连连申请创单前 应该先保存订单信息，刷新页面不会重复保存
            //在checkout_payment页面会重置
            Helper::zcLog("INFO", $_SESSION['order_number_created']);
            if (!isset($_SESSION['order_number_created'])) {
                global $zco_notifier, $payment_modules;
                $order->info['payment_method'] = 'LianLianPay';
                $order->info['payment_module_code'] = 'lianlianpay';
                $insert_id = $order->create($this->processTotal(), 2);
                $zco_notifier->notify('NOTIFY_CHECKOUT_PROCESS_AFTER_ORDER_CREATE', $insert_id);
                $payment_modules->after_order_create($insert_id);
                $zco_notifier->notify('NOTIFY_CHECKOUT_PROCESS_AFTER_PAYMENT_MODULES_AFTER_ORDER_CREATE', $insert_id);
                // store the product info to the order
                $order->create_add_products($insert_id);
                //保存防止重复保存
                $_SESSION['order_number_created'] = $insert_id;
                $zco_notifier->notify('NOTIFY_CHECKOUT_PROCESS_AFTER_ORDER_CREATE_ADD_PRODUCTS', $insert_id, $order);
                //send email notifications
                $order->send_order_email($insert_id, 2);
                $zco_notifier->notify('NOTIFY_CHECKOUT_PROCESS_AFTER_SEND_ORDER_EMAIL', $insert_id, $order);
            }


            $this->orderPayUrl = $this->getOrderPayUrl($order);
            Helper::zcLog("INFO", $this->orderPayUrl);
            $this->form_action_url = $this->orderPayUrl == null ? '' : $this->orderPayUrl;
            //如果支付回调链接为空则直接跳转到商户收银台页面
            if (empty($this->orderPayUrl)) {
                zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL'));
            }

            $confirmation['title'] .=
                '<script type="text/javascript">
                    $(document).ready(function() {
                        $("#checkout_confirmation").submit(function(e) {
                            e.preventDefault();
                            window.location.href="' . $this->orderPayUrl . '";
                        });
                    });
                </script>';

            $confirmation['title'] .= '<div class="back" style="background-color: #E5F2FF; margin:10px 0px;">';
        } catch (\Exception $e) {
            zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL'));
        }

        $confirmation['title'] .= '</div>';

        return $confirmation;
    }

    /**
     * 生成金额统计信息（由于使用官方的会导致显示信息重复，所以复制过来进行计算）
     * @return array
     */
    function processTotal()
    {
        global $order, $order_total_modules;
        $order_total_array = array();
        $GLOBALS2 = array();
        if (is_array($order_total_modules->modules)) {
            foreach ($order_total_modules->modules as $value) {
                $class = substr($value, 0, strrpos($value, '.'));
                if (!isset($GLOBALS[$class])) continue;
                $GLOBALS2[$class] = unserialize(serialize($GLOBALS[$class]));//深拷贝
                $GLOBALS2[$class]->process();
                for ($i = 0, $n = sizeof($GLOBALS2[$class]->output); $i < $n; $i++) {
                    if (zen_not_null($GLOBALS2[$class]->output[$i]['title']) && zen_not_null($GLOBALS2[$class]->output[$i]['text'])) {
                        $order_total_array[] = array('code' => $GLOBALS2[$class]->code,
                            'title' => $GLOBALS2[$class]->output[$i]['title'],
                            'text' => $GLOBALS2[$class]->output[$i]['text'],
                            'value' => $GLOBALS2[$class]->output[$i]['value'],
                            'sort_order' => $GLOBALS2[$class]->sort_order);
                    }
                }
            }
        }

        return $order_total_array;
    }

    /**
     * Build the data and actions to process when the "Submit" button is pressed on the order-confirmation screen.
     * This sends the data to the payment gateway for processing.
     * (These are hidden fields on the checkout confirmation page)
     *
     * @return string
     */
    function process_button()
    {
        Helper::zcLog("INFO", "lianlianpay process_button()");
        global $order;
        $buttonArray = array();

        $options = array(
            'payment_url' => $this->orderPayUrl,
        );

        // build the button fields
        foreach ($options as $name => $value) {
            $buttonArray[] = zen_draw_hidden_field($name, $value);
        }
        $process_button_string = "\n" . implode("\n", $buttonArray) . "\n";
        Helper::zcLog("INFO", $process_button_string);

        return $process_button_string;
    }

    /**
     * Store transaction info to the order and process any results that come back from the payment gateway
     */
    function before_process()
    {
        Helper::zcLog("INFO", "lianlianpay before_process()");

        Helper::zcLog("INFO", json_encode($_GET));

        global $messageStack, $_GET;

        $response = array();
        $response['merchant_id'] = $_GET['merchant_id'];
        $response['merchant_transaction_id'] = $_GET['merchant_transaction_id'];
        $response['order_amount'] = $_GET['order_amount'];
        $response['order_currency_code'] = $_GET['order_currency_code'];
        $response['payment_amount'] = $_GET['payment_amount'];
        $response['payment_currency_code'] = $_GET['payment_currency_code'];
        $response['payment_status'] = $_GET['payment_status'];
        $response['sign_type'] = $_GET['sign_type'];

        Helper::zcLog("INFO", json_encode($response));

        // 验签
        $sign_tools = new LianLianSign();
        Helper::zcLog("INFO", $_GET["signature"]);
        Helper::zcLog("INFO", MODULE_PAYMENT_LIANLIANPAY_PUBLIC_KEY);
        $check = $sign_tools->lianlianVerifySign($response, $_GET["signature"], MODULE_PAYMENT_LIANLIANPAY_PUBLIC_KEY);

        // 用于写入Zen Cart后台订单历史记录中的数据
        $this->payment_id = $_GET["merchant_transaction_id"];

        // 判断是否支付成功
        if ($check && $_GET['payment_status'] == 'PS') {
            return true;
        } else {
            $messageStack->add_session('checkout_payment', 'verify sign failed', 'error');
            zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL', true, false));
        }
        return false;
    }

    /**
     * Checks referrer
     *
     * @param string $zf_domain
     * @return boolean
     */
    function check_referrer($zf_domain)
    {
        Helper::zcLog("INFO", "lianlianpay check_referrer()");
        return true;
    }

    /**
     * Post-processing activities
     * When the order returns from the processor, if PDT was successful, this stores the results in order-status-history and logs data for subsequent reference
     *
     * @return boolean
     */
    function after_process()
    {
        Helper::zcLog("INFO", "lianlianpay after_process()");

        return true;
    }

    /**
     * Check to see whether module is installed
     *
     * @return boolean
     */
    function check()
    {
        Helper::zcLog("INFO", "lianlianpay check()");
        global $db;
        if (!isset($this->_check)) {
            $check_query = $db->Execute("SELECT configuration_value FROM " . TABLE_CONFIGURATION . " WHERE configuration_key = 'MODULE_PAYMENT_LIANLIANPAY_STATUS'");
            $this->_check = $check_query->RecordCount();
        }
        if (defined('MODULE_PAYMENT_LIANLIANPAY_HANDLER') && !in_array(MODULE_PAYMENT_LIANLIANPAY_HANDLER, array('live', 'sandbox'))) {
            $val = (stristr(MODULE_PAYMENT_LIANLIANPAY_HANDLER, 'sand')) ? 'sandbox' : 'live';
            $sql = "UPDATE " . TABLE_CONFIGURATION . " SET configuration_title = 'Live or Sandbox', configuration_value = '" . $val . "', configuration_description= '<strong>Live: </strong> Used to process Live transactions<br><strong>Sandbox: </strong>For developers and testing', set_function='zen_cfg_select_option(array(\'live\', \'sandbox\'), ' WHERE configuration_key = 'MODULE_PAYMENT_LIANLIANPAY_HANDLER'";
            $db->Execute($sql);
        }
        return $this->_check;
    }

    /**
     * Install the payment module and its configuration settings
     *
     */
    function install()
    {
        Helper::zcLog("INFO", "lianlianpay install()");
        global $db, $messageStack;
        if (defined('MODULE_PAYMENT_LIANLIANPAY_STATUS')) {
            $messageStack->add_session('LianLianPay module already installed.', 'error');
            zen_redirect(zen_href_link(FILENAME_MODULES, 'set=payment&module=lianlianpay', 'NONSSL'));
            return 'failed';
        }

        // Lianlian config params
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) VALUES ('Enable LianLianPay Module', 'MODULE_PAYMENT_LIANLIANPAY_STATUS', 'True', 'Do you want to accept LianLianPay payments?', '6', '0', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) VALUES ('Set Order Status', 'MODULE_PAYMENT_LIANLIANPAY_ORDER_STATUS_ID', '2', 'Set the status of orders made with this payment module that have completed payment to this value<br />(\'Processing\' recommended)', '6', '6', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Sort order of display.', 'MODULE_PAYMENT_LIANLIANPAY_SORT_ORDER', '0', 'Sort order of display. Lowest is displayed first.', '6', '8', now())");
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) VALUES ('Live or Sandbox', 'MODULE_PAYMENT_LIANLIANPAY_HANDLER', 'live', '<strong>Live: </strong> Used to process Live transactions<br><strong>Sandbox: </strong>For developers and testing', '6', '73', 'zen_cfg_select_option(array(\'live\', \'sandbox\'), ', now())");
        // 商户ID
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('LianLianPay Account', 'MODULE_PAYMENT_LIANLIANPAY_ACCOUNT', '', 'Account which can obtainable from LianLianPay.', '6', '80', now())");
        // 连连公钥
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('LianLianPay Public Key', 'MODULE_PAYMENT_LIANLIANPAY_PUBLIC_KEY', '', 'Public key which can obtainable from LianLianPay.', '6', '82', now())");
        // 商户MCC
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('MCC', 'MODULE_PAYMENT_LIANLIANPAY_MERCHANT_MCC', '', 'MCC code.', '6', '84', now())");
        // 商户私钥
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Private Key', 'MODULE_PAYMENT_LIANLIANPAY_MERCHANT_PRIVATE_KEY', '', 'Private key which can generate by merchant or ask LianLianPay for one.', '6', '86', now())");

        $this->notify('NOTIFY_PAYMENT_LIANLIANPAY_INSTALLED');
    }

    /**
     * Remove the module and all its settings
     *
     */
    function remove()
    {
        Helper::zcLog("INFO", "lianlianpay remove()");
        global $db;
        $db->Execute("DELETE FROM " . TABLE_CONFIGURATION . " WHERE configuration_key LIKE 'MODULE\_PAYMENT\_LIANLIANPAY\_%'");
        $this->notify('NOTIFY_PAYMENT_LIANLIANPAY_UNINSTALLED');
    }

    /**
     * Internal list of configuration keys used for configuration of the module
     *
     * @return array
     */
    function keys()
    {
        Helper::zcLog("INFO", "lianlianpay keys()");
        $keys_list = array(
            'MODULE_PAYMENT_LIANLIANPAY_STATUS',
            'MODULE_PAYMENT_LIANLIANPAY_ORDER_STATUS_ID',
            'MODULE_PAYMENT_LIANLIANPAY_SORT_ORDER',
            'MODULE_PAYMENT_LIANLIANPAY_HANDLER',
            'MODULE_PAYMENT_LIANLIANPAY_ACCOUNT',
            'MODULE_PAYMENT_LIANLIANPAY_PUBLIC_KEY',
            'MODULE_PAYMENT_LIANLIANPAY_MERCHANT_MCC',
            'MODULE_PAYMENT_LIANLIANPAY_MERCHANT_PRIVATE_KEY',
        );

        return $keys_list;
    }

    public function getApiInstance()
    {
        Helper::zcLog("INFO", "lianlianpay getApiInstance()");
        if (self::$apiInstance === null) {
            $account = MODULE_PAYMENT_LIANLIANPAY_ACCOUNT;
            $token = MODULE_PAYMENT_LIANLIANPAY_MERCHANT_PRIVATE_KEY;
            $mccCode = MODULE_PAYMENT_LIANLIANPAY_MERCHANT_MCC;
            $testMode = $this->testMode;
            self::$apiInstance = new Api(new Account($account, $token, $testMode, $mccCode), new Request(new Cryptography($token)));
        }
        return self::$apiInstance;
    }

    /**
     *  获取订单支付URL
     * @param order $order
     * @return null|string
     */
    public function getOrderPayUrl(order $order)
    {
        Helper::zcLog("INFO", "lianlianpay getOrderPayUrl()");
        global $db, $currencies, $currency;

        $my_currency = $_SESSION['currency'];

        Helper::zcLog("INFO", "currency: " . $my_currency);
        $this->transaction_currency = $my_currency;

        $this->totalsum = $order->info['total'] = zen_round($order->info['total'], 2);
        $this->transaction_amount = zen_round($this->totalsum * $currencies->get_value($my_currency), $currencies->get_decimal_places($my_currency));
        Helper::zcLog("INFO", "amount: " . $this->transaction_amount);

        $orderTotalAmount = $this->transaction_amount;
        $notifyUrl = zen_href_link('lianlianpay_handler.php', '', 'SSL', false, false, true);
        $redirectUrl = zen_href_link(FILENAME_CHECKOUT_SUCCESS, '', 'SSL');
        Helper::zcLog("INFO", "redirectUrl: " . $redirectUrl);
        $basePathUrl = zen_href_link(FILENAME_PRODUCT_INFO, '', 'SSL');

        try {
            $pay_url = $this->getApiInstance()->payment(
                $_SESSION['order_number_created'],
                $order,
                null,
                $orderTotalAmount,
                $my_currency,
                $redirectUrl,
                $notifyUrl,
                $basePathUrl,
                0);
        } catch (\Exception $e) {
            $error_hint_url = Api::paymentFailUrl($this->testMode) . \urlencode($e->getMessage());
//            $error_hint_url = 'https://gpcashier.lianlianpay.com/gw/payment/failed?message='.\urlencode($e->getMessage());
            return $error_hint_url;
        }

        return $pay_url;
    }

}

// for backward compatibility prior to v1.5.7;
if (!function_exists('zen_update_orders_history')) {
    function zen_update_orders_history($orders_id, $message = '', $updated_by = null, $orders_new_status = -1, $notify_customer = -1)
    {
        $data = array(
            'orders_id' => (int)$orders_id,
            'orders_status_id' => (int)$orders_new_status,
            'customer_notified' => (int)$notify_customer,
            'comments' => zen_db_input($message),
        );
        zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $data);
    }
}
