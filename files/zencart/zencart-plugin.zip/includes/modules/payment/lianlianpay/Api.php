<?php

require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Account.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Api.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Cryptography.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Currency.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Helper.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/LianLianSign.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Notify.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/OrderHelper.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/PaymentParams.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Request.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/RequestErrorException.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Response.php');

class Api
{
    const TEST_DOMAIN = 'https://celer-api.lianLianpay-inc.com/';
    const ONLINE_DOMAIN = 'https://gpapi.lianLianpay.com/';

    const REDIRECT = "redirect";

    const NOTIFY = "notify";
    /**
     * @var Account
     */
    private $account;
    /**
     * @var Request
     */
    private $request;

    public function __construct(Account $account, Request $request)
    {
        $this->account = $account;
        $this->request = $request;
    }

    /**
     * 支付请求接口
     * @param order $order
     * @param $pay_method
     * @param $amount
     * @param $currency
     * @param $redirect_url
     * @param $notify_url
     * @param $base_path_url
     * @param int $timeout
     * @return mixed|null
     * @throws \Exception
     */
    public function payment($order_id,$order, $pay_method, $amount, $currency, $redirect_url, $notify_url, $base_path_url, $timeout = 0)
    {
        //TODO 组装支付请求报文
        $request = $this->buildPayRequest($order_id,$currency, $this->account->getMcc(), $order, $amount, $redirect_url, $notify_url, $base_path_url);
        Helper::zcLog('INFO', '========支付请求报文==========' . json_encode($request));
        //支付请求
        $response_data = $this->request->sendCurl(self::paymentsUrl($this->account->getUser()), $request, $this->account);
        Helper::zcLog('INFO', '===支付响应报文====' . json_encode($response_data));
        //TODO 处理支付结果
        $payinfo = $this->processRes($response_data);

        if (isset($payinfo['url']) && !empty($payinfo['url'])) {
            return $payinfo['url'];
        }
        return null;
    }

    /**
     * 组装支付报文
     * @param order $order
     * @param $amount
     * @param $redirect_url
     * @param $notify_url
     * @return array
     */
    public function buildPayRequest($order_id,$currency, $mcc, $order, $amount, $redirect_url, $notify_url, $base_path_url)
    {
//        Helper::zcLog("INFO", json_encode($order));

        $now = time();
        $timestamp = date('YmdHis', $now);

//        $order_id = $this->create_guid();

        $street = $order->delivery['street_address'];
        $house_number = $order->delivery['suburb'];
        if (empty($house_number)) {
            $house_number = "-";
        }
        $district = "-";
        $address = array(
            "street_name" => $street,
            "house_number" => $house_number,
            "district" => $district,
            "city" => $order->delivery['city'],
            "state" => $order->delivery['state'],
            "country" => $order->delivery['country']['iso_code_2'],
            "postal_code" => $order->delivery['postcode']
        );
        $billing_street = $order->billing['street_address'];
        $billing_house_number = $order->billing['suburb'];
        if (empty($billing_street)) {
            $billing_house_number = "-";
        }
        $billing_district = "-";
        $billing_address = array(
            "street_name" => $billing_street,
            "house_number" => $billing_house_number,
            "district" => $billing_district,
            "city" => $order->billing['city'],
            "state" => $order->billing['state'],
            "country" => $order->billing['country']['iso_code_2'],
            "postal_code" => $order->billing['postcode']
        );
        $card = array(
            "billing_address" => $billing_address
        );

        $customer = array(
            "customer_type" => PaymentParams::PAY_CUSTOMER_TYPE,
            "email" => $order->customer['email_address'],
            "full_name" => $order->customer['firstname'] . ' ' . $order->customer['lastname'],
            "first_name" => $order->customer['firstname'],
            "last_name" => $order->customer['lastname'],
            "address" => $billing_address
        );

        $payment_data = array(
            "payment_currency_code" => $currency,
            "payment_amount" => $amount,
            "card" => $card
        );

        $shipping = array(
            "name" => $order->delivery['firstname'] . ' ' . $order->delivery['lastname'],
            "phone" => $order->customer['telephone'],
            "address" => $address,
            "cycle" => PaymentParams::PAY_SHIPPING_CYCLE
        );

        $merchant_order = array(
            "mcc" => $mcc,
            "merchant_order_id" => $order_id,
            "merchant_order_time" => $timestamp,
            "order_amount" => $amount,
            "order_currency_code" => $currency,
            "products" => $this->getOrderProduct($order, $base_path_url),
            "shipping" => $shipping
        );

        $pay_request = array(
            'merchant_transaction_id' => $order_id,
            'merchant_id' => $this->account->getUser(),
            'biz_code' => PaymentParams::PAY_BIZ_CODE,
            'notification_url' => $notify_url,
            'redirect_url' => $redirect_url,
            'country' => PaymentParams::PAY_COUNTRY,
            'merchant_order' => $merchant_order,
            'customer' => $customer,
            'payment_data' => $payment_data
        );
        return $pay_request;
    }

    /**
     * 获取订单产品信息
     * @param order $order
     * @return array
     */
    protected function getOrderProduct($order, $base_path_url)
    {
        $productList = array();
//        Helper::zcLog('INFO', json_encode($order->products));
        foreach ($order->products as $product) {
            $tmp = array();
            if (isset($product['name']) && !empty($product['name'])) {
                $tmp['name'] = $product['name'];
            } else {
                $tmp['name'] = 'unknown';
            }
            if (isset($product['id']) && !empty($product['id'])) {
                $tmp['product_id'] = $product['id'];
            }
            if (isset($product['price']) && !empty($product['price'])) {
                $tmp['price'] = number_format($product['price'], 2, ".", "");
            } else {
                $tmp['price'] = 0.00;
            }
            if (isset($product['qty']) && !empty($product['qty'])) {
                $tmp['quantity'] = floor($product['qty']);
            } else {
                $tmp['quantity'] = 0;
            }
            $tmp['sku'] = '-';
            $tmp['shipping_provider'] = '-';
            $tmp['category'] = '-';
            //TODO 需要获取真正的Category
//            if (isset($product['product_type']) && !empty($product['product_type'])) {
//                $tmp['category'] = $product['product_type'];
//            }
//            if (isset($product['sku']) && !empty($product['sku'])) {
//                $tmp['sku'] = $product['sku'];
//            }
//            $tmp['shipping_provider'] = $order->info['shipping_method'];
            $tmp['url'] = $this->getProductUrl($base_path_url, $tmp['product_id']);
            $productList[] = $tmp;
        }
        return $productList;
    }


    /**
     * @param $res
     * @return array
     * @throws \Exception
     */
    public function processRes(&$res)
    {
        $code = $res['return_code'];
        $json = array(
            'suc' => $code == 'SUCCESS'
        );
        if ($code == 'SUCCESS') {
            $json['url'] = $res['order']['payment_url'];
            return $json;
        }
        throw new \Exception(json_encode($res));
    }


    public function cancel($trade_id)
    {
        return $this->request->post(self::cancelUrl(), array(
            'user' => $this->account->getUser(),
            'trade_id' => $trade_id
        ));
    }

    public function shipment($orderId, $carrier, $number)
    {
        $request = array(
            'merchant_order' => $orderId,
            'carrie' => $carrier,
            'number' => $number
        );
        Helper::zcLog('INFO', '========物流上传请求报文==========' . json_encode($request, true));
        $response_data = $this->request->sendCurl(self::shipmentUrl(), $request, $this->account);
        Helper::zcLog('INFO', '===物流上传响应报文====' . json_encode($response_data));


    }

    public function orderQuery($trade_id)
    {
        return $this->request->post(self::orderQueryUrl(), array(
            'user' => $this->account->getUser(),
            'trade_id' => $trade_id
        ));
    }

    public function refund($trade_id, $description)
    {
        return $this->request->post(self::orderQueryUrl(), array(
            'user' => $this->account->getUser(),
            'trade_id' => $trade_id,
            'description' => $description
        ));
    }

    public function verify()
    {
        $verify = $this->request->post(self::verifyUrl(), array(
            'user' => $this->account->getUser()
        ));
        if (isset($verify['info']) && empty($verify['info'])) {
            return true;
        }
        return false;
    }

    private function generateUrl($action)
    {
        if($this->account->getTestMode() === true){
            return self::TEST_DOMAIN . $action;
        }
        return self::ONLINE_DOMAIN . $action;
    }


    protected function paymentsUrl($merchantId)
    {
        return self::generateUrl('v3/merchants/' . $merchantId . '/payments');
    }

    protected function shipmentUrl()
    {
        return self::generateUrl('shipment.php');
    }

    protected function cancelUrl()
    {
        return self::generateUrl('cancel.php');
    }

    public  function orderQueryUrl()
    {
        return self::generateUrl('orderquery.php');
    }

    protected  function refundUrl()
    {
        return self::generateUrl('refund.php');
    }

    protected  function verifyUrl()
    {
        return self::generateUrl('verify.php');
    }

    public static function paymentFailUrl($testMode)
    {
        if($testMode === true){
            return "https://celer-gateway.lianlianpay-inc.com/payment/failed?message=";
        }
        return "https://gpcashier.lianlianpay.com/gw/payment/failed?message=";
    }

    public function getProductUrl($basepath, $productId)
    {
        // http://192.168.136.16:8089/index.php?main_page=product_info&products_id=84:5e2efd079e42237233ae199a9233589d
        return $basepath . '&products_id=' . $productId;
    }

    public function create_guid($namespace = '') {
        static $guid = 'lianlianpay';
        $uid = uniqid("lianlianpay", true);
        $data = $namespace;
        $data .= $_SERVER['REQUEST_TIME'];
        $data .= $_SERVER['HTTP_USER_AGENT'];
        $data .= $_SERVER['LOCAL_ADDR'];
        $data .= $_SERVER['LOCAL_PORT'];
        $data .= $_SERVER['REMOTE_ADDR'];
        $data .= $_SERVER['REMOTE_PORT'];
        $data = $uid . $guid . $data;
        $guid = md5($data);
        return $guid;
    }

}