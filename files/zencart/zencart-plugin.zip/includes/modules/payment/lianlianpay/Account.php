<?php


class Account
{
    /**
     * @var string
     */
    private $user;
    /**
     * @var string
     */
    private $token;

    private $mcc;

    private $testMode;

    public function __construct($user, $token, $testMode,$mcc = null)
    {
        $this->user = $user;
        $this->mcc = $mcc;
        $this->token = $token;
        $this->testMode = $testMode;
    }

    /**
     * @return string
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * @param string $user
     */
    public function setUser($user)
    {
        $this->user = $user;
    }

    /**
     * @return string
     */
    public function getMcc()
    {
        return $this->mcc;
    }

    public function getTestMode()
    {
        return $this->testMode;
    }

    /**
     * @param string $password
     */
    public function setMcc($mcc)
    {
        $this->mcc = $mcc;
    }

    /**
     * @return string
     */
    public function getToken()
    {
        return $this->token;
    }

    /**
     * @param string $token
     */
    public function setToken($token)
    {
        $this->token = $token;
    }

}