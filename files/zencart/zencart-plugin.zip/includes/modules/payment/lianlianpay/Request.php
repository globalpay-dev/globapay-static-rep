<?php

require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/LianLianSign.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/Cryptography.php');
require_once(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/lianlianpay/RequestErrorException.php');

class Request
{
    const SUCCESS = true;
    /**
     * @var Cryptography
     */
    private $cryptography;

    private $callback = null;

    public function __construct(Cryptography $cryptography, $callback = null)
    {
        $this->cryptography = $cryptography;
        $this->callback = $callback;
    }

    public function get($url, $data)
    {

    }

    public function post($url, $data)
    {
        $data = $this->completion($data);
        if(\is_callable($this->callback)){
            $result = \call_user_func($this->callback, [ $url, $data ]);
        }else{
            $result = $this->curlPost($url, $data);
        }
        if(!isset($result) || empty($result)){
            throw new RequestErrorException('post request error, response data is empty');
        }
        $response = \json_decode($result, true);
        if($response === null || $response === false || empty($response) || \json_last_error()){
            throw new RequestErrorException('request response json format error,' . \json_last_error_msg() . '<br/>' . $result);
        }
        if(!isset($response['status'])){
            throw new RequestErrorException('post request response error');
        }
        if($response['status'] === self::SUCCESS && isset($response['data']) && !empty($response['data'])){
            return $response['data'];
        }else{
            throw new RequestErrorException($response['message']);
        }
    }

    /**
     * 发送支付请求
     * @param $url
     * @param $request
     * @param $account
     * @return mixed
     */
    public function sendCurl($url, $request, $account)
    {
        $headers_req = array(
            'sign-type: ' . 'RSA',
            'timestamp: ' . date("YmdHis", time()),
            'timezone: ' . date_default_timezone_get(),
            'Content-Type: ' . 'application/json',
        );
        $sign_tools = new LianLianSign();
        $headers_req[] = 'signature: ' . $sign_tools->lianlianSign($request, $account->getToken());;
        $header_res = [];
//        Helper::zcLog('INFO',  $headers_req[4] );
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers_req);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($request));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HEADERFUNCTION,
            function ($curl, $header) use (&$header_res) {
                $len = strlen($header);
                $header = explode(':', $header, 2);
                if (count($header) < 2) // ignore invalid headers
                    return $len;
                $header_res[strtolower(trim($header[0]))][] = trim($header[1]);
                return $len;
            }
        );
        $response_data = curl_exec($curl);
        curl_close($curl);
        //验签
        $response = json_decode($response_data, true);
        if ($response['return_code'] != 'SUCCESS') {
            return $response;
        }
        if(!isset($header_res['signature'])){
            return $response;
        }
        $check =  $sign_tools->lianlianVerifySign($response, $header_res['signature'][0], Helper::getLL_PUBLICKEY($account->getTestMode()) );
        if (!$check) {
            $response['return_code'] = 'signature error';
        }
        return $response;
    }


    public function completion($param)
    {
        $sign_param = \array_merge($param, $param['data']);
        unset($sign_param['data']);
        $sign = $this->cryptography->encrypt($sign_param, true);
        $param['sign'] = $sign;
        return \json_encode($param, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    private function curlPost($url, $data)
    {
        $curl = \curl_init();
        \curl_setopt($curl, CURLOPT_URL, $url);
        \curl_setopt($curl, CURLOPT_HEADER, 0);
        \curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        \curl_setopt($curl, CURLOPT_POST, 1);
        \curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        \curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $result = \curl_exec($curl);
        if(\curl_errno($curl)){
            $error = \curl_error($curl);
        }
        \curl_close($curl);
        if(isset($error) && !empty($error)){
            throw new RequestErrorException($error);
        }
        return $result;
    }

    /**
     * @return mixed
     */
    public function getCallback()
    {
        return $this->callback;
    }

    /**
     * @param mixed $callback
     */
    public function setCallback($callback)
    {
        $this->callback = $callback;
    }


}