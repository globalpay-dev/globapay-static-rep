<?php

class Notify
{
    /**
     * @var Cryptography
     */
    private $cryptography;

    public function __construct(Cryptography $cryptography)
    {
        $this->cryptography = $cryptography;
    }

    /**
     * 获取回调订单
     * @return mixed
     */
    public function getOrderInfo($notifyType, $testMode)
    {
        $sign_tool = new LianLianSign();
        $result = \file_get_contents('php://input');
        Helper::zcLog('INFO', "======获取回调信息========".json_encode($result));
        if(!empty($result)){
            $result = \urldecode($result);
        }
        if(empty($result)){
            throw new \InvalidArgumentException('Receiver Data Is Empty');
        }
        $signature = "";
        $payment_status = "";
        if(isset($notifyType) && Api::NOTIFY == $notifyType){
            if(isset($_SERVER['HTTP_SIGNATURE'])) {
                 $signature = $_SERVER['HTTP_SIGNATURE'];
             }
            $result = $this->processNotifyRes($result);
            $payment_data = $result['payment_data'];
            $payment_status = $payment_data['payment_status'];
//            return $result;
        } else {
            $result = $this->processRedirectRes($result);
            $signature = $result['signature'];
            $payment_status = $result['payment_status'];
            unset($result['signature']);
        }
        $check_result = $sign_tool->lianlianVerifySign($result, $signature, Helper::getLL_PUBLICKEY($testMode));
        if (!$check_result) {
           throw new \InvalidArgumentException('Receiver Data Signature Verification Failed');
        }
        $result['payment_status'] = $payment_status;
        return  $result;
    }

    /**
     * @return Cryptography
     */
    public function getCryptography()
    {
        return $this->cryptography;
    }

    /**
     * @param Cryptography $cryptography
     */
    public function setCryptography(Cryptography $cryptography)
    {
        $this->cryptography = $cryptography;
    }

    /**
     * 处理异步回调参数对象
     * @param $result
     * @return array
     */
    private function processNotifyRes($result){
        $res = array();
        $result = \json_decode($result, true);
        if(isset($result['merchant_transaction_id']) && !empty($result['merchant_transaction_id'])){
            $res['merchant_transaction_id'] = $result['merchant_transaction_id'];
        }
        $payment_data = $result['payment_data'];
        /*if(isset($payment_data) && !empty($payment_data)){
            if(isset($payment_data['payment_status']) && !empty($payment_data['payment_status'])){
                $res['order_status'] = $payment_data['payment_status'];
            }
            if(isset($payment_data['payment_amount']) && !empty($payment_data['payment_amount'])){
                $res['payment_amount'] = $payment_data['payment_amount'];
            }
        }*/
        if (isset($payment_data['payment_amount']) && !empty($payment_data['payment_amount'])) {
            $payment_amount = $payment_data['payment_amount'];
            $payment_data['payment_amount'] = number_format($payment_amount, 2, ".", "");
        }
        if (isset($payment_data['exchange_rate']) && !empty($payment_data['exchange_rate'])) {
            $exchange_rate = $payment_data['exchange_rate'];
            $payment_data['exchange_rate'] = number_format($exchange_rate, 8, ".", "");
        }
        if (isset($payment_data['settlement_amount']) && !empty($payment_data['settlement_amount'])) {
            $settlement_amount = $payment_data['settlement_amount'];
            $payment_data['settlement_amount'] = number_format($settlement_amount, 2, ".", "");
        }
        $result['payment_data'] = $payment_data;
        if(!isset($payment_data['payment_status']) || empty($payment_data['payment_status'])){
            throw new \InvalidArgumentException('Receiver Data payment_status is Missing');
        }
        return $result;
    }

    /**
     * 处理同步回调参数对象
     * @param $result
     * @return array
     */
    private function processRedirectRes($result){
        $arr = explode('&', $result);
        $res = array();
        foreach ($arr as $k => $v) {
            $arr = explode('=', $v);
            $res[$arr[0]] = $arr[1];
        }
        if (!isset($res['signature']) || empty($res['signature'])) {
            throw new \InvalidArgumentException('Receiver SIGNATURE Is Empty');
        }
        if(!isset($res['payment_status']) || empty($res['payment_status'])){
            throw new \InvalidArgumentException('Receiver Data payment_status is Missing');
        }
        return $res;
    }
}