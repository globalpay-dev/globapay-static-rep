<?php

class LianLianSign
{
    function __construct() {

    }

    public function lianlianSign(&$data, $privateKey)
    {
//        Helper::zcLog("INFO", 'privateKey: ' . $privateKey);
        return $this->genSign($this->genSignContent($data), $privateKey);
    }

    public function lianlianVerifySign(&$data, $sign, $pubKey)
    {
        return $this->verifySign($this->genSignContent($data), $sign, $pubKey);
    }

    /**
     * 生成签名内容
     * @param $req
     * @return string
     */
    private function genSignContent(&$req)
    {
        $arr = array($req);
//        Helper::zcLog("INFO", $arr);
        $strs = array();
        ksort($arr);
        $this->items(0, $arr, $strs);
        $msg = implode('&', $strs);
//        Helper::zcLog("INFO", 'SignContent: ' . $msg);
        return $msg;
    }

    /**
     * 递归深度优先排序
     * @param $x
     * @param $y
     * @param $strs
     */
    private function items($x, $y, &$strs)
    {
        if (!isset($y)) {
            return;
        }
        if (is_array($y)) {
            ksort($y);
            foreach ($y as $key => $value) {
                $this->items($key, $value, $strs);
            }
            return;
        }
        $strs[] = $x . "=" . $y;
    }

    /**
     * 生成签名
     * @param $toSign
     * @param $privateKey
     * @return string
     */
    public function genSign($toSign, $privateKey)
    {
        //这里他是拼接成和pem文件一样的格式
        $privateKey = "-----BEGIN RSA PRIVATE KEY-----\n" . wordwrap($privateKey, 64, "\n",true) . "\n-----END RSA PRIVATE KEY-----\n";
        $key = openssl_get_privatekey($privateKey);
        openssl_sign($toSign, $signature, $key);
        openssl_free_key($key);
        $sign = base64_encode($signature);
        return $sign;
    }

    /**
     * 验证签名
     * @param $data
     * @param $sign
     * @param $pubKey
     * @return bool
     */
    public function verifySign($data, $sign, $pubKey)
    {
        $sign = base64_decode($sign);

        $pubKey = "-----BEGIN PUBLIC KEY-----\n" .
            wordwrap($pubKey, 64, "\n", true) .
            "\n-----END PUBLIC KEY-----";

        $key = openssl_pkey_get_public($pubKey);
        $result = openssl_verify($data, $sign, $key, OPENSSL_ALGO_SHA1) === 1;
        return $result;
    }


}