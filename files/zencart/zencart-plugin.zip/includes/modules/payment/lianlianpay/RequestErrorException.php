<?php


class RequestErrorException extends \Exception
{

}