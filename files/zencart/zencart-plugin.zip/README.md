# LianLianPay payment module v1.0.0

[中文]
==================================================

功能说明：
1. LianLianPay支付模块，适用 Zen Cart v1.5.* 英文版；
2. 在使用LianLianPay接口前，需要先联系LianLianPay客服开通服务。

安装说明：
1. 上传目录下所有文件到Zen Cart对应的目录；
2. 管理页面->模块管理->支付模块->LianLianPay，根据提示设置各项参数。

[English]
==================================================

Function Description:
1. LianLianPay payment module, applicable to Zen Cart v1.5.* English Version;
2. Before using LianLianPay interface, we need to contact LianLianPay customer service first.

Installation:
1. Upload all files under the directory to the corresponding directory of Zen cart;
2. Management > Modules > Payment > LianLianPay, and set the parameters according to the prompts.