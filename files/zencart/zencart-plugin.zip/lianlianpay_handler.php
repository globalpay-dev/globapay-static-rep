<?php
/**
 * Callback module for LianLianPay payment module
 *
 */

header('Access-Control-Allow-Origin: *');
require 'includes/application_top.php';
if (!empty($_GET) && empty($_POST)) {
    $_POST = $_GET;
}
unset($_GET);
if (empty($_POST)) {
    die();
}
$result = file_get_contents('php://input');
if (empty($result)) {
    die();
}
$result = processNotifyRes($result);

require DIR_WS_CLASSES . 'payment.php';

$module = new payment('lianlianpay');
$lianlianpay = new lianlianpay;
$sign_tool = new LianLianSign;

$signature = $_SERVER['HTTP_SIGNATURE'];
$order_id = trim($result['merchant_transaction_id']);
$ll_transaction_id = trim($result['ll_transaction_id']);
$payment_status = $result['payment_data']['payment_status'];
unset($_SESSION['order_id']);

Helper::zcLog('INFO', "notify data:\n orderId=" . $order_id . "\n llTransactionId=" . $ll_transaction_id . "\n status=" . $payment_status);

$sign_tool = new LianLianSign;
$check_result = $sign_tool->lianlianVerifySign($result, $signature, MODULE_PAYMENT_LIANLIANPAY_PUBLIC_KEY);
if (!$check_result) {
    $messageStack->add_session('checkout_payment', 'signature error!', 'error');
    unset($_SESSION['order_id']); // if the customer come back and replace same order which has been paid
    echo response_info('verify signature fail');
    exit;
}


if ($payment_status == 'PS') {
    if (!checkExist($db, $order_id)) {
        Helper::zcLog('INFO', 'payment success duplicate notify: orderId=' . $order_id);
        http_response_code(200);
        echo response_info('200');
        exit;
    }


    require(DIR_WS_CLASSES . 'order.php');
    $order = new order($order_id);

    // 发成功邮件
    $_SESSION['messageStack'] = "Pay Result: Successful";
    $lang_file = DIR_WS_LANGUAGES . $_SESSION['language'] . '/checkout_process.php';
    if (file_exists($lang_file)) {
        require_once($lang_file);
    } else {
        require_once('includes/languages/english/checkout_process.php');
    }
    $order->send_order_email($order_id, 2);


    // 添加订单状态历史记录
    $comment = 'Order payment successful! TransactionNo:' . $ll_transaction_id;
    $sql_data_array = array('orders_id' => $order_id,
        'orders_status_id' => MODULE_PAYMENT_LIANLIANPAY_ORDER_STATUS_ID,
        'date_added' => 'now()',
        'comments' => $comment,
        'customer_notified' => '1'
    );
    zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);

    //更新订单状态
    $sql_data_array = array(
        'orders_status' => MODULE_PAYMENT_LIANLIANPAY_ORDER_STATUS_ID,
        'orders_date_finished' => 'now()',
    );
    zen_db_perform(TABLE_ORDERS, $sql_data_array, 'update', 'orders_id = ' . (int)$order_id);

    Helper::zcLog('INFO', 'payment success : orderId=' . $order_id);


    $_SESSION['cart']->reset(true);
    unset($_SESSION['order_id']);


    http_response_code(200);
    echo response_info('200');
    exit;
}


/**
 * 判断历史库中是否已经有该订单LianLianPay的通知的记录（避免重复写入）
 * @param queryFactory $db
 * @param $order_id
 * @return mixed
 */
function checkExist(queryFactory $db, $order_id)
{
    $orders_query = "SELECT count(1) as counter FROM " . TABLE_ORDERS_STATUS_HISTORY . "
                 WHERE orders_id = :orderId and comments like '%TransactionNo%' LIMIT 1 ";
    $orders_query = $db->bindVars($orders_query, ':orderId', $order_id, 'string');
    $orders = $db->Execute($orders_query);
    $counter = $orders->fields['counter'];
    return $counter == 0;
}

function response_info($code)
{
    $res = [
        'code' => $code
    ];
    return json_encode($res);
}

/**
 * 处理异步回调参数对象
 * @param $result
 * @return array
 */
function processNotifyRes($result)
{
    $res = array();
    $result = \json_decode($result, true);
    if (isset($result['merchant_transaction_id']) && !empty($result['merchant_transaction_id'])) {
        $res['merchant_transaction_id'] = $result['merchant_transaction_id'];
    }
    $payment_data = $result['payment_data'];
    if (isset($payment_data['payment_amount']) && !empty($payment_data['payment_amount'])) {
        $payment_amount = $payment_data['payment_amount'];
        $payment_data['payment_amount'] = number_format($payment_amount, 2, ".", "");
    }
    if (isset($payment_data['exchange_rate']) && !empty($payment_data['exchange_rate'])) {
        $exchange_rate = $payment_data['exchange_rate'];
        $payment_data['exchange_rate'] = number_format($exchange_rate, 8, ".", "");
    }
    if (isset($payment_data['settlement_amount']) && !empty($payment_data['settlement_amount'])) {
        $settlement_amount = $payment_data['settlement_amount'];
        $payment_data['settlement_amount'] = number_format($settlement_amount, 2, ".", "");
    }
    $result['payment_data'] = $payment_data;
    if (!isset($payment_data['payment_status']) || empty($payment_data['payment_status'])) {
        throw new \InvalidArgumentException('Receiver Data payment_status is Missing');
    }
    return $result;
}