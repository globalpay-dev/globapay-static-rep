var config = {
    map: {
        '*': {
            'LLPayJs': 'https://gacashier.lianlianpay-inc.com/sandbox2/llpay.min.js',
            'LLPayJsPro': 'https://gpcashier.lianlianpay.com/v2/llpay.min.js',
            'llpay_payments': 'LianLian_LLPay/js/llpay_payments'
        }
    }
};
