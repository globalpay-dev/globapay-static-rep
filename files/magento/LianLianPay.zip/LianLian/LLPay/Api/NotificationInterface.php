<?php
namespace LianLian\LLPay\Api;

/**
 * Created by
 * User：罗志禹
 * Date：2022/4/14
 * Time：23:01
 */
interface NotificationInterface
{
    /**
     * @return mixed
     */
    public function updateStatus();
}
