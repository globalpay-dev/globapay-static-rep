<?php
/**
 * Created by
 * User：罗志禹
 * Date：2022/2/17
 * Time：23:03
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'LianLian_LLPay', __DIR__);
