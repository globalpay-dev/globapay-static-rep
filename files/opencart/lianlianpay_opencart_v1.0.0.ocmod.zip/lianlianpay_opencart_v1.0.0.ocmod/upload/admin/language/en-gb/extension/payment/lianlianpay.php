<?php
// Heading
$_['heading_title']					= 'LianLianPay';

// Text
$_['text_payment']					= 'Payment';
$_['text_extension']			    = 'Extensions';
$_['text_success']					= 'Success: You have modified LianLianPay account details!';
$_['text_edit']                     = 'Edit LianLianPay';
$_['text_lianlianpay']					= '<a href="https://www.lianlianpay.com" target="_blank"><img src="view/image/payment/lianlianpay.png" alt="LianLianPay" title="LianLianPay" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_testmode_on']				= 'On';
$_['text_testmode_off']				= 'Off';

// Entry
$_['entry_merchantId']				= 'Merchant Id';
$_['entry_apikey']				    = 'Api Key';
$_['entry_secretkey']				= 'Secret Key';
$_['entry_country']				    = 'Country';
$_['entry_test']					= 'Test Mode';
$_['entry_order_status']			= 'Order Status';
$_['entry_geo_zone']				= 'Geo Zone';
$_['entry_status']					= 'Status';
$_['entry_sort_order']				= 'Sort Order';

// Error
$_['error_permission']				= 'Warning: You do not have permission to modify payment LianLianPay!';
$_['error_merchantId']				= 'Merchant Id Required!';
$_['error_secretkey']				= 'Secret Key Required!';
$_['error_apikey']				    = 'Api Key Required!';
$_['error_country']				    = 'Country Required!';