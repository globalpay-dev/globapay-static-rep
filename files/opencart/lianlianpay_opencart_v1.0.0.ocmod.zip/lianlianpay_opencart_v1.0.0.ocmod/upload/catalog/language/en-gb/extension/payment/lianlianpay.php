<?php
// Heading
$_['heading_title'] = 'Thank you for shopping with %s .... ';

// Text
$_['text_title'] = 'LianLianPay';


$_['text_response'] = '';
$_['text_success'] = '... your payment was successfully received.';
$_['text_success_wait'] = '<b><span style="color: #FF0000">Please wait...</span></b> while we finish processing your order.<br>If you are not automatically re-directed in 10 seconds, please click <a href="%s">here</a>.';
$_['text_failure'] = '... Your payment has not been received yet, please wait up to 10 minutes for us to process the payment if you have paid.';
$_['text_failure_wait'] = '<b><span style="color: #FF0000">Please wait...</span></b><br>If you are not automatically re-directed in 10 seconds, please click <a href="%s">here</a>.';
$_['text_pw_mismatch'] = 'CallbackPW does not match. Order requires investigation.';

$_['text_system_error'] = 'system error';
$_['text_customer_has_restrictions'] = 'you has restrictions to perform exchange operation';
$_['text_annual_limit_exceeded'] = 'you has exceeded the annual limit. for you to continue shopping, send proof of income to request limit increase ';
$_['text_boleto_limit_exceeded'] = 'boleto_limit_exceeded ';
$_['text_fx_transaction_limit_exceeded'] = 'fx_transaction_limit_exceeded';
$_['text_payment_completed'] = 'payment_completed';
$_['text_payment_closed'] = 'payment_closed ';
$_['text_refund_amount_exceeded '] = 'the refund amount can not be greater than the amount of the order previously paid   ';
$_['text_non_refundable_order'] = 'the current order status does not allow a refund';
$_['text_refund_already_requested'] = ' the refund of this order has already been requested.';
$_['text_insufficient_balance'] = 'merchant does not have enough balance for this operation ';