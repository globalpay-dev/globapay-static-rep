<?php

class ControllerExtensionPaymentLianlianpay extends Controller
{
    protected $pm_id = '';

    /**
     * 创单页面
     * @return mixed
     */
    public function index()
    {

        $data['button_confirm'] = $this->language->get('button_confirm');
        $data['text_loading'] = 'loading';
        $data['entry_phone'] = 'phone';
        $data['url'] = $this->url->link('extension/payment/lianlianpay/resend', '', true);

        return $this->load->view('default/template/extension/payment/lianlianpay', $data);
    }

    /**
     * 发送创单请求，返回收银台url
     */
    public function resend()
    {


        $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        $products_info = $this->model_checkout_order->getOrderProducts($this->session->data['order_id']);

        $req_products = array();
        $order_desc = '';
        foreach ($products_info as $product) {
            $order_desc = $order_desc . $product['name'] . ' x ' . $product['quantity'] . '; ';
            $req_products[] = array(
                'product_id' => $product['product_id'],
                'name' => $product['name'],
                'price' => round($product['price'], 2),
                'quantity' => $product['quantity']
            );
        }
        $req_address = array(
            'postal_code' => $order_info['payment_postcode'] ?: '00000000',
            'country' => $order_info['payment_iso_code_2'],
            'state' => $order_info['payment_zone'],
            'city' => $order_info['payment_city'],
            'district' => '0',
            'street_name' => $order_info['payment_address_1'],
            'house_number' => $order_info['payment_address_2'] ?: '0'
        );
        ksort($req_address);
        $req_customer = array(
            'customer_type' => 'I',
            'first_name' => $order_info['firstname'],
            'last_name' => $order_info['lastname'],
            'full_name' => $order_info['firstname'] . ' ' . $order_info['lastname'],
            'email' => $order_info['email'],
            'address' => $req_address
        );
        ksort($req_customer);
        $req_merchant_order = array(
            'merchant_order_id' => $order_info['order_id'],
            'merchant_order_time' => date("YmdHis", strtotime($order_info['date_added'])),
            'order_description' => $order_desc,
            'order_amount' => round($order_info['total'], 2),
            'order_currency_code' => $order_info['currency_code'],
            'products' => $req_products
        );
        ksort($req_merchant_order);
        $req_payment_data = array(
            'settlement_currency_code' => $order_info['currency_code']
        );
        $merchantId = $this->config->get('payment_lianlianpay_merchantId');
        $request = array(
            'merchant_transaction_id' => $order_info['order_id'],
            'merchant_id' => $merchantId,
            'customer' => $req_customer,
            'merchant_order' => $req_merchant_order,
            'payment_data' => $req_payment_data,
            'notification_url' => $this->url->link('extension/payment/lianlianpay/notify', '', true),
            'redirect_url' => $this->url->link('checkout/success', '', true),
            'cancel_url' => $this->url->link('checkout/checkout', '', true),
            'country' => $this->config->get('payment_lianlianpay_country')
        );
        ksort($request);
        $header = array(
            'sign-type: ' . 'RSA',
            'timestamp: ' . date("YmdHis", time()),
            'timezone: ' . date_default_timezone_get(),
            'Content-Type: ' . 'application/json'
        );
        if ($this->config->get('payment_lianlianpay_test')) {
            $url = 'https://celer-api.lianlianpay-inc.com/v3/merchants/' . $merchantId . '/payments';
        } else {
            $url = 'https://gpapi.lianlianpay.com/v3/merchants/' . $merchantId . '/payments';
        }
        $response_data = $this->sendCurl($url, $header, $request);


        $json = $this->processRes($response_data);
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }


    public function processRes(&$res)
    {
        $code = $res['return_code'];
        $json = array(
            'suc' => $code == 'SUCCESS'
        );
        if ($code == 'SUCCESS') {
            $json['url'] = $res['order']['payment_url'];
            return $json;
        }

        $this->load->language('extension/payment/lianlianpay');
        switch ($code) {
            case "CUSTOMER_HAS_RESTRICTIONS":
                $json['msg'] = $this->language->get('text_customer_has_restrictions');
                break;
            case "ANNUAL_LIMIT_EXCEEDED":
                $json['msg'] = $this->language->get('text_annual_limit_exceeded');
                break;
            case "BOLETO_LIMIT_EXCEEDED":
                $json['msg'] = $this->language->get('text_boleto_limit_exceeded');
                break;
            case "FX_TRANSACTION_LIMIT_EXCEEDED":
                $json['msg'] = $this->language->get('text_fx_transaction_limit_exceeded');
                break;
            case "PAYMENT_COMPLETED":
                $json['msg'] = $this->language->get('text_payment_completed');
                break;
            case "PAYMENT_CLOSED":
                $json['msg'] = $this->language->get('text_payment_closed');
                break;
            case "REFUND_AMOUNT_EXCEEDED ":
                $json['msg'] = $this->language->get('text_refund_amount_exceeded');
                break;
            case "NON_REFUNDABLE_ORDER":
                $json['msg'] = $this->language->get('text_non_refundable_order');
                break;
            case "REFUND_ALREADY_REQUESTED":
                $json['msg'] = $this->language->get('text_refund_already_requested');
                break;
            case "INSUFFICIENT_BALANCE":
                $json['msg'] = $this->language->get('text_insufficient_balance');
                break;
            default:
                $json['msg'] = $this->language->get('text_system_error');
        }
        return $json;
    }

    /**
     * 回调通知
     */
    public function notify()
    {
        $this->log->write('lianlianpay notify:');
        $sign = $_SERVER['HTTP_SIGNATURE'];
        $data = json_decode(file_get_contents('php://input'), true);
//        number_format($float, ),2, '.', '')
        $data['payment_data']['payment_amount'] = number_format(round($data['payment_data']['payment_amount'],2), 2, '.', '');
        $data['payment_data']['exchange_rate'] = number_format(round($data['payment_data']['exchange_rate'],2), 8, '.', '');
        $data['payment_data']['settlement_amount'] = number_format(round($data['payment_data']['settlement_amount'],2), 2, '.', '');
        $this->log->write('POST' . var_export($data, true));

        $check = $this->verifySign($this->genSignContent($data), $sign, $this->config->get('payment_lianlianpay_apikey'));
        $json = array();
        if ($check) {//check successed
            $this->log->write('lianlianpay check successed');
            $order_id = $data['merchant_transaction_id'];
            $this->load->model('checkout/order');
            $result = $this->checkResult($data, $this->model_checkout_order->getOrder($order_id));
            if ($result) {
                $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_lianlianpay_order_status_id'));
            }
            $json['Code'] = '200';
            $json['Msg'] = 'success';
        } else {
            $this->log->write('lianlianpay check failed');
            $json['Code'] = '400';
            $json['Msg'] = 'check signature error';
        }
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    private function checkResult($data, $order)
    {
        if ($data['payment_data']['payment_status'] != 'PS') {
            return false;
        }
        if ($data['payment_data']['payment_amount'] != $order['total']) {
            return false;
        }
        return true;
    }


    /**
     * 发送请求
     * @param $url
     * @param $headers_req
     * @param $request
     * @return mixed
     */
    private function sendCurl($url, $headers_req, $request)
    {
        // 签名
        $headers_req[] = 'signature: ' . $this->genSign($this->genSignContent($request), $this->config->get('payment_lianlianpay_secretkey'));


        $header_res = [];
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers_req);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($request));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HEADERFUNCTION,
            function ($curl, $header) use (&$header_res) {
                $len = strlen($header);
                $header = explode(':', $header, 2);
                if (count($header) < 2) // ignore invalid headers
                    return $len;

                $header_res[strtolower(trim($header[0]))][] = trim($header[1]);

                return $len;
            }
        );

        $response_data = curl_exec($curl);
        curl_close($curl);

        //TODO 验签
        $response = json_decode($response_data, true);

        if ($response['return_code'] != 'SUCCESS') {
            return $response;
        }
        $check = $this->verifySign($this->genSignContent($response), $header_res['signature'][0], $this->config->get('payment_lianlianpay_apikey'));
        if (!$check) {
            $response['return_code'] = 'signature error';
        }
        return $response;
    }


    /**
     * 生成签名内容
     * @param $req
     * @return string
     */
    private function genSignContent(&$req)
    {
        $arr = array($req);
        $strs = array();
        ksort($arr);
        $this->items(0, $arr, $strs);
        $msg = implode('&', $strs);
        return $msg;
    }

    /**
     * 递归深度优先排序
     * @param $x
     * @param $y
     * @param $strs
     */
    private function items($x, $y, &$strs)
    {
        if ($y == null) {
            return;
        }
        if (is_array($y)) {
            ksort($y);
            foreach ($y as $key => $value) {
                $this->items($key, $value, $strs);
            }
            return;
        }
        $strs[] = $x . "=" . $y;
    }

    /**
     * 生成签名
     * @param $toSign
     * @param $privateKey
     * @return string
     */
    private function genSign($toSign, $privateKey)
    {
        //这里他是拼接成和pem文件一样的格式
        $privateKey = "-----BEGIN RSA PRIVATE KEY-----\n" .
            wordwrap($privateKey, 64, "\n", true) .
            "\n-----END RSA PRIVATE KEY-----";

        $key = openssl_get_privatekey($privateKey);
        openssl_sign($toSign, $signature, $key);
        openssl_free_key($key);
        $sign = base64_encode($signature);
        return $sign;
    }

    /**
     * 验证签名
     * @param $data
     * @param $sign
     * @param $pubKey
     * @return bool
     */
    private function verifySign($data, $sign, $pubKey)
    {
        $sign = base64_decode($sign);

        $pubKey = "-----BEGIN PUBLIC KEY-----\n" .
            wordwrap($pubKey, 64, "\n", true) .
            "\n-----END PUBLIC KEY-----";

        $key = openssl_pkey_get_public($pubKey);
        $result = openssl_verify($data, $sign, $key, OPENSSL_ALGO_SHA1) === 1;
        return $result;
    }


}