<?php
include_once "../util/sign.php";

//const LL_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxkPtaI6OCdnFwQPoyuCDGTIagYFP0MYvUd9IcVZbs4JRB/E+y2y1Gw2m59ROEbE28Y95IPh9YwrUPXL+SN/LeQO8pE0nNf3EUge3JNmWjQyucToZ+TRmeyTCadkPNIy0MyJR1Sa68K6CFnHRZ9xqbcCPACB+g2v+1HUJgMwjbaDr8UdJpqEY6q7Omh02Nc3AB5zKf01CnyffqixiTcD/UAXiiipnGhReXCV7pM7eQ5+5N0jw/RDPsMSX01GjU2p/ZH5fFgJXHv+pw0wm7tm66dI2+G6caCk2UbJZriUoJNkjoxePFwGNSX6xcjbwLEhvbkrMWwixJkQ/TCf0zbO8zwIDAQAB";
const LL_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwnPfpxFGfzg8kKd3iFTyahj+n5TcR8J8QLwWnQdYa73VHHXO06pUmqS3aXCNladnRc03s+qBzAfTm3HTWIrPQ2dwoaOIe1xBOwPQMab94KKR+FUOzUwri2QUuVQHrY1lZOImDYNbycnQ1p3ZtPvgj2mdENTzr1XiHyUflnArCICId8n5CtAxfEmRBZwZcAYPbEILmbAITj4MJLvRClNnzDgAaRWJcumvbas4G1erQUubwfgbIsDLqPld2+P0bcQUbILJEC8eyAMBScyxqjCC71ox2NvM+NZgI7rOdjFS8RvQYx2DtcLGZl+l5IzgbCOij2qFhOjy/cXanU01kzivyQIDAQAB";
$notify_body = file_get_contents("php://input");
$signature = $_SERVER['HTTP_SIGNATURE'];
echo $notify_body;
echo "<br>";
echo $signature;
$notifyMsg = json_decode($notify_body, true);
echo "<br>";
print_r($notifyMsg);
if (empty($signature)) {
    echo "no signature";
    return http_response_code("401");
} else {
    $sign_tool = new LianLianSign();
    $check_result = $sign_tool->verifySignForLianlian($notifyMsg, $signature, LL_PUBLIC_KEY);
    if (!$check_result) {
        echo "signature error";
        return http_response_code("401");
    } else {
        $payment_status = $notifyMsg['payment_data']['payment_status'];
        if ($payment_status == 'PS') {
            echo "ok";
        } else {
            echo "payment result incorrect";
        }
    }
}