<?php
include_once "../util/sign.php";

$pay_query = new PaymentQuery();
$result = $pay_query->query();
echo json_encode($result);
class PaymentQuery {
    const MERCHNAT_ID = "202006090000013002";
    const PRIVATE_KEY = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDGQ+1ojo4J2cXBA+jK4IMZMhqBgU/Qxi9R30hxVluzglEH8T7LbLUbDabn1E4RsTbxj3kg+H1jCtQ9cv5I38t5A7ykTSc1/cRSB7ck2ZaNDK5xOhn5NGZ7JMJp2Q80jLQzIlHVJrrwroIWcdFn3GptwI8AIH6Da/7UdQmAzCNtoOvxR0mmoRjqrs6aHTY1zcAHnMp/TUKfJ9+qLGJNwP9QBeKKKmcaFF5cJXukzt5Dn7k3SPD9EM+wxJfTUaNTan9kfl8WAlce/6nDTCbu2brp0jb4bpxoKTZRslmuJSgk2SOjF48XAY1JfrFyNvAsSG9uSsxbCLEmRD9MJ/TNs7zPAgMBAAECggEBAJhnFLJfik2GKd3hrGtuwzd17SwJg5n/DdbIZP5CHMFS9gi958AlMt2108u2xcAR0iNDXx/6AyBD7bvCjjbkWJsQRUyixfZZuDQ6HAzmeTS5P8pnmBmYrwIP0qXcpTSGx+nagr7vQ5nI+tRX71j/9IujDglR8Q4C0OLtiD2KLd2RD8/GF2bkpxlrk2UZGGK4EuQQPc57O1RkceqEQVr3gZrKF4SGnLbZJlwJQDxZZz8VSqk4/ptee56bkjUZBDv0ENTr2hMujd6BJjvOBloinj4vyGsETals4h4AB3xDmg6ce2eIy8lP7JqQcXwKsx/qXG+YD4LugSFfh6JJFz/qAsECgYEA6hxakY+XDmCmJYsJdy4zF4SDP0Ley4X8tYo02wh3WvADyMZBGd3ow0uWozlxF9UWu6kC355Xxaizzot15Ks6Cvfh8/Rr6F2Y+uVrCCIoZvXX+8qRVFbzfXeMzRbZtN0nHOkdhpU5HMImi11KdNxVL6qLsrBN/WzNED3SKRLprKECgYEA2M2VB1bEslDSH+vQFhHZ/5NugAmVf6R9PL1BG1RYa/tpqKI5ZJVCDjhDXu8BC+52umn3gYF0pmJhobdlJty2SDLMXTuNRSV25moy19kpzXZRRGX6Tf0fz+siTfpjGpqE4BxU6EiQjoSvtgSZtyf6830g/kghGk3RH99z8qPcA28CgYAjfHTGB6vwA/prSm3+4MPh1rZGSo6W7xJlOjPU162v3R3Vuyd3EkoMAFMvHq/j2ur9OxsyZkALuAy5TC5soP/FVdmsLuqEaFud/FSDARp6sN0yT3xD+oIiDJMNK1+IqNUa7sMI+WmU0GEjUtrMZ/GJriJKzaqktW9H/Pb0PueowQKBgQC7vPJzQ3ja7M+4YqxzoAvFnDaQ2zvBJ4Bni38ImnZjM3fgVnIanoFv7NqyJ4chfOMFM+PnGmIX/pOKxVPrXi7ewFZl2b7QhMu8ZXQXo+7mA7IF58TjqfDVTEkNe2g8TlgH9aC08Ll1IINDvCIcD5vpI47hgzZfH8marxYppClOMwKBgENGwsOXrdH2f2HoYSpXEYiM922HEMmOzX51wzHtj/bWF7g+83WQDUUoM0HIASsfa/wcWNK2DLnWUFPVjRQzqgYb9fT8H7M2w5+17SsfLA/ZkUC/SvTb1ZNCSw1faKfk88dxIeEzIC4Uy/APRx/XHglK22F0Yq/pk0reBZCEjaVu";
    const LL_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxkPtaI6OCdnFwQPoyuCDGTIagYFP0MYvUd9IcVZbs4JRB/E+y2y1Gw2m59ROEbE28Y95IPh9YwrUPXL+SN/LeQO8pE0nNf3EUge3JNmWjQyucToZ+TRmeyTCadkPNIy0MyJR1Sa68K6CFnHRZ9xqbcCPACB+g2v+1HUJgMwjbaDr8UdJpqEY6q7Omh02Nc3AB5zKf01CnyffqixiTcD/UAXiiipnGhReXCV7pM7eQ5+5N0jw/RDPsMSX01GjU2p/ZH5fFgJXHv+pw0wm7tm66dI2+G6caCk2UbJZriUoJNkjoxePFwGNSX6xcjbwLEhvbkrMWwixJkQ/TCf0zbO8zwIDAQAB";
    const PAY_URL = "https://celer-api.LianLianpay-inc.com/v3/merchants/%s/payments";
    const PAY_QUERY_URL = "https://celer-api.LianLianpay-inc.com/v3/merchants/%s/payments/%s";
    const REFUND_URL = "https://celer-api.LianLianpay-inc.com/v3/merchants/%s/payments/%s/refunds";
    const REFUND_QUERY_URL = "https://celer-api.LianLianpay-inc.com/v3/merchants/%s/refunds/%s";

    public function query() {
        $merchantTransactionId = "363627689558604";
        $pay_query_url = sprintf(self::PAY_QUERY_URL, self::MERCHNAT_ID, $merchantTransactionId);
        $request_params = array(
            "merchant_id"=>self::MERCHNAT_ID,
            "merchant_transaction_id"=>$merchantTransactionId
        );
        $sign_tools = new LianLianSign();
        $signature = $sign_tools->signForLianlian($request_params, self::PRIVATE_KEY);
        $header = array(
            'sign-type: ' . 'RSA',
            'timestamp: ' . date("YmdHis", time()),
            'timezone: ' . date_default_timezone_get(),
            'Content-Type: ' . 'application/json',
            'signature: '.$signature
        );
        $httpResponse = $this->payQuery($pay_query_url, $header);
        return $httpResponse;
    }

    /**
     * 发送请求
     * @param $url
     * @param $headers_req
     * @param $request
     * @return mixed
     */
    private function payQuery($url, $headers_req)
    {
        $header_res = [];
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers_req);
//        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($request));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HEADERFUNCTION,
            function ($curl, $header) use (&$header_res) {
                $len = strlen($header);
                $header = explode(':', $header, 2);
                if (count($header) < 2) // ignore invalid headers
                    return $len;

                $header_res[strtolower(trim($header[0]))][] = trim($header[1]);

                return $len;
            }
        );

        $response_data = curl_exec($curl);
        curl_close($curl);

        $response = json_decode($response_data, true);

        $return_code = $response['return_code'];
        if ($return_code != 'SUCCESS') {
            echo "<script>alert('warning! Pay Query failed')</script>";
            return $response;
        }
        if (empty($header_res['signature'][0])) {
            echo "<script>alert('warning! no signature, contact LL')</script>";
            return $response;
        } else {
            $sign_tool = new LianLianSign();
            $check = $sign_tool->verifySignForLianlian($response, $header_res['signature'][0], self::LL_PUBLIC_KEY);

            $payment_status = $response['order']['payment_data']['payment_status'];
            if (!$check) {
                echo "<script>alert('warning! signature error, contact LL')</script>";
            } else if ($payment_status == 'PS') {
                echo "<script>alert('Great! Payment successful')</script>";
            } else {
                echo "<script>alert('Payment processing')</script>";
            }
        }
        return $response;
    }
}