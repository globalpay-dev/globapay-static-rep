<?php
include_once "../util/sign.php";

const LL_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxkPtaI6OCdnFwQPoyuCDGTIagYFP0MYvUd9IcVZbs4JRB/E+y2y1Gw2m59ROEbE28Y95IPh9YwrUPXL+SN/LeQO8pE0nNf3EUge3JNmWjQyucToZ+TRmeyTCadkPNIy0MyJR1Sa68K6CFnHRZ9xqbcCPACB+g2v+1HUJgMwjbaDr8UdJpqEY6q7Omh02Nc3AB5zKf01CnyffqixiTcD/UAXiiipnGhReXCV7pM7eQ5+5N0jw/RDPsMSX01GjU2p/ZH5fFgJXHv+pw0wm7tm66dI2+G6caCk2UbJZriUoJNkjoxePFwGNSX6xcjbwLEhvbkrMWwixJkQ/TCf0zbO8zwIDAQAB";
$notify_body = file_get_contents("php://input");
$signature = $_SERVER['HTTP_SIGNATURE'];

$notifyMsg = json_decode($notify_body, true);
if (empty($signature)) {
    echo "no signature";
    return http_response_code("401");
} else {
    $sign_tool = new LianLianSign();
    $check_result = $sign_tool->verifySignForLianlian($notifyMsg, $signature, LL_PUBLIC_KEY);
    if (!$check_result) {
        echo "signature error";
        return http_response_code("401");
    } else {
        $payment_status = $notifyMsg['refund_data']['refund_status'];
        if ($payment_status == 'RS') {
            echo "ok";
        } else {
            echo "refund result incorrect";
        }
    }
}