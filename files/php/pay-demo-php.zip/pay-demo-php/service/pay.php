<?php
include_once "../util/sign.php";

$payment = new PaymentApply();
$result = $payment->pay();
echo json_encode($result);
class PaymentApply {
    const MERCHNAT_ID = "202006090000013002";
    const PRIVATE_KEY = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDW0b6oUcwyzsqtG+WtBqd1IckQVC2Dw3kLg2bsVw4OhbeW0rck1bm1kfLMR3dp6TJx335QdKfpx6CaMGF98RbPYJR5URVncMpVGfgzDvCMBduqtgdUFRoRcRZadElVWGgmDWmviY+N68c7rccg8cFQ1mCvNd/Q2dM1YqoS/ZQPypxFJfN8V/Pa0lBC7ruDoUg3BRtZ2mmsFPhwcN/3Xl1jmZ3JNLGGjwHqR8SHK536RtYPXv/lgcIaylHw7wK08nMMWIbpaEM8NYbabXqiFCCTsbXNEdkLrzHUd9rdoMHhWFrc7kijJINkwWls04DxUClzuQIPEl0A0KlE8WPMt5CHAgMBAAECggEAbBH0wqTz/5N87v2b3CH+2LR4fFh81U7fdGVUwA1DqxamN6AmNse2t5uG9DH35zZEBHmVCFDHsJqXNzqjsUI6YXWK/EVIaVOa1plL/hPD/A1uZ0FQCoLbLG8h+buKsP7a1lnlE0Q3DgTRpDpWdUJqKIrQ9RQ7VsxervrF6OvdMtukXBtgDXX50REFKprhnbWvXYn/xZrywa4vmvW+U9IzGktTcNxaI7VVxa94EX/z+t/nTlcLdyWKinUbgSLcHXKRlqEwDFOQ7UkKwGTIpzClnq9VIfF0Fw5BKfIexht3K04i4Fdf9piw/pkSIC1ETaSKCpgaWp80T7UFox7IKcw+0QKBgQD/GlIll7/6Ev1/uAjDnzVejhs4k6iYHbK3EuW382A0ifz2KnhtClEc6ACa4IqN7t4OEnsCvU5Uztshc3PktAXIvHOMCQTtdkCsjIfO6QloH/Mdqmriq+7XfMdSkkeF5MksJ3g3fQ2NX4YwWAKN9p4PUsQWuoDWAkZOepP7tPOYFQKBgQDXkyexMDiRydvw1LFqYo5BUCNBnVDjzFaZMKdNBnU3Hhuzp18NlsEa+xARF3L50NV0IL60YqkoIReA8gZ3lu6RPREj1LqBsu7vkXf2wqzq3YXCMboAQyDVpLRstmvIKc0sg/esAcL7Xjaq0tJP3klAOpA4WZKDkh7J2s6e3C0xKwKBgBY/4XJN7fyNs3Z0Qq9tL2Zz1oP0vPune3LkPwzwOS/b6Sg/RAmeoLx4r7TSaMNAVjW7/uaaRD65W/tq6mzEFs0PQrSwBLIBYlqqVx4AzUU7pCSuPGxQuqAozemxwHM5JSKovp94VLpD3pxQ0Mg4/kgv29JvqdUAlck6f7Wwbp6RAoGBAKNIqv/i7nY+14ELGXbjP6zo7kt8xRBGbjGKUK5e/dnJzGG/nJfGYG33TKwlfskKDSPwyYIIWOg0aIEa0Rs0D2+jOaBSORKUXbbIEH2v5xnewLnewGwCbJRmNONDKVBrmSTmsGpwyydqrS2mkfY9AG7N7P9BmWBfBUMPoQFi9DgRAoGAbrLRT2YscCwn1Fem/1LC2I1HLWM3EEsaRhNErt6f/145KtszK8bak5sqiqd7U/a2UGTlIXHJgg5EM/GLsXgfcRYaZpDHsdmvdqJRWXmjlxh/HQQMNWQOWec9JgOK2Gi70f7PxsNDv0iTHuCCSw66yAdqFuqBwkSwTLsUMc7z8us=";
    const LL_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1tG+qFHMMs7KrRvlrQandSHJEFQtg8N5C4Nm7FcODoW3ltK3JNW5tZHyzEd3aekycd9+UHSn6cegmjBhffEWz2CUeVEVZ3DKVRn4Mw7wjAXbqrYHVBUaEXEWWnRJVVhoJg1pr4mPjevHO63HIPHBUNZgrzXf0NnTNWKqEv2UD8qcRSXzfFfz2tJQQu67g6FINwUbWdpprBT4cHDf915dY5mdyTSxho8B6kfEhyud+kbWD17/5YHCGspR8O8CtPJzDFiG6WhDPDWG2m16ohQgk7G1zRHZC68x1Hfa3aDB4Vha3O5IoySDZMFpbNOA8VApc7kCDxJdANCpRPFjzLeQhwIDAQAB";
    const PAY_URL = "https://celer-api.lianlianpay-inc.com/v3/merchants/%s/payments";
//    const PAY_URL = "http://10.20.97.49:9999/v3/merchants/%s/payments";
    const PAY_QUERY_URL = "https://celer-api.LianLianpay-inc.com/v3/merchants/%s/payments/%s";
    const REFUND_URL = "https://celer-api.LianLianpay-inc.com/v3/merchants/%s/payments/%s/refunds";
    const REFUND_QUERY_URL = "https://celer-api.LianLianpay-inc.com/v3/merchants/%s/refunds/%s";

    public function checkKey() {
        $src = "biz_code=EC&country=HK&city=HONGKONG&country=HK&district=Kowloon&house_number=Room 09, Floor 10&postal_code=210932&state=HK&street_name=Mei Sang House&customer_type=I&first_name=zhang&full_name=zhang san&last_name=san&merchant_id=202006090000013002&merchant_order_id=1595389263&merchant_order_time=20200722054103&order_amount=26.6&order_currency_code=USD&category=clothes&name=female clothes&price=26.6&product_id=P2020070001&quantity=1&shipping_provider=DHL&sku=sku-103848&url=https://www.baidu.com&city=HONGKONG&country=HK&district=Kowloon&house_number=Room 09, Floor 10&postal_code=210932&state=HK&street_name=Mei Sang House&name=zhang san&phone=+86-13657689382&merchant_transaction_id=1595389263&payment_amount=26.6&payment_currency_code=USD";
        $public_key = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxkPtaI6OCdnFwQPoyuCDGTIagYFP0MYvUd9IcVZbs4JRB/E+y2y1Gw2m59ROEbE28Y95IPh9YwrUPXL+SN/LeQO8pE0nNf3EUge3JNmWjQyucToZ+TRmeyTCadkPNIy0MyJR1Sa68K6CFnHRZ9xqbcCPACB+g2v+1HUJgMwjbaDr8UdJpqEY6q7Omh02Nc3AB5zKf01CnyffqixiTcD/UAXiiipnGhReXCV7pM7eQ5+5N0jw/RDPsMSX01GjU2p/ZH5fFgJXHv+pw0wm7tm66dI2+G6caCk2UbJZriUoJNkjoxePFwGNSX6xcjbwLEhvbkrMWwixJkQ/TCf0zbO8zwIDAQAB';
        $sign_tool = new LianLianSign();
        $signature = $sign_tool->genSign($src, self::PRIVATE_KEY);
        echo $signature;
        echo "\n";
        $check = $sign_tool->verifySign($src, $signature, $public_key);
        echo $check;
    }

    public function pay() {
        $now = time();
        $timestamp = date('YmdHis', $now);

        $address = array(
            "line1"=>"Mei Sang House",
            "line2"=>"Room 09, Floor 10",
            "city"=>"HONGKONG",
            "state"=>"HK",
            "country"=>"HK",
            "postal_code"=>"210932"
        );

        $customer = array(
            "customer_type"=>"I",
            "full_name" => "zhang san",
            "first_name" => "zhang",
            "last_name" => "san",
            "address"=>$address
        );

        $product = array(
            "product_id" => "P2020070001",
            "name" => "female clothes",
            "price" => "26.6",
            "quantity"=>1,
            "category" => "clothes",
            "sku" => "sku-103848",
            "shipping_provider" => "DHL",
            "url" => "https://www.baidu.com"
        );

        $card = array(
            "billing_address" => $address
        );

        $payment_data = array(
            "payment_currency_code" => "USD",
            "payment_amount" => "26.6",
            "card" => $card
        );

        $shipping = array(
            "name" => "zhang san",
            "phone" => "+86-13657689382",
            "cycle" => "other",
            "address" => $address
        );

        $merchant_order = array(
            "merchant_order_id"=>(string)$now,
            "merchant_order_time"=>$timestamp,
            "order_amount"=>"26.6",
            "order_currency_code" => "USD",
            "products"=>array($product),
            "shipping"=>$shipping
        );

        $pay_request = array(
            'merchant_transaction_id' => (string) $now,
            'merchant_id' => self::MERCHNAT_ID,
            'biz_code' => 'EC',
            'notification_url' => 'https://merchant.notify.com',
            'country' => 'HK',
            'merchant_order'=>$merchant_order,
//            'customer'=>$customer,
            'payment_data'=>$payment_data
        );

        $pay_url = sprintf(self::PAY_URL, self::MERCHNAT_ID);
        $sign_tools = new LianLianSign();
        $signature = $sign_tools->signForLianlian($pay_request, self::PRIVATE_KEY);
        $header = array(
            'sign-type: ' . 'RSA',
            'timestamp: ' . date("YmdHis", time()),
            'timezone: ' . date_default_timezone_get(),
            'Content-Type: ' . 'application/json',
            'signature: '.$signature
        );
        $httpResponse = $this->payApply($pay_url, $header, $pay_request);
        return $httpResponse;
    }

    /**
     * 发送请求
     * @param $url
     * @param $headers_req
     * @param $request
     * @return mixed
     */
    private function payApply($url, $headers_req, $request)
    {
        echo "\nrequest body: ".json_encode($request);
        $header_res = [];
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers_req);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($request));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_HEADERFUNCTION,
            function ($curl, $header) use (&$header_res) {
                $len = strlen($header);
                $header = explode(':', $header, 2);
                if (count($header) < 2) // ignore invalid headers
                    return $len;

                $header_res[strtolower(trim($header[0]))][] = trim($header[1]);

                return $len;
            }
        );

        $response_data = curl_exec($curl);
        echo "\nresponse is: ".$response_data;
        curl_close($curl);

        $response = json_decode($response_data, true);
        $return_code = $response['return_code'];
        if ($return_code != 'SUCCESS') {
            echo "\n<script>alert('warning! Pay Apply failed')</script>";
            return $response;
        }
        if (empty($header_res['signature'][0])) {
            echo "<script>alert('warning! no signature, contact LL')</script>";
            return $response;
        } else {
            $sign_tool = new LianLianSign();
            $check = $sign_tool->verifySignForLianlian($response, $header_res['signature'][0], self::LL_PUBLIC_KEY);

            $payment_status = $response['order']['payment_data']['payment_status'];
            if (!$check) {
                echo "<script>alert('warning! signature error, contact LL')</script>";
            } else if ($payment_status == 'PS') {
                echo "<script>alert('Great! Payment successful')</script>";
            } else {
                echo "<script>alert('Payment apply successful, wait for result notify or you can call the query endpoint.')</script>";
            }
        }
        return $response;
    }
}