<?php

namespace model;

class Address
{
    public $line1;
    public $line2;
    public $district;
    public $city;
    public $state;
    public $country;
    public $postal_code;
}