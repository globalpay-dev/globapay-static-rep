<?php

namespace model;

class Shipping
{
    public $name;
    public $phone;
    public $address;
    public $cycle;
}