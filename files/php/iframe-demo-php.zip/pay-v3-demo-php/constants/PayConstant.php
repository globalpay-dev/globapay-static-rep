<?php

namespace constants;

class PayConstant
{
    /**
     * 支付成功后跳转地址，商户支付成功地址，这里模拟商户的支付成功页面
     * 127.0.0.1:8080调不通，需要改为商户的实际通知地址
     * 收银台模式需要制定该参数，iframe模式只需要商户在支付页面根据支付结果报文跳转相应地址
     */
    public static $redirect_url = 'http://192.168.136.16/pay-v3-demo/pay_result.php';

    /**
     * 支付成功后异步通知地址，这里模拟商户的接收异常通知请求
     */
    public static $notification_url = 'http://192.168.136.16/pay-v3-demo/pay_notify.php';

    public static $pay_url = 'https://celer-api.LianLianpay-inc.com/v3/merchants/%s/payments';

    public static $merchant_id = '202103310000636003';

    public static $private_key = 'MIIEowIBAAKCAQEA1tG+qFHMMs7KrRvlrQandSHJEFQtg8N5C4Nm7FcODoW3ltK3JNW5tZHyzEd3aekycd9+UHSn6cegmjBhffEWz2CUeVEVZ3DKVRn4Mw7wjAXbqrYHVBUaEXEWWnRJVVhoJg1pr4mPjevHO63HIPHBUNZgrzXf0NnTNWKqEv2UD8qcRSXzfFfz2tJQQu67g6FINwUbWdpprBT4cHDf915dY5mdyTSxho8B6kfEhyud+kbWD17/5YHCGspR8O8CtPJzDFiG6WhDPDWG2m16ohQgk7G1zRHZC68x1Hfa3aDB4Vha3O5IoySDZMFpbNOA8VApc7kCDxJdANCpRPFjzLeQhwIDAQABAoIBAGwR9MKk8/+TfO79m9wh/ti0eHxYfNVO33RlVMANQ6sWpjegJjbHtrebhvQx9+c2RAR5lQhQx7Calzc6o7FCOmF1ivxFSGlTmtaZS/4Tw/wNbmdBUAqC2yxvIfm7irD+2tZZ5RNENw4E0aQ6VnVCaiiK0PUUO1bMXq76xejr3TLbpFwbYA11+dERBSqa4Z21r12J/8Wa8sGuL5r1vlPSMxpLU3DcWiO1VcWveBF/8/rf505XC3cliop1G4Ei3B1ykZahMAxTkO1JCsBkyKcwpZ6vVSHxdBcOQSnyHsYbdytOIuBXX/aYsP6ZEiAtRE2kigqYGlqfNE+1BaMeyCnMPtECgYEA/xpSJZe/+hL9f7gIw581Xo4bOJOomB2ytxLlt/NgNIn89ip4bQpRHOgAmuCKje7eDhJ7Ar1OVM7bIXNz5LQFyLxzjAkE7XZArIyHzukJaB/zHapq4qvu13zHUpJHheTJLCd4N30NjV+GMFgCjfaeD1LEFrqA1gJGTnqT+7TzmBUCgYEA15MnsTA4kcnb8NSxamKOQVAjQZ1Q48xWmTCnTQZ1Nx4bs6dfDZbBGvsQERdy+dDVdCC+tGKpKCEXgPIGd5bukT0RI9S6gbLu75F39sKs6t2FwjG6AEMg1aS0bLZryCnNLIP3rAHC+142qtLST95JQDqQOFmSg5IeydrOntwtMSsCgYAWP+FyTe38jbN2dEKvbS9mc9aD9Lz7p3ty5D8M8Dkv2+koP0QJnqC8eK+00mjDQFY1u/7mmkQ+uVv7aupsxBbND0K0sASyAWJaqlceAM1FO6QkrjxsULqgKM3pscBzOSUiqL6feFS6Q96cUNDIOP5IL9vSb6nVAJXJOn+1sG6ekQKBgQCjSKr/4u52PteBCxl24z+s6O5LfMUQRm4xilCuXv3Zycxhv5yXxmBt90ysJX7JCg0j8MmCCFjoNGiBGtEbNA9vozmgUjkSlF22yBB9r+cZ3sC53sBsAmyUZjTjQylQa5kk5rBqcMsnaq0tppH2PQBuzez/QZlgXwVDD6EBYvQ4EQKBgG6y0U9mLHAsJ9RXpv9SwtiNRy1jNxBLGkYTRK7en/9eOSrbMyvG2pObKoqne1P2tlBk5SFxyYIORDPxi7F4H3EWGmaQx7HZr3aiUVl5o5cYfx0EDDVkDlnnPSYDithou9H+z8bDQ79Ikx7ggksOusgHahbqgcJEsEy7FDHO8/Lr';

    public static $public_key = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1tG+qFHMMs7KrRvlrQandSHJEFQtg8N5C4Nm7FcODoW3ltK3JNW5tZHyzEd3aekycd9+UHSn6cegmjBhffEWz2CUeVEVZ3DKVRn4Mw7wjAXbqrYHVBUaEXEWWnRJVVhoJg1pr4mPjevHO63HIPHBUNZgrzXf0NnTNWKqEv2UD8qcRSXzfFfz2tJQQu67g6FINwUbWdpprBT4cHDf915dY5mdyTSxho8B6kfEhyud+kbWD17/5YHCGspR8O8CtPJzDFiG6WhDPDWG2m16ohQgk7G1zRHZC68x1Hfa3aDB4Vha3O5IoySDZMFpbNOA8VApc7kCDxJdANCpRPFjzLeQhwIDAQAB';

    public static $iframe_url = 'https://gacashier.lianlianpay-inc.com/sandbox/index.html?key=%s';

    public static $log_file = 'log.txt';
}