<?php

use constants\PayConstant;

require_once './service/IframeIcrPay.php';
require_once './constants/PayConstant.php';

echo "<h1>以下是外卡iframe模式的接入流程</h1>";
echo "=================================================================================";
echo '<br/>';
echo "<b>第一步 用户在商户页面选择外卡支付发起商户后端支付申请</b>";
echo '<br/>';
echo "-------------商户签名信息配置放在constants/PayConstant.php中-------------------";
echo '<br/>';
echo "以下是demo是模拟商户服务向连连发起支付申请请求及响应报文：";
echo '<br/>';

$icr_pay = new IframeIcrPay();
$response = $icr_pay->pay();

echo '返回参数: ' . json_encode($response) . '<br/>';
if (strcmp($response->return_code,'SUCCESS') == 0) {
    echo '<br/>';
    echo 'payment apply fail';
    echo '<br/>';
    exit();
}

$order = $response['order'];
$payment_url = sprintf(PayConstant::$iframe_url, $order['key']);
echo '连连交易单号llTransactionId:[' . $order['ll_transaction_id'] . ']商户交易单号[' . $order['merchant_transaction_id'] . ']';
echo '<br/>';
echo "=================================================================================";
echo '<br/>';
echo '<b>第二步 将 [<a href="' . $payment_url . '" target="_blank">' . $payment_url . '</a>]（此为模拟商户的支付页面）复制到浏览器打开</b>';
echo '<br/>';
echo "=================================================================================";
echo '<br/>';
echo "<b>第三步 在浏览器中按照以下案例测试</b>";
echo '<br/>';
echo "-----------------------支付成功案例----------------------";
echo '<br/>';
echo "卡号：4000 0000 0000 0002 或者 5200 0000 0000 0007";
echo '<br/>';
echo "有效期：12/30";
echo '<br/>';
echo "cvv：123";
echo '<br/>';
echo "-----------------------支付失败案例----------------------";
echo '<br/>';
echo "卡号：4000 0000 1000 1112";
echo '<br/>';
echo "有效期：11/20";
echo '<br/>';
echo "cvv：123";
echo '<br/>';
echo "=================================================================================";
echo '<br/>';
echo "<b>第四步 在浏览器输入支付信息，支付成功后,商户在支付页面根据支付结果报文，跳转支付成功地址，详见redirect_url</b>";
echo '<br/>';
echo "=================================================================================";
echo '<br/>';
echo "<b>第五步 支付成功后会收到连连的异步通知，通知地址接口中传入，详见notification_url</b>";
echo '<br/>';
echo "=================================================================================";
echo '<br/>';
