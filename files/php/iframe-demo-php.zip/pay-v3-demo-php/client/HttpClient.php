<?php
namespace service;

use constants\PayConstant;
use LianLianSign;

class HttpClient
{
    /**
     * 发送请求
     * @param $url
     * @param $headers
     * @param $request
     * @return mixed
     */
    public function post($url, $headers, $request)
    {
        $header_res = [];
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($request));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HEADERFUNCTION,
            function ($curl, $header) use (&$header_res) {
                $len = strlen($header);
                $header = explode(':', $header, 2);
                if (count($header) < 2) // ignore invalid headers
                    return $len;

                $header_res[strtolower(trim($header[0]))][] = trim($header[1]);

                return $len;
            }
        );

        $response_data = curl_exec($curl);
        curl_close($curl);

        $response = json_decode($response_data, true);

        $return_code = $response['return_code'];
        if ($return_code != 'SUCCESS') {
            echo "<script>alert('warning! Pay Apply failed')</script>";
            return $response;
        }
        if (empty($header_res['signature'][0])) {
            echo "<script>alert('warning! no signature, contact LianLianPay')</script>";
            return $response;
        } else {
            $sign_tool = new LianLianSign();
            $check = $sign_tool->verifySignForLianlian($response, $header_res['signature'][0], PayConstant::$public_key);

            $payment_status = $response['order']['payment_data']['payment_status'];
            if (!$check) {
                echo "<script>alert('warning! signature error, contact LianLianPay')</script>";
            } else if ($payment_status == 'PS') {
                echo "<script>alert('Great! Payment successful')</script>";
            } else {
                //echo "<script>alert('Payment apply successful, wait for result notify or you can call the query endpoint.')</script>";
            }
        }
        return $response;
    }
}