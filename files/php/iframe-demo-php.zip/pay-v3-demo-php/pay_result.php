<?php

use constants\PayConstant;

require_once './constants/PayConstant.php';

$params = array();
foreach ($_GET as $key=>$value) {
    $params[$key] = $value;
}
foreach ($_POST as $key=>$value) {
    $params[$key] = $value;
}

echo json_encode($params);

$merchant_id = $params['merchant_id'];
$merchant_transaction_id = $params['merchant_transaction_id'];
$order_currency_code = $params['order_currency_code'];
$order_amount = $params['order_amount'];
$payment_status = $params['payment_status'];
$payment_amount = $params['payment_amount'];
$payment_currency_code = $params['payment_currency_code'];
$sign_type = $params['sign_type'];
$signature = $params['signature'];

if (!empty($signature)) {
    $sign_tool = new LianLianSign();
    $check_result = $sign_tool->verifySignForLianlian($params, $signature, PayConstant::$public_key);
    if (!$check_result) {
        echo '验签成功';
    } else {
        echo '验签失败';
    }
} else {
    echo '签名为空';
}
