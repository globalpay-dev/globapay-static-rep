<?php

include './model/Address.php';
include './model/Customer.php';
include './model/MerchantOrderInfo.php';
include './model/PayRequest.php';
include './model/Product.php';
include './model/Shipping.php';
include './constants/PayConstant.php';
include './utils/LianLianSign.php';
include './client/HttpClient.php';

use constants\PayConstant;
use model\Address;
use model\Customer;
use model\MerchantOrderInfo;
use model\PayRequest;
use model\Product;
use model\Shipping;
use service\HttpClient;

class IframeIcrPay
{

    private $http_client;

    public function __construct() {
        $this->http_client = new HttpClient();
    }

    public function pay() {
        $pay_request = new PayRequest();
        $pay_request->merchant_id = PayConstant::$merchant_id;
        $pay_request->biz_code = 'EC';
        $pay_request->country = 'HK';
        //支付成功后跳转地址，商户支付成功地址，这里模拟商户的支付成功页面
        //iframe模式可以不传
        $pay_request->redirect_url = PayConstant::$redirect_url;
        //支付成功后异步通知地址，这里模拟商户的接收异常通知请求  请看PayController#paymentSuccess
        $pay_request->notification_url = PayConstant::$notification_url;

        $time = date('YmdHis', time());
        $merchant_transaction_id = 'Test-' . $time;
        //商户发起支付交易的单号，保证唯一
        $pay_request->merchant_transaction_id = $merchant_transaction_id;
        //国际信用iframe 创单时需要手动制定支付方式inter_credit_card
        $pay_request->payment_method = 'inter_credit_card';
        $pay_request->front_model = 'IFRAME';
        $address = new Address();
        $address->city = 'Bangkok';
        $address->country = 'HK';
        $address->district = 'ruset';
        $address->line1 = 'Avenida Paulista';
        $address->line2 = 'test hong';
        $address->state = 'TH-19';
        $address->postal_code = '35627';
        $customer = new Customer();
        $customer->address = $address;
        $customer->customer_type = 'I';
        $customer->full_name = 'zhang san';
        $customer->first_name = 'zhang';
        $customer->last_name = 'san';
        $pay_request->customer = $customer;
        $product = new Product();
        $product->category = 'clothes';
        $product->name = 'female clothes';
        $product->price = '126.6';
        $product->product_id = '20001029398';
        $product->quantity = 1;
        $product->shipping_provider = 'DHL';
        $product->sku = 'sku-103848';
        $product->url = 'https://www.baidu.com';
        $products = array();
        $products[] = $product;
        $shipping = new Shipping();
        $shipping->address = $address;
        $shipping->name = 'zhangsan';
        $shipping->phone = '+55-2849384938';
        $shipping->cycle = '48h';

        $merchant_order_info = new MerchantOrderInfo();
        //此为商户系统的订单号，支付订单号和支付交易单号可以传一样
        $merchant_order_info->merchant_order_id = $merchant_transaction_id;
        $merchant_order_info->merchant_order_time = $time;
        $merchant_order_info->order_amount = '126.62';
        $merchant_order_info->order_currency_code = 'HKD';
        $merchant_order_info->order_description = '测试订单描述';
        $merchant_order_info->products = $products;
        $merchant_order_info->mcc = '5137';
        $merchant_order_info->shipping = $shipping;

        $pay_request->merchant_order = $merchant_order_info;
        $pay_url = sprintf(PayConstant::$pay_url, PayConstant::$merchant_id);
        $sign_tools = new LianLianSign();
        $signature = $sign_tools->signForLianlian($this->object_to_array($pay_request), PayConstant::$private_key);
        $header = array(
            'sign-type: ' . 'RSA',
            'timestamp: ' . date("YmdHis", time()),
            'timezone: ' . date_default_timezone_get(),
            'Content-Type: ' . 'application/json',
            'signature: '.$signature
        );
        echo '请求地址: ' . $pay_url . '<br/>';
        echo '请求参数: ' . str_replace('\\n', '<br/>', json_encode($pay_request, JSON_PRETTY_PRINT)) . '<br/>';
        echo '请求签名: ' . $signature . '<br/>';
        return $this->http_client->post($pay_url, $header, $pay_request);
    }

    public function object_to_array($obj){
        $_arr=is_object($obj)?get_object_vars($obj):$obj;
        $arr = null;
        foreach($_arr as $key=>$val){
            $val=(is_array($val))||is_object($val)?$this->object_to_array($val):$val;
            $arr[$key]=$val;
        }
        return $arr;
    }

}