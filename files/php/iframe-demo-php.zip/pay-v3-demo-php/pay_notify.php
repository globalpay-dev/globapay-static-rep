<?php

use constants\PayConstant;

require_once './constants/PayConstant.php';

$notify_body = file_get_contents("php://input");
$signature = $_SERVER['HTTP_SIGNATURE'];

file_put_contents(PayConstant::$log_file, "$notify_body\n", FILE_APPEND);
file_put_contents(PayConstant::$log_file, "$signature\n", FILE_APPEND);

$notify_body = preg_replace('/:\s*([0-9]*\.?[0-9]+)/', ': "$1"', $notify_body);
$notifyMsg = json_decode($notify_body, true);

if (empty($signature)) {
    file_put_contents(PayConstant::$log_file, "no signature", FILE_APPEND);
    return http_response_code("401");
} else {
    $sign_tool = new LianLianSign();
    $check_result = $sign_tool->verifySignForLianlian($notifyMsg, $signature, PayConstant::$public_key);
    if (!$check_result) {
        file_put_contents(PayConstant::$log_file, "signature error", FILE_APPEND);
        return http_response_code("401");
    } else {
        $payment_status = $notifyMsg['payment_data']['payment_status'];
        if ($payment_status == 'PS') {
            file_put_contents(PayConstant::$log_file, "payment successful", FILE_APPEND);
        } else {
            file_put_contents(PayConstant::$log_file, "payment result incorrect", FILE_APPEND);
        }
    }
}
