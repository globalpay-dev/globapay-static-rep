<?php
namespace lianlianpay\v3sdk\model;

class Shipping
{
    public $name;
    public $first_name;
    public $last_name;
    public $phone;
    public $address;
    public $cycle;
}