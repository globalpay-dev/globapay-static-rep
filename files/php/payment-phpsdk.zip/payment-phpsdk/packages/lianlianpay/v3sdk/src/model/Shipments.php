<?php

namespace lianlianpay\v3sdk\model;

class Shipments
{
    public $carrier_code;
    public $tracking_no;
    public $country;
}