<?php
namespace lianlianpay\v3sdk\model;

class RequestRefundData
{
    public $refund_currency_code;
    public $refund_amount;
    public $card;
    public $reason;
}