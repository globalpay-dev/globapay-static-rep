<?php

namespace lianlianpay\v3sdk\model;

class ShippingUploadRequest
{
    public $shipments;
    public $merchant_id;
    public $merchant_transaction_id;
}