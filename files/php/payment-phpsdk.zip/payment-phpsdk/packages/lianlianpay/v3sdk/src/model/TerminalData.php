<?php
namespace lianlianpay\v3sdk\model;

class TerminalData
{
    public $user_order_ip;
    public $user_client_mode;
    public $user_client_app_type;
    public $user_client_android_imei;
    public $user_client_android_sim_id;
    public $user_client_ios_machine_id;
}