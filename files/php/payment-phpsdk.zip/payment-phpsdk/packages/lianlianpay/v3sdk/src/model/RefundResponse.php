<?php
namespace lianlianpay\v3sdk\model;

class RefundResponse
{
    public $ll_transaction_id;
    public $merchant_transaction_id;
    public $original_transaction_id;
    public $refund_data;
}