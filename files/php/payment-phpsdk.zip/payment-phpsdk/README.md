# php-sdk使用文档
## 一、简介
适用于 PHP 7.0 以上的开发环境。
## 二、使用说明
概述：连连支付将与服务端交互的接口（OpenAPI）封装在开发工具包（SDK）中，开发者无需自行实现同服务端交互的复杂逻辑，直接将 SDK 导入自己的工程后，通过 OpenAPI 的示例代码实现同连连支付服务端的交互
### 适用人群
本文阅读对象：商户系统集成连连支付涉及的技术架构师，研发工程师，测试工程师，系统运维工程师等相关人员
## 三、支持接口
提供创单支付、退款、支付查询、退款查询、物流上传、支付取消、获取iframe支付token方法、支付/退款通知接口，开发者只需修改部分参数即可调用

目前已支持的接口，如api文档所示 ：
https://doc.lianlianpay.com/doc-api/open-api/pay-order

## 四、开发准备
### 下载并安装Composer
#### windows平台  
下载地址（windows环境下安装composer-setup.exe）：https://getcomposer.org/download/  
#### linux平台  
使用以下命令来安装：
```php
#php -r "copy('https://install.phpcomposer.com/installer', 'composer-setup.php');"
#php composer-setup.php
All settings correct for using Composer
Downloading...
Composer (version 1.6.5) successfully installed to: /root/composer.pharUse it: php composer.phar
//移动 composer.phar，这样 composer 就可以进行全局调用：
# mv composer.phar /usr/local/bin/composer
//更新 composer：
# composer selfupdate
```

### 安装sdk
```
查看在线文档，选择资源下载栏，将对接SDK-php直接下载到本地进行使用
如有版本升级，在当前项目目录下，执行如下命令
composer require lianlianpay/v3sdk:1.0.0（1.0.0为版本号）  
composer dump-autoload
```
### 修改参数
需要修改：商户号、连连公钥、商户私钥、环境设置  
开发准备工作参数示例
```php
//配置信息
//二级商户号,若有二级商户号必填
public static $sub_merchant_id = '请填写二级商户号';
//为true时，为沙箱环境，false和默认不填时，为生产环境
public static $sandbox = true;
public static $merchant_id = '请填写商户号';
public static $public_key ='请填写连连公钥'
public static $private_key='请填写商户私钥'
```
### 调用环境
调用示例
```php
<?php
use demo\PayConstant;
use \lianlianpay\v3sdk\core\PaySDK;

$pay_sdk = PaySDK::getInstance();
//调用环境
$pay_sdk->init(PayConstant::$sandbox);
$demo = new \demo\Demo();
//调用方法
$demo->pay();

```
备注：商户号、连连公钥、商户私钥等参数统一封装在示例代码（demo包）中
## 五、SDK 调用示例代码
LianLianpay SDK 集成说明:SDK 已经对加签验签逻辑做了封装，使用 SDK 时传入商户公钥等内容可直接通过 SDK 自动进行加验签，签名方法：加签验签详情参见https://doc.lianlianpay.com/pay-guide/dev-ready/rule

### 创单支付调用示例
代码示例
```php
//创单支付
public function pay() {
    //入参
    $pay_request = new PayRequest();
    //请求入参,参考api文档：https://doc.lianlianpay.com/doc-api/open-api/pay-order
    
    $payment = new Payment();
    //调用paymet的pay方法，返回参数
    $pay_response = $payment->pay($pay_request, PayConstant::$private_key, PayConstant::$public_key);
    
    //可选转换为json字符串格式，将返回参数打印在日志中
    $pay_response_json = json_encode($pay_response);
    //将返回参数打印在日志
    file_put_contents(PayConstant::$log_file, "pay_response=$pay_response_json\n", FILE_APPEND);
}
```

### 退款调用示例
代码示例
```php
public function refund() {
    //入参
    $refund_request = new RefundRequest();
    //请求入参，参考api文档：https://doc.lianlianpay.com/doc-api/open-api/refund
    
    //调用refund的refund方法，返回参数
    $refund = new Refund();
    $refund_response = $refund->refund($refund_request, PayConstant::$private_key, PayConstant::$public_key);
}
```
### 支付结果查询调用示例
代码示例
```php
//查询支付结果
public function pay_query(){
    //请求入参，参考api文档：https://doc.lianlianpay.com/doc-api/open-api/pay-result
    
    //调用payment的query方法，返回参数 
    $payment = new Payment();
    $pay_query_response = $payment->pay_query(PayConstant::$merchant_id, $merchant_transaction_id,PayConstant::$private_key,PayConstant::$public_key);
}
```
### 退款结果查询调用示例
代码示例
```php
//查询退款结果
public function refund_query(){
    //请求入参，参考api文档：https://doc.lianlianpay.com/doc-api/open-api/refund-result
    
    //调用payment的query方法，返回参数 
    $refund = new Refund();
    $refund_query_response = $refund->refund_query($merchant_id, $merchant_transaction_id,PayConstant::$private_key,PayConstant::$public_key);
}
```

### 支付取消调用示例
代码示例
```php
//支付取消
public function pay_cancel(){
    //请求入参，参考api文档：https://doc.lianlianpay.com/doc-api/open-api/pay-cancel
    
    //调用payment的pay_cancel方法，返回参数 
    $payment = new Payment();
    $pay_cancel_response = $payment->pay_cancel(PayConstant::$merchant_id, $merchant_transaction_id,PayConstant::$private_key,PayConstant::$public_key);
}
```

### 物流上传调用示例
代码示例
```php
//物流上传
public function shipping_upload(){
    //入参
    $shippingUploadRequest = new ShippingUploadRequest();
    //请求入参，参考api文档：https://doc.lianlianpay.com/doc-api/open-api/logistics
    
    //调用shippingUpload的upload方法，返回参数 
    $shippingUpload = new ShippingUpload();
    $shippingUpload_response = $shippingUpload->upload($shippingUploadRequest,PayConstant::$private_key, PayConstant::$public_key);
}
```

### 获取iframe支付token调用示例
代码示例
```php
//获取iframe支付token
public function get_token(){
    //请求入参，参考api文档：https://doc.lianlianpay.com/doc-api/open-api/get-token
    
    //调用payment的get_token方法，返回参数 
    $payment = new Payment();
    $pay_token_response = $payment->get_token(PayConstant::$merchant_id,PayConstant::$private_key,PayConstant::$public_key);
}
```

### 支付/退款结果通知调用示例
代码示例
```php
//支付/退款结果通知
/*
*参考api文档
*https://doc.lianlianpay.com/doc-api/open-news/pay-result
*https://doc.lianlianpay.com/doc-api/open-news/refund-result
*/

//调用notification的payment_notify方法   
public function payment_notify($notify_body, $signature, $public_key = ''){

    //方法内部进行验签，将notify_body进行排序并转换为json字符串格式
    $notify_data = json_decode($notify_body, true);
        
    //返回参数
    return $notify_data;
}

```





