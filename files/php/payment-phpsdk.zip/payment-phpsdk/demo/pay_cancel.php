<?php
require '../vendor/autoload.php';
require './Demo.php';

use \lianlianpay\v3sdk\core\PaySDK;

$pay_sdk = PaySDK::getInstance();
$pay_sdk->init(true);

$demo = new \demo\Demo();
$demo->pay_cancel();
