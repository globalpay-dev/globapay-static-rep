<?php
namespace demo;

require './PayConstant.php';

use lianlianpay\v3sdk\model\Address;
use lianlianpay\v3sdk\model\Card;
use lianlianpay\v3sdk\model\Customer;
use lianlianpay\v3sdk\model\MerchantOrder;
use lianlianpay\v3sdk\model\PayRequest;
use lianlianpay\v3sdk\model\Product;
use lianlianpay\v3sdk\model\RefundRequest;
use lianlianpay\v3sdk\model\RequestPaymentData;
use lianlianpay\v3sdk\model\RequestRefundData;
use lianlianpay\v3sdk\model\Shipping;
use lianlianpay\v3sdk\model\Shipments;
use lianlianpay\v3sdk\model\ShippingUploadRequest;

use lianlianpay\v3sdk\service\Payment;
use lianlianpay\v3sdk\service\Refund;
use lianlianpay\v3sdk\service\ShippingUpload;

class Demo
{
    //创单支付
    public function pay() {
        $pay_request = new PayRequest();
        $pay_request->merchant_id = PayConstant::$merchant_id;
        //二级商户号,若有二级商户号必填
        //$pay_request->sub_merchant_id= PayConstant::$sub_merchant_id;
        $pay_request->biz_code = 'EC';
        $pay_request->country = 'BR';
        //支付成功后跳转地址，商户支付成功地址，这里模拟商户的支付成功页面
        //支付成功后，用户页面回跳URL地址;收银台方式接入必填，Iframe必填，api国际信用卡、本地必填。
        $redirect_url='https://www.yezhou.cc/callback/redirect.php';
        $pay_request->redirect_url = $redirect_url;
        //支付成功后异步通知地址，这里模拟商户的接收异常通知请求  请看PayController#paymentSuccess
        $notification_url='https://www.yezhou.cc/callback/notify.php';
        $pay_request->notification_url = $notification_url;

        $time = date('YmdHis', time());
        $merchant_transaction_id = 'Test-' . $time;
        //商户发起支付交易的单号，保证唯一
        $pay_request->merchant_transaction_id = $merchant_transaction_id;
        //国际信用iframe 创单时需要手动制定支付方式inter_credit_card
        $pay_request->payment_method = 'inter_credit_card';
        //$pay_request->front_model = 'IFRAME';
        $address = new Address();
        $address->city = 'JIS';
        $address->country = 'US';
        $address->line1 = 'CNO';
        $address->line2 = 'BEIJINGOOQ';
        $address->state = 'TH-19';
        $address->postal_code = '35627';
        $customer = new Customer();
        $customer->address = $address;
        $customer->customer_type = 'I';
        $customer->full_name = 'bac test';
        $customer->first_name = 'Sllo';
        $customer->last_name = 'test';
        $pay_request->customer = $customer;
        $product = new Product();
        $product->category = 'clothes';
        $product->name = 'female clothes';
        $product->price = '126.6';
        $product->product_id = '20001029398';
        $product->quantity = 1;
        $product->shipping_provider = 'DHL';
        $product->sku = 'M1120';
        $product->url = 'https://www.taobao.com';
        $products = array();
        $products[] = $product;
        $shipping = new Shipping();
        $shipping->address = $address;
        $shipping->name = 'zhangsan';
        $shipping->phone = '+55-2849384938';
        $shipping->cycle = '48h';

        $merchant_order = new MerchantOrder();
        //此为商户系统的订单号，支付订单号和支付交易单号可以传一样
        $merchant_order->merchant_order_id = $merchant_transaction_id;
        $merchant_order->merchant_order_time = $time;
        $merchant_order->order_amount = '126.62';
        $merchant_order->order_currency_code = 'HKD';
        $merchant_order->order_description = '测试订单描述';
        $merchant_order->products = $products;
        //$merchant_order->mcc = '5137';
        $merchant_order->shipping = $shipping;

        $pay_request->merchant_order = $merchant_order;

        $payment_data = new RequestPaymentData();

        $card = new Card();
        $card->card_no = '4761739000060016';
        $card->card_brand = 'visa';
        $card->card_expiration_month = '02';
        $card->card_expiration_year = '26';
        $card->cvv = '642';
        $card->holder_name = 'YU DAN';
        //$card->card_token = '******';
        $payment_data->card = $card;
        $pay_request->payment_data = $payment_data;

        $pay_request_json = json_encode($pay_request);
        file_put_contents(PayConstant::$log_file, "pay_request=$pay_request_json\n", FILE_APPEND);

        $payment = new Payment();
        $pay_response = $payment->pay($pay_request, PayConstant::$private_key, PayConstant::$public_key);

        $pay_response_json = json_encode($pay_response);
        file_put_contents(PayConstant::$log_file, "pay_response=$pay_response_json\n", FILE_APPEND);
    }

    //退款
    public function refund() {
        $refund_request = new RefundRequest();
        $refund_request->merchant_id = PayConstant::$merchant_id;
        $refund_request->merchant_transaction_id = 'Test-20220112153723';
        $refund_request->original_transaction_id = 'Test-20220124153326';
        $refund_request->merchant_refund_time = '20220120014822';

        $notification_url = 'https://www.yezhou.cc/callback/notify.php';
        $refund_request->notification_url = $notification_url;

        $refund_data = new RequestRefundData();
        $refund_data->refund_amount = '10.0'; 
        $refund_data->refund_currency_code = 'HKD';
        $refund_data->reason = 'test';
        $refund_request->refund_data = $refund_data;

        file_put_contents(PayConstant::$log_file, "refund_request=". json_encode($refund_request) ."\n", FILE_APPEND);

        $refund = new Refund();
        $refund_response = $refund->refund($refund_request, PayConstant::$private_key, PayConstant::$public_key);

        file_put_contents(PayConstant::$log_file, "refund_response=$refund_response\n", FILE_APPEND);
    }

    //查询支付结果
    public function pay_query(){
        $payment = new Payment();
        $merchant_id = PayConstant::$merchant_id;
        $merchant_transaction_id = 'Test-20220114112923';

        $private_key = PayConstant::$private_key;
        $public_key = PayConstant::$public_key;

        $payment->pay_query($merchant_id,$merchant_transaction_id,$private_key,$public_key);
        $pay_query_response = $payment->pay_query(PayConstant::$merchant_id,'Test-20220114112923',PayConstant::$private_key,PayConstant::$public_key);
        $pay_query_response_json = json_encode($pay_query_response);
        file_put_contents(PayConstant::$log_file, "pay_query_response=$pay_query_response_json\n", FILE_APPEND);
    }

    //查询退款结果
    public function refund_query(){
        $refund = new Refund();
        $merchant_id = PayConstant::$merchant_id;
        $merchant_transaction_id = 'Test-20220114152923';

        $private_key = PayConstant::$private_key;
        $public_key = PayConstant::$public_key;
       // $refund->refund_query($merchant_id,$merchant_transaction_id,$private_key,$public_key);
        $refund_query_response = $refund->refund_query($merchant_id, $merchant_transaction_id,PayConstant::$private_key,PayConstant::$public_key);
        $refund_query_response_json = json_encode($refund_query_response);
        file_put_contents(PayConstant::$log_file, "refund_query_response=$refund_query_response_json\n", FILE_APPEND);
    }

    //支付取消
    public function pay_cancel(){
        $payment = new Payment();
        $merchant_id = PayConstant::$merchant_id;
        $merchant_transaction_id = 'Test-20220118182346';

        $private_key = PayConstant::$private_key;
        $public_key = PayConstant::$public_key;

        $payment->pay_cancel($merchant_id,$merchant_transaction_id,$private_key,$public_key);
        $pay_cancel_response = $payment->pay_cancel(PayConstant::$merchant_id,'Test-20220118182346',PayConstant::$private_key,PayConstant::$public_key);
        $pay_cancel_response_json = json_encode($pay_cancel_response);
        file_put_contents(PayConstant::$log_file, "pay_cancel_response=$pay_cancel_response_json\n", FILE_APPEND);
    }

    //查询iframe支付token
    public function get_token(){
        $payment = new Payment();
        $merchant_id = PayConstant::$merchant_id;

        $private_key = PayConstant::$private_key;
        $public_key = PayConstant::$public_key;

        $payment->get_token($merchant_id,$private_key,$public_key);
        $pay_token_response = $payment->get_token(PayConstant::$merchant_id,PayConstant::$private_key,PayConstant::$public_key);
        $pay_token_response_json = json_encode($pay_token_response);
        file_put_contents(PayConstant::$log_file, "pay_token_response=$pay_token_response_json\n", FILE_APPEND);
    }

    //物流上传
    public function shipping_upload(){
        $merchant_id = PayConstant::$merchant_id;
        $merchant_transaction_id = '202107150554289088';

        $private_key = PayConstant::$private_key;
        $public_key = PayConstant::$public_key;

        $shipment = new Shipments();
        $shipment->carrier_code = 'DHL';
        $shipment->tracking_no = '210714100227505217';
        $shipments = [$shipment];

        $shippingUploadRequest = new ShippingUploadRequest();
        $shippingUploadRequest->shipments = $shipments;
        $shippingUploadRequest->merchant_id = $merchant_id;
        $shippingUploadRequest->merchant_transaction_id = $merchant_transaction_id;

        file_put_contents(PayConstant::$log_file, "shippingUploadRequest=".json_encode($shippingUploadRequest)."\n",FILE_APPEND);
        $shippingUpload = new ShippingUpload();
        $shippingUpload_response = $shippingUpload->upload($shippingUploadRequest,PayConstant::$private_key, PayConstant::$public_key);

        file_put_contents(PayConstant::$log_file, "shippingUpload_response=".json_encode($shippingUpload_response)."\n",FILE_APPEND);
    }
}