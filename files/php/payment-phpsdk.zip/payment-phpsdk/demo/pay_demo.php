<?php
require '../vendor/autoload.php';
require './Demo.php';

use demo\PayConstant;
use \lianlianpay\v3sdk\core\PaySDK;

$pay_sdk = PaySDK::getInstance();
$pay_sdk->init(PayConstant::$sandbox);


$demo = new \demo\Demo();
$demo->pay();
