<?php
require '../vendor/autoload.php';
use demo\PayConstant;
use lianlianpay\v3sdk\service\Notification;

require './PayConstant.php';


$notify_body = file_get_contents("php://input");
$signature = $_SERVER['HTTP_SIGNATURE'];

file_put_contents(PayConstant::$log_file, "notify_body=$notify_body\n", FILE_APPEND);
file_put_contents(PayConstant::$log_file, "signature=$signature\n", FILE_APPEND);

$notification = new Notification();
$notify_data = $notification->payment_notify($notify_body, $signature, \demo\PayConstant::$public_key);

//do not echo anything after
$payment_status = $notify_data['payment_data']['payment_status'];
if ($payment_status == 'PS') {
    // TODO update self system
}
