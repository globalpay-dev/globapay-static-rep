<?php
require './PayConstant.php';
require '../vendor/autoload.php';

use demo\PayConstant;
use lianlianpay\v3sdk\service\Notification;

$notify_body = file_get_contents("php://input");
$signature = $_SERVER['HTTP_SIGNATURE'];

file_put_contents(PayConstant::$log_file, "notify_body=".json_encode($notify_body)."\n", FILE_APPEND);
file_put_contents(PayConstant::$log_file, "signature=$signature\n", FILE_APPEND);

$notification = new Notification();
$notify_data = $notification->refund_notify($notify_body, $signature, \demo\PayConstant::$public_key);

//do not echo anything after
$refund_status = $notify_data['refund_data']['refund_status'];
if ($refund_status == 'RS') {
    // TODO update self system
}
