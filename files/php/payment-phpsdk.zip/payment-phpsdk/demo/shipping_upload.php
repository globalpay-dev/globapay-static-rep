<?php
use lianlianpay\v3sdk\core\PaySDK;

require '../vendor/autoload.php';
require './Demo.php';


$pay_sdk = PaySDK::getInstance();
$pay_sdk->init(true);

$demo = new \demo\Demo();
$demo->shipping_upload();