<?php
namespace demo;

class PayConstant
{
    /**
     * 支付成功后跳转地址，商户支付成功地址，这里模拟商户的支付成功页面
     * 127.0.0.1:8080调不通，需要改为商户的实际通知地址
     * 收银台模式需要制定该参数，iframe模式只需要商户在支付页面根据支付结果报文跳转相应地址
     */
    public static $redirect_url = 'https://www.yezhou.cc/callback/redirect.php';

    /**
     * 支付成功后异步通知地址，这里模拟商户的接收异常通知请求
     */
    public static $notification_url = 'https://www.yezhou.cc/callback/notify.php';

    public static $sandbox = true;

    //二级商户号,若有二级商户号必填
    public static $sub_merchant_id = '';

    public static $merchant_id = '202103310000636001';

    public static $public_key ='MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAklkdKRBjnfmUXZhGtMbDIxKmxRV/VbKahUmOOJzvx+oNDVd3cWnGxj5bJQrY/jn6LTtB5xlRG7VhJXSfqB1VZ9wIFWSnWFT6AYmXHmcb5cRVXTSp12+fKEibLr+fydGjRWsp6gdV0RDLgVmucyGi1RFtibmNk/lhD8d8IBapKC4YyGHXBsWrPEFCS+t5VwXo7TNkGHXDi0Nm0qgccEmJIzwEjAnrk05hetjPa4PN2cctLg7bZfkiSM7bZ4qfi5xMpT3ws+B25bKh3RFsqrQ5rQLpBEbMorG1ZfCuBhoxjVGHxmzk7UjcvGbTjNvLR4QsOIsLe11LXxQEfA2BCJLBeQIDAQAB';
    public static $private_key = 'MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCSWR0pEGOd+ZRdmEa0xsMjEqbFFX9VspqFSY44nO/H6g0NV3dxacbGPlslCtj+OfotO0HnGVEbtWEldJ+oHVVn3AgVZKdYVPoBiZceZxvlxFVdNKnXb58oSJsuv5/J0aNFaynqB1XREMuBWa5zIaLVEW2JuY2T+WEPx3wgFqkoLhjIYdcGxas8QUJL63lXBejtM2QYdcOLQ2bSqBxwSYkjPASMCeuTTmF62M9rg83Zxy0uDttl+SJIzttnip+LnEylPfCz4HblsqHdEWyqtDmtAukERsyisbVl8K4GGjGNUYfGbOTtSNy8ZtOM28tHhCw4iwt7XUtfFAR8DYEIksF5AgMBAAECggEAAb1TbmiGdps/2zjzJjTyntka6F7QC6m60njEWwHqi7rJeu4eOlfih/q3xKHzYFo6Eg2RQ/j2ENlAFVzkhPAMUta3teFjZ9Zivl/vTuo0169UwG3e0vO9tZHfXlfiw1hdk3apoeGCcKC9eoUhYLb2o4e4gJmXCDo/oBtj61G5owOcp6M9m+HyePL6AQ7j+2YI9+trVuk1bHYcTFap1y+RftnpIvRxZNuxI6L3WhBCEChEXW1e9Z/e1mCT6leJrOKZFRjcOTqXRdJczcORstnSN+8xmqm92zXL6ooR0egQN1pPBRI4b08gl6T8IUX3CBfaUG7lhu4Urcg4ez8HcT5McQKBgQDE7OlELm5Se8dDgaLUB5vwnh4kALrc1jIX4lBv2bS8yc2xRQeAHZvsG5r40kecO4NCXjYr2avYsICOc5l8iiMMyGvWa80Fv31oQn3Gl82o7JB9hdDALRddOf5nEo4OyS9oBASd84EWs/Yt/hzCPGpsByhFSkWf6zcun0fIRow4bQKBgQC+QBCliUnBnibePqbyxWKem9qrcewVzy6il0wdByptkSn5m0ao0F6o28GfDQozdBe1rMUrcRTwyM5eZX9tIudZmHw5zObpnprkxtGba3V+wfRhBmYamy4vT8V3RG2IgOvHO+uPwbqpMFe+xuj/0p1lZeWUoEwMxWUg9uULJ1PdvQKBgHQ2q+LE0+5xhcLc+k7OvsRdS8RLefthnOZjdLzNadAP+AepiSeeUaohEG/PCNu2c1vzZVyzdKrIXtWyet34V37vuFQuAixmOYgR1VAhvgj2sr6g/fSrp6Io223QkW1AZW2pEWB1l7TiN2IlGKu4I8Xk42sgzb32ffZRoXcbyxxxAoGBAIJAkGUVElcp9QhxspFBzFw07kg0zeK8nvwYQ7cYAddT7H4E7iKDzlsjYXOIVPSXRehPKgqs+B5GDOwZ510L6YKw4FQeUfWebgO1jyouLxoipjKLU/phRgSEQ/h889TiFwqnnoYkp6xP+bMWscz8IGCcm8re2FJiDvO7tWKmgUetAoGAddxIS0ksA2PEVGwIh8wlJOMQjiHkn4IGYvCFzxooIj1/sCxofQjfRY2/MPzYmCHrau261jslLyFiBVkc1okmq1BWaEwjn5A8eEnfznIkyNNfZTEUiymhh+ESqWg3gXSgsNLQL3Ng033DaHJC++FF6nCkA+KCnwAUeSAQf1i2GSE=';

    public static $log_file = 'log.txt';
}


