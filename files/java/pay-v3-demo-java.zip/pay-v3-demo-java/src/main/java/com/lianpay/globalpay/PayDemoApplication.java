package com.lianpay.globalpay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author yanggx
 */
@SpringBootApplication(scanBasePackages = {"com.lianpay.globalpay"})
public class PayDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(PayDemoApplication.class, args);
    }
}
