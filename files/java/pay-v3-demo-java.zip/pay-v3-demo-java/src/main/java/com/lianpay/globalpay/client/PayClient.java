package com.lianpay.globalpay.client;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.lianpay.globalpay.PayConfig;
import com.lianpay.globalpay.domain.ApiResult;
import com.lianpay.globalpay.domain.PayRequest;
import com.lianpay.globalpay.domain.PayResponse;
import com.lianpay.globalpay.domain.RefundRequest;
import com.lianpay.globalpay.domain.RefundResponse;
import com.lianpay.globalpay.utils.SignUtil;
import com.lianpay.globalpay.utils.TimeZoneUtil;

@Component
public class PayClient {
    @Autowired
    private PayConfig payConfig;
    private OkHttpClient okHttpClient = new OkHttpClient();

    public ApiResult<PayResponse> pay(PayRequest request, String timezone) throws Exception {
        String url = payConfig.getApiBaseUrl() + "/merchants/{0}/payments";
        PayConfig.MerchantConfig merchantConfig = payConfig.getMerchantConfig(request.getMerchantId());
        String signature = SignUtil.addSign(JSON.toJSONString(request), merchantConfig.getPrivateKey());
        String timestamp = TimeZoneUtil.getTimestampOfTimezone(timezone);
        MediaType mediaType = MediaType.parse("application/json;charset=utf-8");
        System.out.println("requet body:[" + JSON.toJSONString(request) + "], signature:[" + signature + "]");
        Request httpRequest = new Request.Builder().addHeader("sign-type", "RSA").addHeader("signature", signature)
                .addHeader("timestamp", timestamp).addHeader("timezone", timezone)
                .url(MessageFormat.format(url, request.getMerchantId())).post(RequestBody.create(mediaType, JSON.toJSONString(request)))
                .build();
        Response response = okHttpClient.newCall(httpRequest).execute();
        if (response == null) {
            throw new RuntimeException("no response");
        }
        String responseBody = response.body().string();
        String responseSignature = response.header("signature");
        if(responseSignature != null){
        	try {
                SignUtil.checkSign(responseSignature, responseBody, merchantConfig.getLlPublicKey());
            } catch (Exception e) {
                throw new RuntimeException("verify signature failed", e);
            }
        }
        System.out.println("response body:[" + responseBody + "] signature：[" + responseSignature + "]");
        return JSON.parseObject(responseBody,new TypeReference<ApiResult<PayResponse>>(){});
    }

    public ApiResult<PayResponse> payQuery(String merchantId, String merchantTransactionId, String timezone) throws Exception {
        String url = payConfig.getApiBaseUrl() + "/merchants/{0}/payments/{1}";
        PayConfig.MerchantConfig merchantConfig = payConfig.getMerchantConfig(merchantId);
        Map<String, String> params = new HashMap<>();
        params.put("merchant_id", merchantId);
        params.put("merchant_transaction_id", merchantTransactionId);
        String signature = SignUtil.addSign(JSON.toJSONString(params), merchantConfig.getPrivateKey());
        String timestamp = TimeZoneUtil.getTimestampOfTimezone(timezone);
        Request httpRequest = new Request.Builder().addHeader("sign-type", "RSA").addHeader("signature", signature)
                .addHeader("timestamp", timestamp).addHeader("timezone", timezone).addHeader("Content-Type", "application/json;charset=utf-8")
                .url(MessageFormat.format(url, merchantId, merchantTransactionId)).get().build();
        Response httpResponse = okHttpClient.newCall(httpRequest).execute();
        if (httpResponse == null) {
            throw new RuntimeException("no response");
        }
        String responseSignature = httpResponse.header("signature");
        String responseBody = httpResponse.body().string();
        if(responseSignature != null){
        	try {
                SignUtil.checkSign(responseSignature, responseBody, merchantConfig.getLlPublicKey());
            } catch (Exception e) {
                throw new RuntimeException("verify signature failed");
            }
        }
        System.out.println("response body:[" + responseBody + "] signature：[" + responseSignature + "]");
        return JSON.parseObject(responseBody,new TypeReference<ApiResult<PayResponse>>(){});
    }

    public RefundResponse refund(RefundRequest request, String timezone) throws Exception {
        String url = payConfig.getApiBaseUrl() + "/merchants/{0}/payments/{1}/refunds";
        PayConfig.MerchantConfig merchantConfig = payConfig.getMerchantConfig(request.getMerchantId());
        String signature = SignUtil.addSign(JSON.toJSONString(request), merchantConfig.getPrivateKey());
        String timestamp = TimeZoneUtil.getTimestampOfTimezone(timezone);
        MediaType mediaType = MediaType.parse("application/json;charset=utf-8");
        System.out.println("requet body:[" + JSON.toJSONString(request) + "], signature: " + signature);
        Request httpRequest = new Request.Builder().addHeader("sign-type", "RSA").addHeader("signature", signature)
                .addHeader("timestamp", timestamp).addHeader("timezone", timezone)
                .url(MessageFormat.format(url, request.getMerchantId(), request.getOriginalTransactionId())).post(RequestBody.create(mediaType, JSON.toJSONString(request)))
                .build();
        Response response = okHttpClient.newCall(httpRequest).execute();
        RefundResponse refundResponse = null;
        if (response == null) {
            throw new RuntimeException("no response");
        }
        String responseBody = response.body().string();
        String responseSignature = response.header("signature");
        try {
            SignUtil.checkSign(responseSignature, responseBody, merchantConfig.getLlPublicKey());
        } catch (Exception e) {
            throw new RuntimeException("verify signature failed");
        }
        System.out.println("response body:[" + responseBody + "]");
        refundResponse = JSON.parseObject(responseBody, RefundResponse.class);
        return refundResponse;
    }

    public RefundResponse refundQuery(String merchantId, String merchantTransactionId, String timezone) throws Exception {
        String url = payConfig.getApiBaseUrl() + "/merchants/{0}/refunds/{1}";
        PayConfig.MerchantConfig merchantConfig = payConfig.getMerchantConfig(merchantId);
        Map<String, String> params = new HashMap<>();
        params.put("merchant_id", merchantId);
        params.put("merchant_transaction_id", merchantTransactionId);
        String signature = SignUtil.addSign(JSON.toJSONString(params), merchantConfig.getPrivateKey());
        String timestamp = TimeZoneUtil.getTimestampOfTimezone(timezone);
        Request httpRequest = new Request.Builder().addHeader("sign-type", "RSA").addHeader("signature", signature)
                .addHeader("timestamp", timestamp).addHeader("timezone", timezone).addHeader("Content-Type", "application/json;charset=utf-8")
                .url(MessageFormat.format(url, merchantId, merchantTransactionId)).get().build();
        Response httpResponse = okHttpClient.newCall(httpRequest).execute();
        if (httpResponse == null) {
            throw new RuntimeException("no response");
        }
        String responseSignature = httpResponse.header("signature");
        String responseBody = httpResponse.body().string();
        try {
            SignUtil.checkSign(responseSignature, responseBody, merchantConfig.getLlPublicKey());
        } catch (Exception e) {
            throw new RuntimeException("verify signature failed");
        }
        System.out.println("response body:[" + responseBody + "]");
        RefundResponse refundResponse = JSON.parseObject(responseBody, RefundResponse.class);
        return refundResponse;
    }
}
