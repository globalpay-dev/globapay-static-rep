package com.lianpay.globalpay.domain;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.math.BigDecimal;

public class RefundRequestRefundData implements Serializable {
	private static final long serialVersionUID = 112131212L;
	@JSONField(name = "refund_currency_code")
    @JsonProperty("refund_currency_code")
    private String refundCurrencyCode;
	@JSONField(name = "refund_amount")
    @JsonProperty("refund_amount")
    private BigDecimal refundAmount;
	@JSONField(name = "reason")
    @JsonProperty("reason")
    private String reason;
	@JSONField(name = "card")
    @JsonProperty("card")
    private CardInfo card;

    public String getRefundCurrencyCode() {
        return refundCurrencyCode;
    }

    public void setRefundCurrencyCode(String refundCurrencyCode) {
        this.refundCurrencyCode = refundCurrencyCode;
    }

    public BigDecimal getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(BigDecimal refundAmount) {
        this.refundAmount = refundAmount;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public CardInfo getCard() {
        return card;
    }

    public void setCard(CardInfo card) {
        this.card = card;
    }
}
