package com.lianpay.globalpay.domain;

import java.io.Serializable;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PayResponse implements Serializable {
	private static final long serialVersionUID = 8891781782121L;
	@JSONField(name = "ll_transaction_id")
	@JsonProperty("ll_transaction_id")
    private String llTransactionId;
	@JSONField(name = "merchant_transaction_id")
	@JsonProperty("merchant_transaction_id")
    private String merchantTransactionId;
	@JSONField(name = "payment_url")
	@JsonProperty("payment_url")
    private String paymentUrl;
	@JSONField(name = "key")
	@JsonProperty("key")
	private String key;
	@JSONField(name = "payment_data")
	@JsonProperty("payment_data")
    private PaymentResponsePaymentData paymentData;
    
    public String getLlTransactionId() {
        return llTransactionId;
    }

    public void setLlTransactionId(String llTransactionId) {
        this.llTransactionId = llTransactionId;
    }

    public String getMerchantTransactionId() {
        return merchantTransactionId;
    }

    public void setMerchantTransactionId(String merchantTransactionId) {
        this.merchantTransactionId = merchantTransactionId;
    }

    public String getPaymentUrl() {
        return paymentUrl;
    }

    public void setPaymentUrl(String paymentUrl) {
        this.paymentUrl = paymentUrl;
    }

    public PaymentResponsePaymentData getPaymentData() {
        return paymentData;
    }

    public void setPaymentData(PaymentResponsePaymentData paymentData) {
        this.paymentData = paymentData;
    }

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
}
