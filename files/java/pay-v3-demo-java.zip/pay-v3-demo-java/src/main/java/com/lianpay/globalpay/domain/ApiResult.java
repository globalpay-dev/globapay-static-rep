package com.lianpay.globalpay.domain;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author zhanghao003  
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResult<T extends Serializable> implements Serializable {
	private static final long serialVersionUID = 112131212L;
    /**
     * 业务状态码
     */
    @JsonProperty(value = "return_code")
    @JSONField(name = "return_code")
    private String returnCode;

    /**
     * 消息
     */
    @JsonProperty(value = "return_message")
    @JSONField(name = "return_message")
    private String returnMessage;
    
    /**
     * 拒绝编码
     *
     * @see DeclineCodeEnum#getCode()
     */
    @JsonProperty(value = "decline_code")
    @JSONField(name = "decline_code")
    private String declineCode;

    /**
     * 调用链ID, 用于定位问题
     */
    @JsonProperty(value = "trace_id")
    @JSONField(name = "trace_id")
    private String traceId;

    /**
     * 响应的数据
     */
    @JsonProperty(value = "order")
    @JSONField(name = "order")
    private T order;

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
