package com.lianpay.globalpay.enums;

public enum SignTypeEnum {

    MD5,
    RSA,
    HMAC;

    public static SignTypeEnum getInstanceByCode(String code) {

        for (SignTypeEnum instance : SignTypeEnum.values()) {
            if (instance.name().equals(code)) {
                return instance;
            }
        }
        return null;
    }
}
