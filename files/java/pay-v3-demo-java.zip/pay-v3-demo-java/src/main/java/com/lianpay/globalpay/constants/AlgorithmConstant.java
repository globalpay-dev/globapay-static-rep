package com.lianpay.globalpay.constants;

/**
 *
 * @author yanggx
 * @date 2017/8/7
 */
public class AlgorithmConstant {
    public final static String MD5_WITH_RSA = "MD5withRSA";

    public final static String SHA1_WITH_RSA = "SHA1withRSA";

    public final static String SHA256_WITH_HMAC = "HmacSHA256";
    public final static String SHA512_WITH_HMAC = "HmacSHA512";
    public final static String SHA1_WITH_HMAC = "HmacSHA1";
    public final static String MD5_WITH_HMAC = "HmacMD5";
}
