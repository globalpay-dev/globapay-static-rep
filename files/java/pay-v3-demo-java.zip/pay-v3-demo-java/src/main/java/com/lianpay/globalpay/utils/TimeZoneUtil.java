package com.lianpay.globalpay.utils;

import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;

public final class TimeZoneUtil {

	public final static Map<String, DateTimeFormatter> FORMATTERS = new ConcurrentHashMap<>();
	public final static String DEFAULT_PATTERN = "yyyy-MM-dd HH:mm:ss";
	public final static String PATTERN_YMDHMS = "yyyyMMddHHmmss";
	public final static String PATTERN_YMD = "yyyyMMdd";
	public final static String BRAZIL_TIME_ZONE = "Brazil/East";
    public final static String UTC_TIME_ZONE = "UTC";
	public final static String PATTERN_YMD000 = "yyyy-MM-dd 00:00:00";
	public final static long DAYToMILL = 24 * 60 * 60 * 1000;

	static {
		FORMATTERS.put(DEFAULT_PATTERN, DateTimeFormatter.ofPattern(DEFAULT_PATTERN));
		FORMATTERS.put(PATTERN_YMDHMS, DateTimeFormatter.ofPattern(PATTERN_YMDHMS));
		FORMATTERS.put(PATTERN_YMD, DateTimeFormatter.ofPattern(PATTERN_YMD));
		FORMATTERS.put(PATTERN_YMD000, DateTimeFormatter.ofPattern(PATTERN_YMD000));
	}
    
    /**
     * 获取制定时区当前时间的当天开始时间毫秒数
     * 把nowTimeMill 转换成 sourceId 时区对应的时间
     * 再获取改时间当天的其实日期
     * 获取日期的毫秒数
     * @author zhanghao003  
     * @param sourceId
     * @return  
     * @since JDK 1.8
     */
    public static long getStartTimeOfDay(String sourceId){
    	return getStartTimeOfDay(sourceId, System.currentTimeMillis());
    }
    
    /**
     * 获取制定时区制定时间的当天开始时间毫秒数
     * 把nowTimeMill 转换成 sourceId 时区对应的时间
     * 再获取改时间当天的其实日期
     * 获取日期的毫秒数
     * @author zhanghao003  
     * @param targetId
     * @param nowTimeMill
     * @return  
     * @since JDK 1.8
     */
    public static long getStartTimeOfDay(String targetId, long nowTimeMill){
    	if(targetId == null){
    		return -1;
    	}
    	ZoneId zoneId = ZoneId.of(targetId);
		Date now = new Date(nowTimeMill);
    	Instant instant = now.toInstant();
		LocalDateTime tzNow = LocalDateTime.ofInstant(instant, zoneId);
		LocalDate tzDate = LocalDate.of(tzNow.getYear(), tzNow.getMonthValue(), tzNow.getDayOfMonth());
		return tzDate.atStartOfDay(zoneId).toInstant().toEpochMilli();
    }
    
    /**
     *  计算当前时间到下个日期零点的差值
     * @author zhanghao003  
     * @param targetId
     * @return  
     * @since JDK 1.8
     */
    public static long calculatIntervalOfNowBetweenNextZeroPoint(String targetId){
    	return calculatIntervalOfNowBetweenNextZeroPoint(targetId, System.currentTimeMillis());
    }
    
    /**
     *  计算当前时间到下个日期零点的差值
     * @author zhanghao003  
     * @param zoneId
     * @param nowTimeMill
     * @return  
     * @since JDK 1.8
     */
    public static long calculatIntervalOfNowBetweenNextZeroPoint(String sourceId, long nowTimeMill){
    	if(sourceId == null){
    		return -1;
    	}
    	ZoneId zoneId = ZoneId.of(sourceId);
    	LocalDateTime tzNow = LocalDateTime.ofInstant(new Date(nowTimeMill).toInstant(), zoneId);
    	LocalDate tzDate = LocalDate.of(tzNow.getYear(), tzNow.getMonthValue(), tzNow.getDayOfMonth());
		long currentZeroTime = tzDate.atStartOfDay(zoneId).toInstant().toEpochMilli();
    	return DAYToMILL - (nowTimeMill - currentZeroTime);
    }
    
    /**
     * 计算制定时区当前时间的下个日期零点的时间毫秒
     * @author zhanghao003  
     * @param zoneId
     * @param nowTimeMill
     * @return  
     * @since JDK 1.8
     */
    public static long calculatIntervalOfStartDayTime(String sourceId, long nowTimeMill){
    	if(sourceId == null){
    		return -1;
    	}
    	ZoneId zoneId = ZoneId.of(sourceId);
    	LocalDateTime tzNow = LocalDateTime.ofInstant(new Date(nowTimeMill).toInstant(), zoneId);
    	LocalDate tzDate = LocalDate.of(tzNow.getYear(), tzNow.getMonthValue(), tzNow.getDayOfMonth());
		long currentZeroTime = tzDate.atStartOfDay(zoneId).toInstant().toEpochMilli();
    	return DAYToMILL + currentZeroTime;
    }

    public static String calculateDateAfterDays(Date date, String timezone, int days) {
		LocalDateTime localDateTime = LocalDateTime.ofInstant(date.toInstant(), ZoneId.of(timezone));
		localDateTime = localDateTime.plusDays(days);
		DateTimeFormatter dateTimeFormatter = FORMATTERS.get(PATTERN_YMD) == null ? DateTimeFormatter.ofPattern(PATTERN_YMD) : FORMATTERS.get(PATTERN_YMD);
		return localDateTime.format(dateTimeFormatter);
	}

	public static LocalDateTime calculateDateAfterTime(Date date, String timezone, int years, int months, int days) {
		LocalDateTime localDateTime = LocalDateTime.ofInstant(date.toInstant(), ZoneId.of(timezone));
		localDateTime = localDateTime.plusYears(years).plusMonths(months).plusDays(days);
		return localDateTime;
	}
    
	public static Date convertBrazilDateToUTC(String dateStr) {
		LocalDate brzDate = LocalDate.parse(dateStr);
		Instant instant = brzDate.atStartOfDay(ZoneId.of(BRAZIL_TIME_ZONE)).toInstant();
		return Date.from(instant);
	}
	
	public static Date convertBrazilDateToUTC(String dateStr, String pattern) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		LocalDateTime localDateTime = LocalDateTime.parse(dateStr, formatter);
		Instant instant = localDateTime.atZone(ZoneId.of(BRAZIL_TIME_ZONE)).toInstant();
		return Date.from(instant);
	}
	
	public static String convertDatePattern(String dateStr, String sourcePattern, String targetPattern) {
		DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern(sourcePattern);
		LocalDate date = LocalDate.parse(dateStr, sourceFormatter);
		DateTimeFormatter targetFormatter = DateTimeFormatter.ofPattern(targetPattern);
		return date.format(targetFormatter);
	}

	public static Date timeStringConvertDate(String sourceTime, String sourcePattern, String sourceId) {
		if (StringUtils.isBlank(sourceTime) || StringUtils.isBlank(sourceId)) {
			return null;
		}
		//时间格式
		SimpleDateFormat inputFormat = new SimpleDateFormat(sourcePattern);
		TimeZone sourceTimeZone = TimeZone.getTimeZone(sourceId);
		inputFormat.setTimeZone(sourceTimeZone);
		try{
			return inputFormat.parse(sourceTime);
		}catch (ParseException e){
			return null;
		}
	}
    
    public static String timeConvert(String sourceTime, String sourceId,
                                     String targetId) {
        return timeConvert(sourceTime, sourceId, targetId, DEFAULT_PATTERN, DEFAULT_PATTERN);
    }
    
    public static String timeConvert(String sourceTime, String sourceId,
    		String targetId, String sourcePattern, String targetPattern) {
		//校验入参是否合法
		if (StringUtils.isBlank(sourceId) || StringUtils.isBlank(targetId) || sourceTime == null) {
			return null;
		}
		if(StringUtils.isBlank(sourceTime)){
			return sourceTime;
		}
		//时间格式
		SimpleDateFormat inputFormat = new SimpleDateFormat(sourcePattern);
		SimpleDateFormat outFormat = new SimpleDateFormat(targetPattern);
		TimeZone sourceTimeZone = TimeZone.getTimeZone(sourceId);
		inputFormat.setTimeZone(sourceTimeZone);
		Date date;
		try{
			date = inputFormat.parse(sourceTime);
		}catch (ParseException e){
			e.printStackTrace();
			return null;
		}
		TimeZone targetTimeZone = TimeZone.getTimeZone(targetId);
		outFormat.setTimeZone(targetTimeZone);
		String targetTime = outFormat.format(date);
		return targetTime;
	}

    public static String convertBrazilDate(Date sourceTime) {
        TimeZone timeZone = TimeZone.getTimeZone(BRAZIL_TIME_ZONE);
        SimpleDateFormat outFormat = new SimpleDateFormat(DEFAULT_PATTERN);
        outFormat.setTimeZone(timeZone);
        return outFormat.format(sourceTime);
    }

    public static String dateConvertStr(Date sourceTime, String targetId) {
        TimeZone timeZone = TimeZone.getTimeZone(targetId);
        SimpleDateFormat outFormat = new SimpleDateFormat(DEFAULT_PATTERN);
        outFormat.setTimeZone(timeZone);
        return outFormat.format(sourceTime);
    }

    public static String dateConvertStr(Date sourceTime, String timezone, String pattern) {
    	Instant instant = sourceTime.toInstant();
    	LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.of(timezone));
		DateTimeFormatter formatter = FORMATTERS.get(pattern) == null ? DateTimeFormatter.ofPattern(pattern) : FORMATTERS.get(pattern);
		return localDateTime.format(formatter);
	}

    public static String convertBrazilDate(Date sourceTime, String pattern) {
        TimeZone timeZone = TimeZone.getTimeZone("Brazil/East");
        SimpleDateFormat outFormat = new SimpleDateFormat(pattern);
        outFormat.setTimeZone(timeZone);
        return outFormat.format(sourceTime);
    }

    public static Date dateConvert(Date sourceTime, String targetId) {
        SimpleDateFormat format = new SimpleDateFormat(DEFAULT_PATTERN);
        String dateStr = dateConvertStr(sourceTime, targetId);
        try {
            return format.parse(dateStr);
        } catch (ParseException e) {
        }
        return null;
    }

    public static Date convertBrazilToUtcDate(String sourceDate) {
        LocalDate localDate = LocalDate.parse(sourceDate);
        Instant instant = localDate.atStartOfDay(ZoneId.of(BRAZIL_TIME_ZONE)).toInstant();
        return Date.from(instant);
    }

    public static Date convertBrazilToUtcDate(LocalDate sourceDate) {
        Instant instant = sourceDate.atStartOfDay(ZoneId.of(BRAZIL_TIME_ZONE)).toInstant();
        return Date.from(instant);
    }

    public static Date convertBrazilToUtcDateAndAddDays(String sourceDate, int days) {
        LocalDate localDate = LocalDate.parse(sourceDate);
        localDate = localDate.plusDays(days);
        Instant instant = localDate.atStartOfDay(ZoneId.of(BRAZIL_TIME_ZONE)).toInstant();
        return Date.from(instant);
    }

    public static String convertUtcToBrazilTime(Date date) {
        Instant instant = date.toInstant();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.of(BRAZIL_TIME_ZONE));
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return localDateTime.format(dateTimeFormatter);
    }

    public static String convertUtcToBrazilTime(Date date, String pattern) {
        Instant instant = date.toInstant();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.of(BRAZIL_TIME_ZONE));
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(pattern);
        return localDateTime.format(dateTimeFormatter);
    }

    public static String getTimestampOfTimezone(String timezone, String pattern) {
		LocalDateTime localDateTime = LocalDateTime.now(ZoneId.of(timezone));
		DateTimeFormatter dateTimeFormatter = FORMATTERS.get(pattern) == null ? DateTimeFormatter.ofPattern(pattern) : FORMATTERS.get(pattern);
		return localDateTime.format(dateTimeFormatter);
	}

	public static String getTimestampOfTimezone(String timezone) {
		return getTimestampOfTimezone(timezone, PATTERN_YMDHMS);
	}

	public static int getYearOfNow(String timezone) {
    	return LocalDateTime.now(ZoneId.of(timezone)).getYear();
	}

	public static int getMonthOfNow(String timezone) {
		return LocalDateTime.now(ZoneId.of(timezone)).getMonthValue();
	}

	public static int getDayOfMonthNow(String timezone) {
    	return LocalDateTime.now(ZoneId.of(timezone)).getDayOfMonth();
	}

	public static String getZeroPointOfDay(LocalDateTime localDateTime) {
		DateTimeFormatter dateTimeFormatter = FORMATTERS.get(PATTERN_YMD000);
		dateTimeFormatter = dateTimeFormatter == null ? DateTimeFormatter.ofPattern(PATTERN_YMD000) : dateTimeFormatter;
		return localDateTime.format(dateTimeFormatter);
	}

//    public static void main(String[] args) throws Exception {
//        String inputDate = "2017-11-30 04:20:00";
//        String outDate = TimeZoneUtil.timeConvert(inputDate, "Brazil/East", "UTC");
//        System.out.println("UTC:"+outDate);
//        System.out.println("Brazil/East:"+TimeZoneUtil.timeConvert(outDate, "UTC", "Brazil/East"));
//        Date inputD = DateUtil.parseDate("2017-11-30 04:20:00");
//        Date outD = TimeZoneUtil.timeConvert(inputD, "Brazil/East", "UTC");
//        System.out.println("UTC:"+DateUtil.parseDateToDatetimeStr(outD));
//        System.out.println("Brazil/East:"+DateUtil.parseDateToDatetimeStr(TimeZoneUtil.timeConvert(outD, "UTC", "Brazil/East")));
//    }
    

    public static void main(String[] args) {
    	Long l1 = calculatIntervalOfNowBetweenNextZeroPoint("America/Santiago");
    	Long l2 = calculatIntervalOfNowBetweenNextZeroPoint("Brazil/East");
    	System.out.println(l1 + "=?" + l2);
    	
		System.out.println("Brazil/East timestamp:" + TimeZoneUtil.getTimestampOfTimezone("Brazil/East"));
		System.out.println("date convert to Brazil/East:" + TimeZoneUtil.dateConvertStr(new Date(), "Brazil/East", "yyyyMMddHHmmss"));
		System.out.println("date after 0 day:" + TimeZoneUtil.calculateDateAfterDays(new Date(), "Brazil/East", 0));
		System.out.println("date after 1 day:" + TimeZoneUtil.calculateDateAfterDays(new Date(), "Brazil/East", 1));
		System.out.println("date after 3 day:" + TimeZoneUtil.calculateDateAfterDays(new Date(), "Brazil/East", 3));
		System.out.println(LocalDateTime.now().getYear() + "----" + LocalDateTime.now().getMonthValue() + "--------" + LocalDateTime.now().getDayOfMonth());
		System.out.println("1 month ago for brazil:" + TimeZoneUtil.calculateDateAfterTime(new Date(), "Brazil/East", 0, -1, 0));
	}
}
