package com.lianpay.globalpay.enums;

import java.util.*;

/**
 * 性别类型
 * @author yanggx
 */
public enum GenderEnum {

    MALE("male"),
    FEMALE("female"),
    UNDEFINED("undefined");
    
    private static Map<String, GenderEnum> NAME_MAP = new HashMap<String, GenderEnum>();
    private static Map<String, GenderEnum> CODE_MAP = new HashMap<String, GenderEnum>();
    private static List<GenderEnum> ALL_LIST;
    
    static {
    	List<GenderEnum> allList = new ArrayList<GenderEnum>();
        for (GenderEnum gender : GenderEnum.values()) {
        	NAME_MAP.put(gender.name(), gender);
            CODE_MAP.put(gender.code, gender);
            allList.add(gender);
        }
        ALL_LIST = Collections.unmodifiableList(allList);
    }
    
    GenderEnum(String code) {
        this.code = code;
    }
    
    private final String code;
    
    public static List<GenderEnum> toList() {
        return ALL_LIST;
    }
    
	public String getCode() {
		return code;
	}
	
	public static boolean contains(String value) {
        if (value == null) {
            return false;
        }
        if (NAME_MAP.containsKey(value.toUpperCase())){
        	return true;
        }
        if (CODE_MAP.containsKey(value.toLowerCase())){
        	return true;
        }
        return false;
    }
	
	public static GenderEnum getEnumByValue(String value) {
        if (value == null) {
            return null;
        }
        GenderEnum result = getEnumByName(value);
        if (result != null){
        	return result;
        }
        return getEnumByCode(value);
    }
    
    public static GenderEnum getEnumByName(String name) {
    	if(name != null){
    		return NAME_MAP.get(name.toUpperCase());
    	}
    	return null;
    }
    
    public static GenderEnum getEnumByCode(String code) {
    	if(code != null){
    		return CODE_MAP.get(code.toLowerCase());
    	}
    	return null;
    }
}
