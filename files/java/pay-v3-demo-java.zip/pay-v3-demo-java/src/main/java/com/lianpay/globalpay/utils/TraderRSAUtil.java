package com.lianpay.globalpay.utils;

import com.lianpay.globalpay.constants.AlgorithmConstant;
import org.apache.commons.codec.binary.Base64;
import org.springframework.util.StringUtils;

import javax.crypto.Cipher;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Map;

/**
 * RSA签名公共类
 *
 * @author shmily
 */
public final class TraderRSAUtil {

	private static String UTF_8 = "UTF-8";
    private static TraderRSAUtil instance = new TraderRSAUtil();

    private TraderRSAUtil() {

    }

    public static TraderRSAUtil getInstance() {
        return instance;
    }

    /**
     * 签名处理
     *
     * @param prikeyvalue：私钥
     * @param sign_str：签名源内容
     * @return
     */
    public static String sign(String prikeyvalue, String sign_str) throws InvalidKeySpecException, SignatureException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        try {
            PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(
                    Base64.decodeBase64(prikeyvalue.getBytes("UTF-8")));
            KeyFactory keyf = KeyFactory.getInstance("RSA");
            PrivateKey myprikey = keyf.generatePrivate(priPKCS8);
            // 用私钥对信息生成数字签名
            java.security.Signature signet = java.security.Signature
                    .getInstance(AlgorithmConstant.SHA1_WITH_RSA);
            signet.initSign(myprikey);
            signet.update(sign_str.getBytes("UTF-8"));
            byte[] signed = signet.sign();
            return new String(org.apache.commons.codec.binary.Base64.encodeBase64(signed));
        } catch (Exception e) {
            throw e;
        }
    }

    public static String signObject(String privateKey, Map<String, Object> srcMap) throws InvalidKeySpecException, SignatureException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        return signObject(privateKey, srcMap, AlgorithmConstant.SHA1_WITH_RSA);
    }

    public static String signObject(String privateKey, Map<String, Object> srcMap, String signAlg) throws NoSuchAlgorithmException, InvalidKeySpecException, UnsupportedEncodingException, InvalidKeyException, SignatureException {
        return sign(privateKey, composeSrcObject(srcMap), signAlg);
    }

    public static String sign(String privateKey, Map<String, String> srcMap) throws InvalidKeySpecException, SignatureException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        return sign(privateKey, srcMap, AlgorithmConstant.SHA1_WITH_RSA);
    }

    public static String sign(String privateKey, Map<String, String> srcMap, String signAlg) throws NoSuchAlgorithmException, InvalidKeySpecException, UnsupportedEncodingException, InvalidKeyException, SignatureException {
        return sign(privateKey, composeSrc(srcMap), signAlg);
    }

    public static String composeSrc(Map<String, String> srcMap) {
        Object[] keys = srcMap.keySet().toArray();
        Arrays.sort(keys);
        StringBuilder src = new StringBuilder();
        for (Object key : keys) {
            String k = (String) key;
            String value = srcMap.get(k);
            if (StringUtils.isEmpty(value)) {
                src.append("&").append(k).append("=").append(srcMap.get(k));
            }
        }
        String signText = StringUtils.isEmpty(src.toString()) ? "" : src.substring(1);
        return signText;
    }

    public static String composeSrcObject(Map<String, Object> srcMap) {
        Object[] keys = srcMap.keySet().toArray();
        Arrays.sort(keys);
        StringBuilder src = new StringBuilder();
        for (Object key : keys) {
            String k = (String) key;
            Object value = srcMap.get(k);
            if (value != null) {
                src.append("&").append(k).append("=").append(String.valueOf(value));
            }
        }
        String signText = StringUtils.isEmpty(src.toString()) ? "" : src.substring(1);
        return signText;
    }

    public static String sign(String privateKey, String src, String signAlg) throws InvalidKeySpecException, SignatureException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        if (StringUtils.isEmpty(signAlg)) {
            signAlg = AlgorithmConstant.SHA1_WITH_RSA;
        }
        if (AlgorithmConstant.SHA1_WITH_RSA.equals(signAlg)) {
            return sign(privateKey, src);
        }
        try {
            PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(
                    Base64.decodeBase64(privateKey.getBytes("UTF-8")));
            KeyFactory keyf = KeyFactory.getInstance("RSA");
            PrivateKey myprikey = keyf.generatePrivate(priPKCS8);
            // 用私钥对信息生成数字签名
            java.security.Signature signet = java.security.Signature
                    .getInstance(signAlg);
            signet.initSign(myprikey);
            signet.update(src.getBytes("UTF-8"));
            byte[] signed = signet.sign();
            return new String(org.apache.commons.codec.binary.Base64.encodeBase64(signed));
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * 签名验证
     *
     * @param pubkeyvalue：公钥
     * @param oid_str：内容
     * @param signed_str：签名结果串
     * @return
     */
    public static boolean checksign(String pubkeyvalue, String oid_str,
                                    String signed_str) throws InvalidKeySpecException, SignatureException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        try {
            X509EncodedKeySpec bobPubKeySpec = new X509EncodedKeySpec(
                    Base64.decodeBase64(pubkeyvalue.getBytes("UTF-8")));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PublicKey pubKey = keyFactory.generatePublic(bobPubKeySpec);
            byte[] signed = Base64.decodeBase64(signed_str.getBytes("UTF-8"));
            java.security.Signature signetcheck = java.security.Signature
                    .getInstance(AlgorithmConstant.SHA1_WITH_RSA);
            signetcheck.initVerify(pubKey);
            signetcheck.update(oid_str.getBytes("UTF-8"));
            return signetcheck.verify(signed);
        } catch (Exception e) {
            throw e;
        }
    }

    public static boolean checkSignObject(String publicKey, Map<String, Object> srcMap, String signedText) throws InvalidKeySpecException, SignatureException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        return checkSignObject(publicKey, srcMap, signedText, AlgorithmConstant.SHA1_WITH_RSA);
    }

    public static boolean checkSignObject(String publicKey, Map<String, Object> srcMap, String signedText, String signAlg) throws NoSuchAlgorithmException, InvalidKeySpecException, UnsupportedEncodingException, InvalidKeyException, SignatureException {
        return checkSign(publicKey, composeSrcObject(srcMap), signedText, signAlg);
    }

    public static boolean checkSign(String publicKey, Map<String, String> srcMap, String signedText) throws InvalidKeySpecException, SignatureException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        return checkSign(publicKey, srcMap, signedText, AlgorithmConstant.SHA1_WITH_RSA);
    }

    public static boolean checkSign(String publicKey, Map<String, String> srcMap, String signedText, String signAlg) throws NoSuchAlgorithmException, InvalidKeySpecException, UnsupportedEncodingException, InvalidKeyException, SignatureException {
        return checkSign(publicKey, composeSrc(srcMap), signedText, signAlg);
    }

    public static boolean checkSign(String publicKey, String src, String signedText, String signAlg) throws InvalidKeySpecException, SignatureException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        if (StringUtils.isEmpty(signAlg)) {
            signAlg = AlgorithmConstant.SHA1_WITH_RSA;
        }
        if (AlgorithmConstant.SHA1_WITH_RSA.equals(signAlg)) {
            return checksign(publicKey, src, signedText);
        }
        try {
            X509EncodedKeySpec bobPubKeySpec = new X509EncodedKeySpec(
                    Base64.decodeBase64(publicKey.getBytes("UTF-8")));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PublicKey pubKey = keyFactory.generatePublic(bobPubKeySpec);
            byte[] signed = Base64.decodeBase64(signedText.getBytes("UTF-8"));
            java.security.Signature signetcheck = java.security.Signature
                    .getInstance(signAlg);
            signetcheck.initVerify(pubKey);
            signetcheck.update(src.getBytes("UTF-8"));
            return signetcheck.verify(signed);
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * 获取密钥对
     *
     * @return 密钥对
     */
    public static KeyPair getKeyPair() throws Exception {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048);
        return generator.generateKeyPair();
    }
    
    public static void main(String[] agrs) throws Exception{
    	long time = System.currentTimeMillis();
    	for(int i=0; i<500; i++){
    		getKeyPair();
    	}
    	System.out.println(System.currentTimeMillis() - time);
    }

    /**
     * 获取私钥
     *
     * @param privateKey 私钥字符串
     * @return
     */
    public static PrivateKey getPrivateKey(String privateKey) throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        byte[] decodedKey = Base64.decodeBase64(privateKey.getBytes());
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(decodedKey);
        return keyFactory.generatePrivate(keySpec);
    }

    /**
     * 获取公钥
     *
     * @param publicKey 公钥字符串
     * @return
     */
    public static PublicKey getPublicKey(String publicKey) throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        byte[] decodedKey = Base64.decodeBase64(publicKey.getBytes());
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(decodedKey);
        return keyFactory.generatePublic(keySpec);
    }
    
    private static final int MAX_ENCRYPT_BLOCK = 245;

    private static final int MAX_DECRYPT_BLOCK = 256;

    public static String decrypt(String data, String privateKey) throws Exception {
    	return decrypt(data, getPrivateKey(privateKey));
    }

    public static String decrypt(String data, PrivateKey privateKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        byte[] dataBytes = Base64.decodeBase64(data);
        byte[] decryptedData = doFinal(cipher, dataBytes, MAX_DECRYPT_BLOCK);
        return new String(decryptedData, UTF_8);
    }
    
    public static String encrypt(String data, String publicKey) throws Exception {
    	return encrypt(data, getPublicKey(publicKey));
    }
    
    public static String encrypt(String data, PublicKey publicKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        byte[] dataBytes = data.getBytes(UTF_8);
        byte[] encryptedData = doFinal(cipher, dataBytes, MAX_ENCRYPT_BLOCK);
        return Base64.encodeBase64String(encryptedData);
    }
    
    private static byte[] doFinal(Cipher cipher, byte[] dataBytes, int maxBlockLength) throws Exception{
         int inputLen = dataBytes.length;
         ByteArrayOutputStream out = new ByteArrayOutputStream();
         int offset = 0;
         byte[] cache;
         int i = 0;
         try{
        	// 对数据分段解密
             while (inputLen - offset > 0) {
                 if (inputLen - offset > maxBlockLength) {
                     cache = cipher.doFinal(dataBytes, offset, maxBlockLength);
                 } else {
                     cache = cipher.doFinal(dataBytes, offset, inputLen - offset);
                 }
                 out.write(cache, 0, cache.length);
                 i++;
                 offset = i * maxBlockLength;
             }
             return out.toByteArray();
         }finally{
        	 try {
				out.close();
			} catch (Exception e) {
			}
         }
    }
}
