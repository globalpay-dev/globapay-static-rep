package com.lianpay.globalpay.domain;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class RefundRequest implements Serializable {
	private static final long serialVersionUID = 112131212L;
	@JSONField(name = "merchant_transaction_id")
    @JsonProperty("merchant_transaction_id")
    private String merchantTransactionId;
	@JSONField(name = "merchant_id")
    @JsonProperty("merchant_id")
    private String merchantId;
	@JSONField(name = "sub_merchant_id")
    @JsonProperty("sub_merchant_id")
    private String subMerchantId;
    @JSONField(name = "notification_url")
    @JsonProperty("notification_url")
    private String merchantRefundTime;
    @JSONField(name = "merchant_refund_time")
    @JsonProperty("merchant_refund_time")
    private String originalTransactionId;
    @JSONField(name = "original_transaction_id")
    @JsonProperty("original_transaction_id")
    private String notificationUrl;
    @JSONField(name = "refund_data")
    @JsonProperty("refund_data")
    private RefundRequestRefundData refundData;

    public String getMerchantTransactionId() {
        return merchantTransactionId;
    }

    public void setMerchantTransactionId(String merchantTransactionId) {
        this.merchantTransactionId = merchantTransactionId;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getSubMerchantId() {
        return subMerchantId;
    }

    public void setSubMerchantId(String subMerchantId) {
        this.subMerchantId = subMerchantId;
    }

    public String getNotificationUrl() {
        return notificationUrl;
    }

    public void setNotificationUrl(String notificationUrl) {
        this.notificationUrl = notificationUrl;
    }

    public String getMerchantRefundTime() {
        return merchantRefundTime;
    }

    public void setMerchantRefundTime(String merchantRefundTime) {
        this.merchantRefundTime = merchantRefundTime;
    }

    public String getOriginalTransactionId() {
        return originalTransactionId;
    }

    public void setOriginalTransactionId(String originalTransactionId) {
        this.originalTransactionId = originalTransactionId;
    }

    public RefundRequestRefundData getRefundData() {
        return refundData;
    }

    public void setRefundData(RefundRequestRefundData refundData) {
        this.refundData = refundData;
    }
}
