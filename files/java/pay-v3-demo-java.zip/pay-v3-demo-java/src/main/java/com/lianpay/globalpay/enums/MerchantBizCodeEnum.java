package com.lianpay.globalpay.enums;

/**
 * @author zhanghao003  
 */
public enum MerchantBizCodeEnum {
    /**
     * Sell physical goods
     */
    PHYSICAL_SALE("PHYSICAL_SALE", "实物商品销售"),
    /**
     * Sell virtual goods
     */
    VIRTUAL_SALE("VIRTUAL_SALE", "虚拟商品销售");

    private final String code;

    private final String desc;

    MerchantBizCodeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}
}
