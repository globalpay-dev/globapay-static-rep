package com.lianpay.globalpay.domain;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class RefundResponseRefundData implements Serializable {
	private static final long serialVersionUID = 112131212L;
	@JSONField(name = "refund_currency_code")
    @JsonProperty("refund_currency_code")
    private String refundCurrencyCode;
	@JSONField(name = "refund_amount")
    @JsonProperty("refund_amount")
    private String refundAmount;
    @JSONField(name = "settlement_currency_code")
    @JsonProperty("settlement_currency_code")
    private String settlementCurrencyCode;
    @JSONField(name = "settlement_amount")
    @JsonProperty("settlement_amount")
    private String settlementAmount;
    @JSONField(name = "actual_refund_currency_code")
    @JsonProperty("actual_refund_currency_code")
    private String actualRefundCurrencyCode;
    @JSONField(name = "actual_refund_amount")
    @JsonProperty("actual_refund_amount")
    private String actualRefundAmount;
    @JSONField(name = "refund_status")
    @JsonProperty("refund_status")
    private String refundStatus;
    @JSONField(name = "exchange_rate")
    @JsonProperty("exchange_rate")
    private String exchangeRate;
    @JSONField(name = "refund_time")
    @JsonProperty("refund_time")
    private String refundTime;
    @JSONField(name = "reason")
    @JsonProperty("reason")
    private String reason;
    @JSONField(name = "account_date")
    @JsonProperty("account_date")
    private String accountDate;

    public String getRefundCurrencyCode() {
        return refundCurrencyCode;
    }

    public void setRefundCurrencyCode(String refundCurrencyCode) {
        this.refundCurrencyCode = refundCurrencyCode;
    }

    public String getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(String refundAmount) {
        this.refundAmount = refundAmount;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getSettlementCurrencyCode() {
        return settlementCurrencyCode;
    }

    public void setSettlementCurrencyCode(String settlementCurrencyCode) {
        this.settlementCurrencyCode = settlementCurrencyCode;
    }

    public String getSettlementAmount() {
        return settlementAmount;
    }

    public void setSettlementAmount(String settlementAmount) {
        this.settlementAmount = settlementAmount;
    }

    public String getActualRefundCurrencyCode() {
        return actualRefundCurrencyCode;
    }

    public void setActualRefundCurrencyCode(String actualRefundCurrencyCode) {
        this.actualRefundCurrencyCode = actualRefundCurrencyCode;
    }

    public String getActualRefundAmount() {
        return actualRefundAmount;
    }

    public void setActualRefundAmount(String actualRefundAmount) {
        this.actualRefundAmount = actualRefundAmount;
    }

    public String getRefundStatus() {
        return refundStatus;
    }

    public void setRefundStatus(String refundStatus) {
        this.refundStatus = refundStatus;
    }

    public String getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(String exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public String getRefundTime() {
        return refundTime;
    }

    public void setRefundTime(String refundTime) {
        this.refundTime = refundTime;
    }

    public String getAccountDate() {
        return accountDate;
    }

    public void setAccountDate(String accountDate) {
        this.accountDate = accountDate;
    }
}
