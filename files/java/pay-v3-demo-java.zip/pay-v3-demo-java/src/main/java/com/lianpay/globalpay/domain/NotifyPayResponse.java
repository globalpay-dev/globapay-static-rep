package com.lianpay.globalpay.domain;

import java.io.Serializable;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

public class NotifyPayResponse implements Serializable {

	private static final long serialVersionUID = 7201022607578476492L;

    @JsonProperty(value = "code")
    @JSONField(name = "code")
    private String code;
    
    @JsonProperty(value = "message")
    @JSONField(name = "message")
    private String message;
    
    public NotifyPayResponse(){}
    
    public NotifyPayResponse(String code, String message) {
		super();
		this.code = code;
		this.message = message;
	}
}
