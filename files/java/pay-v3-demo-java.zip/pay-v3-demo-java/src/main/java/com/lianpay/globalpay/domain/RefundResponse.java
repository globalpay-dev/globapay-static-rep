package com.lianpay.globalpay.domain;

import java.io.Serializable;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

public class RefundResponse implements Serializable {
	private static final long serialVersionUID = 112131212L;
    @JSONField(name = "merchant_transaction_id")
    @JsonProperty("merchant_transaction_id")
    private String llTransactionId;
    @JSONField(name = "original_transaction_id")
    @JsonProperty("original_transaction_id")
    private String merchantTransactionId;
    @JSONField(name = "ll_transaction_id")
    @JsonProperty("ll_transaction_id")
    private String originalTransactionId;
    @JSONField(name = "refund_data")
    @JsonProperty("refund_data")
    private RefundResponseRefundData refundData;

    public String getMerchantTransactionId() {
        return merchantTransactionId;
    }

    public void setMerchantTransactionId(String merchantTransactionId) {
        this.merchantTransactionId = merchantTransactionId;
    }

    public String getOriginalTransactionId() {
        return originalTransactionId;
    }

    public void setOriginalTransactionId(String originalTransactionId) {
        this.originalTransactionId = originalTransactionId;
    }

    public String getLlTransactionId() {
        return llTransactionId;
    }

    public void setLlTransactionId(String llTransactionId) {
        this.llTransactionId = llTransactionId;
    }

    public RefundResponseRefundData getRefundData() {
        return refundData;
    }

    public void setRefundData(RefundResponseRefundData refundData) {
        this.refundData = refundData;
    }
}
