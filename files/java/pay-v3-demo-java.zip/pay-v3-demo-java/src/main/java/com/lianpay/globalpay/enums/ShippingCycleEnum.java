package com.lianpay.globalpay.enums;


import java.util.HashMap;
import java.util.Map;

/**
 * @author zhanghao003  
 */
public enum ShippingCycleEnum {

	/**
	 * 12h: Within 12 hours；
	 */
    h12("12h"),
    /**
	 * 24h: Within 24 hours；
	 */
    h24("24h"),
    /**
     * 48h: Within 48 hours；
     */
    h48("48h"),
    /**
     * 72h: Within 72 hours；
     */
    h72("72h"),
    /**
     * other: Over 72 hours
     */
    other("other");

    private static final Map<String, ShippingCycleEnum> CODE_MAP = new HashMap<>();

    static {
        for (ShippingCycleEnum cardBrandEnum : ShippingCycleEnum.values()) {
            CODE_MAP.put(cardBrandEnum.code, cardBrandEnum);
        }
    }

    public static final boolean contains(String value) {
        if (value != null) {
        	return CODE_MAP.containsKey(value.trim());
        }
        return false;
    }

    public static final ShippingCycleEnum getEnumByValue(String value) {
        if (value == null) {
            return null;
        }
        return getEnumByCode(value);
    }

    public static final ShippingCycleEnum getEnumByCode(String code) {
        if (code != null) {
            return CODE_MAP.get(code.trim());
        }
        return null;
    }

    String code;
    String name;

    ShippingCycleEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static void main(String[] args) {
        System.out.println(ShippingCycleEnum.getEnumByValue("visa"));
        System.out.println(ShippingCycleEnum.getEnumByValue("VISA"));
    }
}
