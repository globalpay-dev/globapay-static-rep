package com.lianpay.globalpay.enums;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * 国家枚举, 缩写、中文英文名称，编号及默认的时区
 *
 * @Author zhanghao003
 * @Email zhanghao003@yintong.com.cn
 * @Date Created at 17:32 2018/6/19
 * @Description
 */
public enum CountryEnum {
    AF("Afghanistan", "AF", "AFG", "阿富汗", "004", "Asia/Kabul"),
    AL("Albania", "AL", "ALB", "阿尔巴尼亚", "008", "Europe/Sofia"),
    AR("Argentina", "AR", "ARG", "阿根廷", "032", "America/Argentina/Buenos_Aires"),
    DZ("Algeria", "DZ", "DZA", "阿尔及利亚", "012", "Africa/Algiers"),
    AO("Angola", "AO", "AGO", "安哥拉", "024", "Africa/Algiers"),
    AW("Aruba", "AW", "ABW", "阿鲁巴", "533", "America/Aruba"),
    AU("Australia", "AU", "AUS", "澳大利亚", "036", "Australia/Canberra"),
    AT("Austria", "AT", "AUT", "奥地利", "040", "Europe/Vienna"),
    AZ("Azerbaijan", "AZ", "AZE", "阿塞拜疆", "031", "Asia/Tashkent"),
    BS("Bahamas The", "BS", "BHS", "巴哈马群岛", "044", "America/Santiago"),
    BH("Bahrain", "BH", "BHR", "巴林", "048", "Africa/Khartoum"),
    BD("Bangladesh", "BD", "BGD", "孟加拉国", "050", "Asia/Dhaka"),
    BB("Barbados", "BB", "BRB", "巴巴多斯", "052", "America/Santiago"),
    BY("Belarus", "BY", "BLR", "白俄罗斯", "112", "Europe/Moscow"),
    BE("Belgium", "BE", "BEL", "比利时", "056", "Europe/Brussels"),
    BZ("Belize", "BZ", "BLZ", "伯利兹", "084", "America/Mexico_City"),
    BJ("Benin", "BJ", "BEN", "贝宁", "204", "Europe/Madrid"),
    BM("Bermuda", "BM", "BMU", "百慕大", "060", "America/Montevideo"),
    BT("Bhutan", "BT", "BTN", "不丹", "064", "Asia/Dhaka"),
    BO("Bolivia", "BO", "BOL", "玻利维亚", "068", "America/Santiago"),
    BA("Bosnia and Herzegovina", "BA", "BIH", "波斯尼亚和黑塞哥维那", "070", "Europe/Bucharest"),
    BW("Botswana", "BW", "BWA", "博茨瓦纳", "072", "Europe/Bucharest"),
    BR("Brazil", "BR", "BRA", "巴西", "076", "Brazil/East"),
    VG("British Virgin Islands", "VG", "VGB", "英属维尔京群岛", "092", "America/Santiago"),
    BN("Brunei", "BN", "BRN", "文莱", "096", "Asia/Manila"),
    BG("Bulgaria", "BG", "BGR", "保加利亚", "100", "Europe/Sofia"),
    BF("Burkina Faso", "BF", "BFA", "布基纳法索", "854", "Europe/London"),
    BI("Burundi", "BI", "BDI", "布隆迪", "108", "Europe/Sofia"),
    KH("Cambodia", "KH", "KHM", "柬埔寨", "116", "Asia/Phnom_Penh"),
    CM("Cameroon", "CM", "CMR", "喀麦隆", "120", "Europe/Madrid"),
    CA("Canada", "CA", "CAN", "加拿大", "124", "America/Toronto"),
    CV("Cape Verde", "CV", "CPV", "佛得角", "132", ""),
    KY("Cayman Islands", "KY", "CYM", "开曼群岛", "136", ""),
    CF("Central African Republic", "CF", "CAF", "中非共和国", "140", ""),
    TD("Chad", "TD", "TCD", "乍得", "148", "Europe/Madrid"),
    CL("Chile", "CL", "CHL", "智利", "152", "America/Santiago"),
    CN("China", "CN", "CHN", "中国", "156", "Asia/Shanghai"),
    CX("Christmas Island", "CX", "CXR", "圣诞岛", "162", ""),
    CC("Cocos (Keeling)Islands", "CC", "CCK", "科科斯（基林）群岛", "166", ""),
    CO("Colombia", "CO", "COL", "哥伦比亚", "170", "America/Bogota"),
    KM("Comoros", "KM", "COM", "科摩罗", "174", ""),
    CG("Congo Republic of the", "CG", "刚果共和国", "COG", "178", ""),
    CK("Cook Islands", "CK", "COK", "库克群岛", "184", ""),
    CR("Costa Rica", "CR", "CRI", "哥斯达黎加", "188", ""),
    CI("Cote d'Ivoire", "CI", "CIV", "科特迪瓦", "384", ""),
    HR("Croatia", "HR", "HRV", "克罗地亚", "191", ""),
    CU("Cuba", "CU", "CUB", "古巴", "192", "America/Havana"),
    CY("Cyprus", "CY", "CYP", "塞浦路斯", "196", ""),
    CZ("Czech Republic", "CZ", "捷克共和国", "CZE", "203", ""),
    DK("Denmark", "DK", "DNK", "丹麦", "208", "Europe/Copenhagen"),
    DJ("Djibouti", "DJ", "DJI", "吉布提", "262", ""),
    DM("Dominica", "DM", "DMA", "多米尼加", "212", ""),
    DO("Dominican Republic", "DO", "DOM", "多米尼加共和国", "214", ""),
    EC("Ecuador", "EC", "ECU", "厄瓜多尔", "218", ""),
    EG("Egypt", "EG", "EGY", "埃及", "818", "Africa/Cairo"),
    SV("El Salvador", "SV", "SLV", "萨尔瓦多", "222", ""),
    GQ("Equatorial Guinea", "GQ", "GNQ", "赤道几内亚", "226", ""),
    ER("Eritrea", "ER", "ERI", "厄立特里亚", "232", ""),
    EE("Estonia", "EE", "EST", "爱沙尼亚", "233", ""),
    ET("Ethiopia", "ET", "ETH", "埃塞俄比亚", "231", "Africa/Addis_Ababa"),
    FK("Falkland Islands (Islas Malvinas)", "FK", "FLK", "福克兰群岛（马尔维纳斯群岛）", "238", ""),
    FO("Faroe Islands", "FO", "FRO", "法罗群岛", "234", ""),
    FJ("Fiji", "FJ", "FJI", "斐济", "242", ""),
    FI("Finland", "FI", "FIN", "芬兰", "246", "Europe/Helsinki"),
    FR("France", "FR", "FRA", "法国", "250", "Europe/Paris"),
    GF("French Guiana", "GF", "GUF", "法属圭亚那", "254", ""),
    PF("French Polynesia", "PF", "PYF", "法属波利尼西亚", "258", ""),
    GA("Gabon", "GA", "GAB", "加蓬", "266", ""),
    GM("Gambia The", "GM", "GMB", "冈比亚", "270", ""),
    GE("Georgia", "GE", "GEO", "格鲁吉亚", "268", ""),
    DE("Germany", "DE", "DEU", "德国", "276", "Europe/Berlin"),
    GH("Ghana", "GH", "GHA", "加纳", "288", ""),
    GI("Gibraltar", "GI", "GIB", "直布罗陀", "292", ""),
    GR("Greece", "GR", "GRC", "希腊", "300", "Europe/Athens"),
    GL("Greenland", "GL", "GRL", "格陵兰", "304", ""),
    GD("Grenada", "GD", "GRD", "格林纳达", "308", ""),
    GP("Guadeloupe", "GP", "GLP", "瓜德罗普", "312", ""),
    GU("Guam", "GU", "GUM", "关岛", "316", ""),
    GT("Guatemala", "GT", "GTM", "危地马拉", "320", ""),
    GN("Guinea", "GN", "GIN", "几内亚", "324", ""),
    GW("Guinea-Bissau", "GW", "GNB", "几内亚比绍", "624", ""),
    GY("Guyana", "GY", "GUY", "圭亚那", "328", ""),
    HT("Haiti", "HT", "HTI", "海地", "332", ""),
    VA("Holy See (Vatican City)", "VA", "VAT", "教廷（梵蒂冈城）", "336", ""),
    HN("Honduras", "HN", "HND", "洪都拉斯", "340", ""),
    HU("Hungary", "HU", "HUN", "匈牙利", "348", "Europe/Budapest"),
    IS("Iceland", "IS", "ISL", "冰岛", "352", ""),
    IN("India", "IN", "IND", "印度", "356", ""),
    ID("Indonesia", "ID", "IDN", "印度尼西亚", "360", ""),
    IR("Iran", "IR", "IRN", "伊朗", "364", ""),
    IQ("Iraq", "IQ", "IRQ", "伊拉克", "368", ""),
    IE("Ireland", "IE", "IRL", "爱尔兰", "372", "Europe/Dublin"),
    IL("Israel", "IL", "ISR", "以色列", "376", ""),
    IT("Italy", "IT", "ITA", "意大利", "380", "Europe/Rome"),
    JM("Jamaica", "JM", "JAM", "牙买加", "388", ""),
    JP("Japan", "JP", "JPN", "日本", "392", "Asia/Tokyo"),
    JO("Jordan", "JO", "JOR", "约旦", "400", ""),
    KZ("Kazakhstan", "KZ", "KAZ", "哈萨克斯坦", "398", ""),
    KE("Kenya", "KE", "KEN", "肯尼亚", "404", ""),
    KI("Kiribati", "KI", "KIR", "基里巴斯", "296", ""),
    KP("Korea North", "KP", "PRK", "朝鲜", "408", ""),
    KR("Korea South", "KR", "KOR", "韩国", "410", "Asia/Seoul"),
    KW("Kuwait", "KW", "KWT", "科威特", "414", ""),
    KG("Kyrgyzstan", "KG", "KGZ", "吉尔吉斯斯坦", "417", ""),
    LA("Laos", "LA", "LAO", "老挝", "418", ""),
    LV("Latvia", "LV", "LVA", "拉脱维亚", "428", ""),
    LB("Lebanon", "LB", "LBN", "黎巴嫩", "422", ""),
    LS("Lesotho", "LS", "LSO", "索托", "426", ""),
    LR("Liberia", "LR", "LBR", "利比里亚", "430", ""),
    LY("Libya", "LY", "LBY", "利比亚", "434", ""),
    LI("Liechtenstein", "LI", "LIE", "列支敦士登", "438", ""),
    LT("Lithuania", "LT", "LTU", "立陶宛", "440", ""),
    LU("Luxembourg", "LU", "LUX", "卢森堡", "442", ""),
    MK("Macedonia", "MK", "MKD", "马其顿", "807", ""),
    MG("Madagascar", "MG", "MDG", "马达加斯加", "450", ""),
    MW("Malawi", "MW", "MWI", "马拉维", "454", ""),
    MY("Malaysia", "MY", "MYS", "马来西亚", "458", ""),
    MV("Maldives", "MV", "MDV", "马里", "462", ""),
    ML("Mali", "ML", "MLI", "马耳他", "466", ""),
    MT("Malta", "MT", "MLT", "马耳他", "470", ""),
    MH("Marshall Islands", "MH", "MHL", "马绍尔群岛", "584", ""),
    MQ("Martinique", "MQ", "MTQ", "马提尼克", "474", ""),
    MR("Mauritania", "MR", "MRT", "毛里塔尼亚", "478", ""),
    MU("Mauritius", "MU", "MUS", "毛里求斯", "480", ""),
    YT("Mayotte", "YT", "MYT", "马约特", "175", ""),
    MX("Mexico", "MX", "MEX", "墨西哥", "484", "America/Mexico_City"),
    FM("Micronesia Federated States of", "FM", "FSM", "密克罗尼西亚联邦", "583", ""),
    MD("Moldova", "MD", "MDA", "摩尔多瓦", "498", ""),
    MC("Monaco", "MC", "MCO", "摩纳哥", "492", ""),
    MN("Mongolia", "MN", "MNG", "蒙古", "496", ""),
    MS("Montserrat", "MS", "MSR", "蒙特塞拉特", "500", ""),
    MA("Morocco", "MA", "MAR", "摩洛哥", "504", ""),
    MZ("Mozambique", "MZ", "MOZ", "莫桑比克", "508", ""),
    MM("Myanmar (Burma)", "MM", "MMR", "缅甸（缅甸）", "104", ""),
    NA("Namibia", "NA", "NAM", "纳米比亚", "516", ""),
    NR("Nauru", "NR", "NRU", "瑙鲁", "520", ""),
    NP("Nepal", "NP", "NPL", "尼泊尔", "524", "Asia/Kathmandu"),
    NL("Netherlands", "NL", "NLD", "荷兰", "528", "Europe/Amsterdam"),
    AN("Netherlands Antilles", "AN", "ANT", "荷属安的列斯群岛", "530", ""),
    NC("New Caledonia", "NC", "NCL", "新喀里多尼亚", "540", ""),
    NZ("New Zealand", "NZ", "NZL", "新西兰", "554", ""),
    NI("Nicaragua", "NI", "NIC", "尼加拉瓜", "558", ""),
    NE("Niger", "NE", "NER", "尼日尔", "562", ""),
    NG("Nigeria", "NG", "NGA", "尼日利亚", "566", ""),
    NU("Niue", "NU", "NIU", "纽埃", "570", ""),
    NF("Norfolk Island", "NF", "NFK", "诺福克岛", "574", ""),
    MP("Northern Mariana Islands", "MP", "MNP", "北马里亚纳群岛", "580", ""),
    NO("Norway", "NO", "NOR", "挪威", "578", ""),
    OM("Oman", "OM", "OMN", "阿曼", "512", ""),
    PK("Pakistan", "PK", "PAK", "巴基斯坦”", "586", ""),
    PW("Palau", "PW", "PLW", "帕劳", "585", ""),
    PA("Panama", "PA", "PAN", "巴拿马", "591", ""),
    PG("Papua New Guinea", "PG", "PNG", "巴布亚新几内亚", "598", ""),
    PY("Paraguay", "PY", "PRY", "巴拉圭", "600", ""),
    PE("Peru", "PE", "PER", "秘鲁", "604", ""),
    PH("Philippines", "PH", "PHL", "菲律宾", "608", ""),
    PN("Pitcairn Islands", "PN", "PCN", "皮特凯恩群岛", "612", ""),
    PL("Poland", "PL", "POL", "波兰", "616", ""),
    PT("Portugal", "PT", "PRT", "葡萄牙", "620", ""),
    PR("Puerto Rico", "PR", "PRI", "波多黎各", "630", ""),
    QA("Qatar", "QA", "QAT", "卡塔尔", "634", ""),
    RE("Reunion", "RE", "REU", "留尼旺", "638", ""),
    RO("Romania", "RO", "ROM", "罗马尼亚", "642", ""),
    RU("Russia", "RU", "RUS", "俄罗斯", "643", ""),
    RW("Rwanda", "RW", "RWA", "卢旺达", "646", ""),
    KN("Saint Kitts and Nevis", "KN", "KNA", "圣基茨和尼维斯", "659", ""),
    LC("Saint Lucia", "LC", "LCA", "圣卢西亚", "662", ""),
    PM("Saint Pierre and Miquelon", "PM", "SPM", "圣皮埃尔和密克隆", "666", ""),
    VC("Saint Vincent and the Grenadines", "VC", "VCT", "圣文森特和格林纳丁斯", "670", ""),
    SM("San Marino", "SM", "SMR", "圣马力诺", "674", ""),
    ST("Sao Tome and Principe", "ST", "STP", "圣多美和普林西比", "678", ""),
    SA("Saudi Arabia", "SA", "SAU", "沙特阿拉伯", "682", ""),
    SN("Senegal", "SN", "SEN", "塞内加尔", "686", ""),
    SC("Seychelles", "SC", "SYC", "塞舌尔", "690", ""),
    SL("Sierra Leone", "SL", "SLE", "塞拉利昂", "694", ""),
    SG("Singapore", "SG", "SGP", "新加坡", "702", "Singapore"),
    SK("Slovakia", "SK", "SVK", "斯洛伐克", "703", ""),
    SI("Slovenia", "SI", "SVN", "斯洛文尼亚", "705", ""),
    SB("Solomon Islands", "SB", "SLB", "所罗门群岛", "090", ""),
    SO("Somalia", "SO", "SOM", "索马里", "706", ""),
    ZA("South Africa", "ZA", "ZAF", "南非", "710", ""),
    ES("Spain", "ES", "ESP", "西班牙", "724", "Europe/Madrid"),
    LK("Sri Lanka", "LK", "LKA", "斯里兰卡", "144", ""),
    SD("Sudan", "SD", "SDN", "苏丹", "736", ""),
    SR("Suriname", "SR", "SUR", "苏里南", "740", ""),
    SJ("Svalbard", "SJ", "SJM", "斯瓦尔巴", "744", ""),
    SZ("Swaziland", "SZ", "SWZ", "斯威士兰", "748", ""),
    SE("Sweden", "SE", "SWE", "瑞典", "752", ""),
    CH("Switzerland", "CH", "CHE", "瑞士", "756", ""),
    SY("Syria", "SY", "SYR", "叙利亚", "760", ""),
    TW("China Taiwan", "TW", "TWN", "中国台湾", "158", "Asia/Taipei"),
    TJ("Tajikistan", "TJ", "TJK", "塔吉克斯坦", "762", ""),
    TZ("Tanzania", "TZ", "TZA", "坦桑尼亚", "834", ""),
    TH("Thailand", "TH", "THA", "泰国", "764", ""),
    TG("Togo", "TG", "TGO", "多哥", "768", ""),
    TK("Tokelau", "TK", "TKL", "托克劳", "772", ""),
    TO("Tonga", "TO", "TON", "汤加", "776", ""),
    TT("Trinidad and Tobago", "TT", "TTO", "特立尼达和多巴哥", "780", ""),
    TN("Tunisia", "TN", "TUN", "突尼斯", "788", ""),
    TR("Turkey", "TR", "TUR", "土耳其", "792", ""),
    TM("Turkmenistan", "TM", "TKM", "土库曼斯坦", "795", ""),
    TC("Turks and Caicos Islands", "TC", "TCA", "特克斯和凯科斯群岛", "796", ""),
    TV("Tuvalu", "TV", "TUV", "图瓦卢", "798", ""),
    UG("Uganda", "UG", "UGA", "乌干达", "800", ""),
    UA("Ukraine", "UA", "UKR", "乌克兰", "804", ""),
    AE("United Arab Emirates", "AE", "ARE", "阿拉伯联合酋长国", "784", ""),
    GB("United Kingdom", "GB", "GBR", "英国", "826", "Europe/London"),
    US("United States", "US", "USA", "美国", "840", "America/New_York"),
    UY("Uruguay", "UY", "URY", "乌拉圭", "858", "America/Montevideo"),
    UZ("Uzbekistan", "UZ", "UZB", "乌兹别克斯坦", "860", ""),
    VU("Vanuatu", "VU", "VUT", "瓦努阿图", "548", ""),
    VE("Venezuela", "VE", "VEN", "委内瑞拉", "862", ""),
    VN("Vietnam", "VN", "VNM", "越南", "704", ""),
    VI("Virgin Islands", "VI", "VIR", "维尔京群岛", "850", ""),
    WF("Wallis and Futuna", "WF", "WLF", "瓦利斯和富图纳群岛", "876", ""),
    EH("Western Sahara", "EH", "ESH", "西撒哈拉", "732", ""),
    WS("Western Samoa", "WS", "WSM", "西萨摩亚", "882", ""),
    YE("Yemen", "YE", "YEM", "也门", "887", "Asia/Aden"),
    ZR("Zaire (Dem Rep of Congo)", "ZR", "ZAR", "“扎伊尔（刚果民主共和国）", "180", ""),
    ZM("Zambia", "ZM", "ZWB", "赞比亚", "894", ""),
    ZW("Zimbabwe", "ZW", "ZWE", "津巴布韦", "716", ""),

    //新增
    PS("Palestine", "PS", "PSE", "巴勒斯坦", "275", ""),
    AD("Andorra", "AD", "AND", "安道尔", "020", ""),
    AG("Antigua and Barbuda", "AG", "ATG", "安地卡及巴布達", "028", ""),
    AI("Anguilla", "AI", "AIA", "安圭拉 （英國）", "660", ""),
    AM("Armenia", "AM", "ARM", "阿尔扎赫", "051", ""),
    AS("American Samoa", "AS", "ASM", "美属萨摩亚（美国）", "016", ""),
    AX("Åland Islands", "AX", "ALA", "奥兰（芬蘭）", "248", ""),
    RS("Serbia", "RS", "SRB", "塞爾維亞", "688", ""),
    BL("Saint Barthélemy", "BL", "BLM", "圣巴泰勒米（法国）", "652", ""),
    BQ("Bonaire, Sint Eustatius and Saba", "BQ", "BES", "加勒比（荷兰）", "535", ""),
    SH("Saint Helena, Ascension and Tristan da Cunha", "SH", "SHN", "圣赫勒拿、阿森松和特里斯坦-达库尼亚（英国）", "654", ""),
    SS("South Sudan", "SS", "SSD", "南蘇丹", "728", ""),
    CD("Congo, Democratic Republic of the", "CD", "COD", "刚果", "180", ""),
    SX("Sint Maarten (Dutch part)", "SX", "SXM", "荷屬聖馬丁（荷蘭）", "534", ""),
    CW("Curaçao", "CW", "CUW", "库拉索（荷蘭）", "531", ""),
    TL("Timor-Leste", "TL", "TLS", "东帝汶", "626", ""),
    UM("United States Minor Outlying Islands", "UM", "UMI", "美国本土外小岛屿", "581", ""),
    GG("Guernsey", "GG", "GGY", "根西（英国）", "831", ""),
    GS("South Georgia and the South Sandwich Islands", "GS", "SGS", "南乔治亚岛和南桑威奇群岛", "239", ""),
    IM("Isle of Man", "IM", "IMN", "马恩岛（英国）", "833", ""),
    IO("British Indian Ocean Territory", "IO", "IOT", "英属印度洋领地", "086", ""),
    JE("Jersey", "JE", "JEY", "澤西（英国）", "832", ""),
    ME("Montenegro", "ME", "MNE", "蒙特內哥羅", "499", ""),
    MF("Saint Martin (French part)", "MF", "MAF", "法属圣马丁", "663", ""),
    HK("China Hong Kong", "HK", "HKG", "中国香港", "344", "Asia/Hong_Kong"),
    MO("China Macao", "MO", "MAC", "中国澳门", "446", "Asia/Macao"),


    UNDEFINED("Undefined", "00", "000", "未定义", "000", "");

    private String code;

    private String threeName;

    private String fullName;

    private String cnFullName;

    private String number;

    private String timeZone;

    CountryEnum(String fullName, String code, String threeName, String cnFullName, String number, String timeZone) {
        this.code = code;
        this.threeName = threeName;
        this.fullName = fullName;
        this.cnFullName = cnFullName;
        this.number = number;
        this.timeZone = timeZone;
    }

    private final static Map<String, CountryEnum> nameMap = new HashMap<>();
    private final static Map<String, CountryEnum> numberMap = new HashMap<>();
    private final static Map<String, CountryEnum> codeMap = new HashMap<>();
    private final static Map<String, Locale> localeMap = new HashMap<>();

    static {
        Locale[] ls = Locale.getAvailableLocales();
        for (Locale l : ls) {
            if (l.getCountry() != null && !"".equals(l.getCountry().trim())) {
                localeMap.put(l.getCountry().trim(), l);
            }
        }
        for (CountryEnum e : CountryEnum.values()) {
            nameMap.put(e.name(), e);
            numberMap.put(e.getNumber(), e);
            codeMap.put(e.getCode(), e);
        }
    }

    public static boolean isUndefined(String code) {
        return UNDEFINED.getCode().equals(code);
    }

    public static boolean contains(String value) {

        if (value == null) {
            return false;
        }
        String valueTmp = value.trim().toUpperCase();
        if (nameMap.containsKey(valueTmp)
                || numberMap.containsKey(valueTmp)) {
            return true;
        }
        return false;
    }

    public static CountryEnum getEnumByName(String value) {
        if (value == null) {
            return null;
        }
        return nameMap.get(value.trim().toUpperCase());
    }

    public static CountryEnum getEnumByValue(String value) {
        if (value == null) {
            return null;
        }
        String valueTmp = value.trim().toUpperCase();
        if (codeMap.containsKey(value)) {
            return codeMap.get(value);
        }
        if (nameMap.containsKey(valueTmp)) {
            return nameMap.get(valueTmp);
        }
        if (numberMap.containsKey(valueTmp)) {
            return numberMap.get(valueTmp);
        }
        return null;
    }

    public Locale getLocale() {
        return localeMap.get(this.name());
    }

    public String getLanguage() {
        Locale l = localeMap.get(this.name());
        if (l != null) {
            return l.getLanguage();
        }
        return null;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getThreeName() {
        return threeName;
    }

    public void setThreeName(String threeName) {
        this.threeName = threeName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getCnFullName() {
        return cnFullName;
    }

    public String getTimeZone() {
        return timeZone;
    }
}
