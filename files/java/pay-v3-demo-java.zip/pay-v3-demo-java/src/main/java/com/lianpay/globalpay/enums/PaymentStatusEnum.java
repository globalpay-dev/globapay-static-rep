package com.lianpay.globalpay.enums;

/**
 * @author zhanghao003
 */
public enum PaymentStatusEnum {
	IN(1, "Payment Initialize"),
    WP(2, "Waiting for Payment"),
    PP(3, "Payment Processing"),
    PC(4, "Payment Cancel"),
    PF(5, "Payment Failed"),
    PS(6, "Payment Success");
    

    private String desc;
    private int lvl;

    PaymentStatusEnum(int lvl, String desc) {

        this.desc = desc;
        this.lvl = lvl;
    }

    public String getDesc() {

        return desc;
    }

    public int getLvl() {

        return lvl;
    }

    public boolean isLessOrEqualLvl(String name) {

        PaymentStatusEnum orderStatus = PaymentStatusEnum.valueOf(name);
        if (orderStatus == null) {
            return false;
        }
        return this.getLvl() <= orderStatus.getLvl();
    }

}
