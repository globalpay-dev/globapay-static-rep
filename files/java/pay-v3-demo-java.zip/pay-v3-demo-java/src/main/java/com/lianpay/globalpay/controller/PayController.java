package com.lianpay.globalpay.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.lianpay.globalpay.PayConfig;
import com.lianpay.globalpay.PayConfig.MerchantConfig;
import com.lianpay.globalpay.utils.SignUtil;

/**
 * @author yanggx
 */
@Controller
@RequestMapping("/pay")
public class PayController {
	
	@Autowired
    private PayConfig payConfig;

    @GetMapping("/checkout")
    public String checkout(Model model) {
        String merchantTransactionId = String.valueOf(System.nanoTime());
        model.addAttribute("productName", "suit");
        model.addAttribute("merchantTransactionId", merchantTransactionId);

        return "checkout";
    }
    
    /**
     * 支付成功跳转的商户成功页面
     * @param model
     * @return 成功页面
     */
    @GetMapping("/success")
    public String paymentSuccess(@RequestParam(name="merchant_id") String merchantId,
    		@RequestParam(name="merchant_transaction_id") String merchantTransactionId,
    		@RequestParam(name="order_currency_code") String orderCurrencyCode,
    		@RequestParam(name="order_amount") BigDecimal orderAmount,
    		@RequestParam(name="payment_status") String paymentStatus,
    		@RequestParam(name="payment_currency_code") String paymentCurrencyCode,
    		@RequestParam(name="payment_amount") BigDecimal paymentAmount,
    		@RequestParam(name="sign_type") BigDecimal signType,
    		@RequestParam(name="signature") String signature){
    	if(signature != null){
    		Map<String, Object> signContentMap = new HashMap<String, Object>();
    		signContentMap.put("merchant_id", merchantId);
    		signContentMap.put("merchant_transaction_id", merchantTransactionId);
    		signContentMap.put("order_currency_code", orderCurrencyCode);
    		signContentMap.put("order_amount", orderAmount);
    		signContentMap.put("payment_status", paymentStatus);
    		signContentMap.put("payment_currency_code", paymentCurrencyCode);
    		signContentMap.put("payment_amount", paymentAmount);
    		signContentMap.put("sign_type", signType);
    		MerchantConfig merchantConfig = payConfig.getMerchantConfig(merchantId);
    		//执行验签
    		try {
                SignUtil.checkSign(signature, signContentMap, merchantConfig.getLlPublicKey());
            } catch (Exception e) {
                throw new RuntimeException("verify signature failed", e);
            }
    		//根据paymentStatus，更新商户订单状态
    	}else{
    		//未开启验签需要抛异常
    	}
    	if("PS".equals(paymentStatus)){
    		return "paymentSuccess";
    	}else{
    		throw new RuntimeException("paymentSuccess is not PS");
    	}
    }
}
