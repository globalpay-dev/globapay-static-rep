package com.lianpay.globalpay.payv3sdkdemojava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayV3SdkDemoJavaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PayV3SdkDemoJavaApplication.class, args);
    }

}
