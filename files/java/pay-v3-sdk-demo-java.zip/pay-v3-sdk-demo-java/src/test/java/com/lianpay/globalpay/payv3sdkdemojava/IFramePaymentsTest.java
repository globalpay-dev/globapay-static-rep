package com.lianpay.globalpay.payv3sdkdemojava;

import com.lianpay.globalpay.IFrameTokenService;
import com.lianpay.globalpay.PaymentsService;
import com.lianpay.globalpay.constants.GlobalpayConstants;
import com.lianpay.globalpay.domain.ApiResult;
import com.lianpay.globalpay.domain.bean.Address;
import com.lianpay.globalpay.domain.bean.CardInfo;
import com.lianpay.globalpay.domain.bean.Customer;
import com.lianpay.globalpay.domain.bean.MerchantOrderInfo;
import com.lianpay.globalpay.domain.bean.PaymentRequestPaymentData;
import com.lianpay.globalpay.domain.bean.Product;
import com.lianpay.globalpay.domain.bean.Shipping;
import com.lianpay.globalpay.domain.request.PaymentsRequest;
import com.lianpay.globalpay.domain.response.PaymentsResponse;
import com.lianpay.globalpay.enums.ApiResultCodeEnum;
import com.lianpay.globalpay.enums.CountryEnum;
import com.lianpay.globalpay.enums.CurrencyEnum;
import com.lianpay.globalpay.enums.CustomerTypeEnum;
import com.lianpay.globalpay.enums.PaymentTypeEnum;
import com.lianpay.globalpay.enums.ShippingCycleEnum;
import com.lianpay.globalpay.enums.USStateEnum;
import com.lianpay.globalpay.exception.HttpClientException;
import com.lianpay.globalpay.exception.ParamCheckFailException;
import com.lianpay.globalpay.exception.SignException;
import com.lianpay.globalpay.exception.VerifySignFailException;
import com.lianpay.globalpay.reader.MerchantPropertyReader;
import com.lianpay.globalpay.utils.DateUtils;
import com.lianpay.globalpay.utils.JacksonUtils;
import org.junit.Test;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class IFramePaymentsTest extends SpringBootTestSupport {
    //初始化商户配置信息
    private final MerchantPropertyReader merchant = new MerchantPropertyReader("/globalpay-merchant.properties");
    private final IFrameTokenService iFrameTokenService = new IFrameTokenService();
    private final PaymentsService payService = new PaymentsService();

    @Test
    public void testIFramePaySuccess() {
        System.out.println("IFrame模式详细支付流程请见：https://doc.lianlianpay.com/pay-guide/pay-scene/iframe/card");
        System.out.println("第一步 根据商户号获取token(对应流程中1.1)");
        ApiResult<String> iFrameTokenRes = null;
        try {
            iFrameTokenRes = iFrameTokenService.sendIFrameTokenRequest(merchant);
        } catch (ParamCheckFailException e) {
            System.out.println("参数校验异常:" + JacksonUtils.toJsonString(e.getValidateErrorList()));
        } catch (SignException e) {
            System.out.println("参数签名异常:" + e.getCode() + "," + e.getMessage());
        } catch (HttpClientException e) {
            System.out.println("http client调用异常:" + e.getCode() + "," + e.getMessage());
        } catch (VerifySignFailException e) {
            System.out.println("签名验证异常:" + e.getCode() + "," + e.getMessage());
        }

        if (iFrameTokenRes == null || !ApiResultCodeEnum.SUCCESS.name().equals(iFrameTokenRes.getReturnCode())) {
            System.out.println("payments apply failed");
            System.out.println("payments response:" + JacksonUtils.toJsonString(iFrameTokenRes));
            return;
        }

        System.out.println("获取到 IFrame token:" + iFrameTokenRes.getOrder());
        System.out.println("第二步 将IFrame token给到前端进行初始化IFRAME对象并且渲染(对应流程中1.4)");
        System.out.println("第三步 由用户完成IFrame中的信息填写(对应流程中2.1 - 2.2)");
        System.out.println("第四步 调用前端js提供的获取card_token方法(详见https://doc.lianlianpay.com/pay-guide/pay-scene/iframe/card#%E5%AE%A2%E6%88%B7%E7%AB%AF%E5%BC%80%E5%8F%91%E6%AD%A5%E9%AA%A4)");
        System.out.println("第五步 将前端获取到的card_token传递到后端进行支付请求参数组装");
        String cardToken = "从前端获取到的card_token";
        PaymentsRequest payRequest = buildIFramePayRequest(cardToken);
        ApiResult<PaymentsResponse> s = null;
        try {
            s = payService.sendPaymentRequest(payRequest, merchant);
        } catch (ParamCheckFailException e) {
            System.out.println("参数校验异常:" + JacksonUtils.toJsonString(e.getValidateErrorList()));
        } catch (SignException e) {
            System.out.println("参数签名异常:" + e.getCode() + "," + e.getMessage());
        } catch (HttpClientException e) {
            System.out.println("http client调用异常:" + e.getCode() + "," + e.getMessage());
        } catch (VerifySignFailException e) {
            System.out.println("签名验证异常:" + e.getCode() + "," + e.getMessage());
        }
        if (s != null && ApiResultCodeEnum.SUCCESS.name().equals(s.getReturnCode())) {
            System.out.println("连连交易单号llTransactionId:[" + s.getOrder().getLlTransactionId() + "]商户交易单号merchantTransactionId[" + s.getOrder().getMerchantTransactionId() + "]订单状态[" + s.getOrder().getPaymentData().getPaymentStatus() + "]");
        } else {
            System.out.println("发起支付失败");
            System.out.println("支付返回结果为:" + JacksonUtils.toJsonString(s));
            return;
        }
        if (GlobalpayConstants.TDS_CHALLENGE.equals(s.getOrder().getTdsStatus())) {
            System.out.println("第六步 需要进行3ds逻辑处理,需要重定向至链接:" + s.getOrder().getPaymentUrl());
            System.out.println("第七步 支付验证完成后，会跳转回支付请求中的redirectUrl");
        }
    }

    private PaymentsRequest buildIFramePayRequest(String cardToken) {
        PaymentsRequest request = new PaymentsRequest();
        String merchantTransactionId = String.valueOf(System.nanoTime());
        //商户支付交易号，保证唯一。必填
        request.setMerchantTransactionId(merchantTransactionId);
        //支付结果通知地址,若消息通知获取结果必填
        request.setNotificationUrl("https://www.baidu.com");
        //支付成功后，用户页面回跳URL地址;必填。
        request.setRedirectUrl("https://global.lianlianpay.com");
        //收单国家(商户主体国家)。必填
        request.setCountry(CountryEnum.HK.getCode());
        //订单信息。必填
        request.setMerchantOrder(generateMerchantOrderInfo());
        //客户详情,必填。
        request.setCustomer(generateCustomer());
        //支付数据,必填
        request.setPaymentData(generatePaymentData(cardToken));
		//IFrame模式，必填
        request.setPaymentMethod(PaymentTypeEnum.ICR.getPaymentMethod());
        return request;
    }

    private MerchantOrderInfo generateMerchantOrderInfo() {
        MerchantOrderInfo merchantOrderInfo = new MerchantOrderInfo();
        //此为商户系统的订单号，支付订单号和支付交易单号可以传一样。必填。
        merchantOrderInfo.setMerchantOrderId(String.valueOf(System.nanoTime()));
        //商户订单时间:yyyyMMddHHmmss,必填
        SimpleDateFormat formatter = DateUtils.DateFormatHolder.formatFor(GlobalpayConstants.TIMESTAMP_FORMAT);
        merchantOrderInfo.setMerchantOrderTime(formatter.format(new Date()));
        //订单金额，需保留两位小数 Eg.100.00。必填。
        merchantOrderInfo.setOrderAmount(new BigDecimal("100.00"));
        //订单币种。必填。
        merchantOrderInfo.setOrderCurrencyCode(CurrencyEnum.USD.getAbbr());
        //商品详情列表，总长度不能超过40960.必填
        merchantOrderInfo.setProducts(generateProducts());
        //物流信息
        merchantOrderInfo.setShipping(generateShipping());
        return merchantOrderInfo;
    }

    private Shipping generateShipping() {
        Shipping shipping = new Shipping();
        //收货人姓名,必填。
        shipping.setName("zhang san");
        //配送周期,必填。
        shipping.setCycle(ShippingCycleEnum.other.getCode());
        //配送地址信息,必填。
        shipping.setAddress(generateAddress());
        return shipping;
    }

    private Address generateAddress() {
        Address address = new Address();
        //详细地址1,必填.
        address.setLine1("4114 Sepulveda Blvd");
        //城市,必填。
        address.setCity("Culver City");
        //省份/州。部分国家（美国巴西加拿大）必填。请参照【https://doc.lianlianpay.com/appendix/state】，其他国家按ISO标准填
        address.setState(USStateEnum.CA.name());
        //国家，必填.
        address.setCountry(CountryEnum.US.getCode());
        //邮编，必填. 可进行postcode校验
        CountryEnum.US.verifyPostcode("90230");
        address.setPostalCode("90230");
        return address;
    }

    private Customer generateCustomer() {
        Customer customer = new Customer();
        //客户身份类型，目前仅支持个人 I =Individual （个人） C=Corporation（公司）。必填
        customer.setCustomerType(CustomerTypeEnum.I.name());
        //客户身份类型为个人，必填
        customer.setFirstName("zhang");
        //客户身份类型为个人，必填
        customer.setLastName("san");
        //个人全名或者公司名称，必填
        customer.setFullName("zhang san");
        //地址信息
        customer.setAddress(generateAddress());
        return customer;
    }

    private List<Product> generateProducts() {
        Product product = new Product();
        //商品ID，必填。
        product.setProductId("20001029398");
        //商品名称，必填。
        product.setName("female clothes");
        //商品描述
        product.setDescription("测试商品");
        //商品价格，需保留两位小数.必填.
        product.setPrice(new BigDecimal("100.00"));
        //商品数量，正整数.必填。
        product.setQuantity(1);
        //分类。
        product.setCategory("clothes");
        //商品SKU.信用卡支付必填。
        product.setSku("sku-103848");
        //商品网址，国际信用卡时必填。
        product.setUrl("https://www.baidu.com");
        //物流供应商
        product.setShippingProvider("DHL");
        return Collections.singletonList(product);
    }

    private PaymentRequestPaymentData generatePaymentData(String cardToken) {
        PaymentRequestPaymentData paymentData = new PaymentRequestPaymentData();
        CardInfo card = new CardInfo();
        //持卡人姓名,IFrame模式必传
        card.setHolderName("zhang san");
        //card_token,IFrame模式必传
        card.setCardToken(cardToken);
        //账单地址,IFrame模式必传
        card.setBillingAddress(generateAddress());
        paymentData.setCard(card);
        return paymentData;
    }
}
