package com.lianpay.globalpay.payv3sdkdemojava;

import com.lianpay.globalpay.MerchantUnbindTokenService;
import com.lianpay.globalpay.domain.ApiResult;
import com.lianpay.globalpay.domain.request.CardTokenRequest;
import com.lianpay.globalpay.enums.ApiResultCodeEnum;
import com.lianpay.globalpay.exception.HttpClientException;
import com.lianpay.globalpay.exception.ParamCheckFailException;
import com.lianpay.globalpay.exception.SignException;
import com.lianpay.globalpay.exception.VerifySignFailException;
import com.lianpay.globalpay.reader.MerchantPropertyReader;
import com.lianpay.globalpay.utils.JacksonUtils;
import org.junit.Test;

public class MerchantCardTokenTest extends SpringBootTestSupport{
    private final MerchantPropertyReader merchant = new MerchantPropertyReader("/globalpay-merchant.properties");

    private MerchantUnbindTokenService merchantUnbindTokenService = new MerchantUnbindTokenService();

    @Test
    public void unbindToken(){
        System.out.println("解除卡绑定请见：https://doc.lianlianpay.com/doc-api/open-api/unbind-token");
        ApiResult<?> unbindTokenRes = null;
        try {
            CardTokenRequest cardTokenRequest = generateCardTokenRequest();
            unbindTokenRes = merchantUnbindTokenService.sendUnbindCardTokenRequest(cardTokenRequest, merchant);
            System.out.println("ret response:" + JacksonUtils.toJsonString(unbindTokenRes));
        } catch (ParamCheckFailException e) {
            System.out.println("参数校验异常:" + JacksonUtils.toJsonString(e.getValidateErrorList()));
        } catch (SignException e) {
            System.out.println("参数签名异常:" + e.getCode() + "," + e.getMessage());
        } catch (HttpClientException e) {
            System.out.println("http client调用异常:" + e.getCode() + "," + e.getMessage());
        } catch (VerifySignFailException e) {
            System.out.println("签名验证异常:" + e.getCode() + "," + e.getMessage());
        }

        if (unbindTokenRes == null || !ApiResultCodeEnum.SUCCESS.name().equals(unbindTokenRes.getReturnCode())) {
            System.out.println("unbind token failed");
            System.out.println("ret response:" + JacksonUtils.toJsonString(unbindTokenRes));
            return;
        }
    }

    private CardTokenRequest generateCardTokenRequest(){
        CardTokenRequest cardTokenRequest = new CardTokenRequest();
        // 商户的用户标识
        cardTokenRequest.setMerchantUserNo("123456789");
        // 连连分配的商户号
        cardTokenRequest.setMerchantId("20240906001537001");
        // 连连分配的站点号（二级商户号）
        cardTokenRequest.setSubMerchantId("1020240906085001");
        // 在连连绑定卡后生成的卡凭证标识
        cardTokenRequest.setLianlianCardTokenId("LIANLIAN_TOKEN2024071702882243");
        return cardTokenRequest;
    }
}
