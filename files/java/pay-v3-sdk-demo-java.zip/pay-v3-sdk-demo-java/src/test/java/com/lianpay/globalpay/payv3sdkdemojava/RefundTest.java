package com.lianpay.globalpay.payv3sdkdemojava;

import com.lianpay.globalpay.RefundService;
import com.lianpay.globalpay.constants.GlobalpayConstants;
import com.lianpay.globalpay.domain.ApiResult;
import com.lianpay.globalpay.domain.bean.RefundRequestRefundData;
import com.lianpay.globalpay.domain.request.RefundRequest;
import com.lianpay.globalpay.domain.response.RefundResponse;
import com.lianpay.globalpay.enums.ApiResultCodeEnum;
import com.lianpay.globalpay.enums.CurrencyEnum;
import com.lianpay.globalpay.exception.HttpClientException;
import com.lianpay.globalpay.exception.ParamCheckFailException;
import com.lianpay.globalpay.exception.SignException;
import com.lianpay.globalpay.exception.VerifySignFailException;
import com.lianpay.globalpay.reader.MerchantPropertyReader;
import com.lianpay.globalpay.utils.DateUtils;
import com.lianpay.globalpay.utils.JacksonUtils;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

public class RefundTest extends SpringBootTestSupport {
    private final MerchantPropertyReader merchant = new MerchantPropertyReader("/globalpay-merchant.properties");
    private final RefundService refundService = new RefundService();

    @Test
    public void testRefund() {
        RefundRequest request = buildRefundRequest();
        //原始交易订单号 必填
        request.setOriginalTransactionId("23366282346686");
        ApiResult<RefundResponse> refundResponseApiResult = null;
        try {
            refundResponseApiResult = refundService.sendRefundRequest(request, merchant);
        } catch (ParamCheckFailException e) {
            System.out.println("参数校验异常:" + JacksonUtils.toJsonString(e.getValidateErrorList()));
        } catch (SignException e) {
            System.out.println("参数签名异常:" + e.getCode() + "," + e.getMessage());
        } catch (HttpClientException e) {
            System.out.println("http client调用异常:" + e.getCode() + "," + e.getMessage());
        } catch (VerifySignFailException e) {
            System.out.println("签名验证异常:" + e.getCode() + "," + e.getMessage());
        }
        if (refundResponseApiResult != null && ApiResultCodeEnum.SUCCESS.name().equals(refundResponseApiResult.getReturnCode())) {
            System.out.println("连连退款单号llTransactionId:[" + refundResponseApiResult.getOrder().getLlTransactionId()
                    + "]商户退款单号merchantTransactionId[" + refundResponseApiResult.getOrder().getMerchantTransactionId()
                    + "]订单状态[" + refundResponseApiResult.getOrder().getRefundData().getRefundStatus() + "]");
        } else {
            System.out.println("发起退款失败");
            System.out.println("退款返回结果为:" + JacksonUtils.toJsonString(refundResponseApiResult));
        }
    }

    private RefundRequest buildRefundRequest() {
        RefundRequest request = new RefundRequest();
        String merchantTransactionId = String.valueOf(System.nanoTime());
        //商户退款订单号 必填
        request.setMerchantTransactionId(merchantTransactionId);
        SimpleDateFormat formatter = DateUtils.DateFormatHolder.formatFor(GlobalpayConstants.TIMESTAMP_FORMAT);
        //商户退款时间 必填
        request.setMerchantRefundTime(formatter.format(new Date()));
        RefundRequestRefundData refundData = new RefundRequestRefundData();
        //退款金额 必填
        refundData.setRefundAmount("10.00");
        //退款币种 必填
        refundData.setRefundCurrencyCode(CurrencyEnum.USD.name());
        request.setRefundData(refundData);
        //退款结果通知地址
        request.setNotificationUrl("https://www.baidu.com");
        return request;
    }
}
