package com.lianpay.globalpay.payv3sdkdemojava;

import com.lianpay.globalpay.CardTokenNotifyService;
import com.lianpay.globalpay.RefundNotifyService;
import com.lianpay.globalpay.domain.request.CardTokenNotifyRequest;
import com.lianpay.globalpay.domain.request.RefundNotifyRequest;
import com.lianpay.globalpay.exception.ParamCheckFailException;
import com.lianpay.globalpay.exception.VerifySignFailException;
import com.lianpay.globalpay.reader.MerchantPropertyReader;
import com.lianpay.globalpay.utils.JacksonUtils;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

public class CardTokenNotifyTest extends SpringBootTestSupport {
    private final MerchantPropertyReader merchant = new MerchantPropertyReader("/globalpay-merchant.properties");
    private final CardTokenNotifyService cardTokenNotifyService = new CardTokenNotifyService();

    @Test
    public void testTokenEventNotify() {
        System.out.println("绑卡结果通知详细请见：https://doc.lianlianpay.com/doc-api/open-news/token-event-result");
        Map<String, String> headers = new HashMap<>();
        headers.put("signature","M+Ono2nzwv35FnuDJBJsWtRrqBSHmS0B0N6iOQwQ6jfQg4LwtFeITsNRQx5ag/uIdOXMwEYnsu4gcFhD6ATLi7fwhjlsECZzPKaXlQrnNQqftx/dkaVXpVxPpSFT5anZOVHNkXKcB5RRumL/hc3gDjIZR39GANQ9Q2VajEDvDnEwNoU/VJx5ERuxFoaz98fMHquTr3fKo4iOAz+UmMfs2/B0G9AHtdHs0nUjA3NfRB8LB2F1MB5S+xX5Yv723LBTyTpcPxsRvcKSkxPB1OwuNj5Rt2LtsB1K3tcRE+GiU/IePkLt2elTbNDuduZLgxO0iKF//53jJNtHnlJjJy/4Iw==");
        headers.put("sign-type","RSA");
        String requestBody = "{\"merchant_user_no\":\"123456789\",\"card_token_data\":{\"card_token_type\":\"PAYMENT_TOKEN\",\"lianlian_card_token_status\":\"UNBIND\",\"card_no\":\"512034******0747\",\"card_expiration_month\":\"12\",\"lianlian_card_token_id\":\"202409116876499\",\"brand\":\"mastercard\",\"card_expiration_year\":\"31\",\"holder_name\":\"zh****an\"},\"merchant_id\":\"20240906001537001\",\"event\":\"UNBIND_CARD_TOKEN\",\"sub_merchant_id\":\"1020240906085001\"}";
        CardTokenNotifyRequest cardTokenNotifyRequest = null;
        try {
            cardTokenNotifyRequest = cardTokenNotifyService.checkNotifySignAndGetPaymentsNotifyRequest(headers, requestBody, merchant);
        } catch (ParamCheckFailException e) {
            System.out.println("参数校验异常:" + JacksonUtils.toJsonString(e.getValidateErrorList()));
        } catch (VerifySignFailException e) {
            System.out.println("签名验证异常:" + e.getCode() + "," + e.getMessage());
        }
        System.out.println("通知数据：" + JacksonUtils.toJsonString(cardTokenNotifyRequest));
        System.out.println("返回成功数据：" + JacksonUtils.toJsonString(cardTokenNotifyRequest.getCard_token_data()));
    }

}
