package com.lianpay.globalpay.payv3sdkdemojava;

import com.lianpay.globalpay.IFrameCardTokenService;
import com.lianpay.globalpay.domain.ApiResult;
import com.lianpay.globalpay.domain.request.CardTokenRequest;
import com.lianpay.globalpay.enums.ApiResultCodeEnum;
import com.lianpay.globalpay.exception.HttpClientException;
import com.lianpay.globalpay.exception.ParamCheckFailException;
import com.lianpay.globalpay.exception.SignException;
import com.lianpay.globalpay.exception.VerifySignFailException;
import com.lianpay.globalpay.reader.MerchantPropertyReader;
import com.lianpay.globalpay.utils.JacksonUtils;
import org.junit.Test;

public class IFrameCardTokenPaymentsTest extends SpringBootTestSupport{

    private final MerchantPropertyReader merchant = new MerchantPropertyReader("/globalpay-merchant.properties");
    private final IFrameCardTokenService iFrameCardTokenService = new IFrameCardTokenService();

    @Test
    public void postCardTokenTest(){
        System.out.println("IFrame模式(绑卡)详细支付流程请见：https://doc.lianlianpay.com/pay-guide/pay-scene/iframe/save-card-pay");
        System.out.println("第一步 根据商户号获取iframe凭证(对应流程中1.3)");
        ApiResult<String> iFrameTokenRes = null;
        try {
            CardTokenRequest cardTokenRequest = generateCardTokenRequest();
            iFrameTokenRes = iFrameCardTokenService.sendCardTokenRequest(cardTokenRequest,merchant);
            System.out.println("ret response:" + JacksonUtils.toJsonString(iFrameTokenRes));
        } catch (ParamCheckFailException e) {
            System.out.println("参数校验异常:" + JacksonUtils.toJsonString(e.getValidateErrorList()));
        } catch (SignException e) {
            System.out.println("参数签名异常:" + e.getCode() + "," + e.getMessage());
        } catch (HttpClientException e) {
            System.out.println("http client调用异常:" + e.getCode() + "," + e.getMessage());
        } catch (VerifySignFailException e) {
            System.out.println("签名验证异常:" + e.getCode() + "," + e.getMessage());
        }

        if (iFrameTokenRes == null || !ApiResultCodeEnum.SUCCESS.name().equals(iFrameTokenRes.getReturnCode())) {
            System.out.println("card token get failed");
            System.out.println("ret response:" + JacksonUtils.toJsonString(iFrameTokenRes));
            return;
        }
    }

    private CardTokenRequest generateCardTokenRequest(){
        CardTokenRequest cardTokenRequest = new CardTokenRequest();
        // 商户的用户标识
        cardTokenRequest.setMerchantUserNo("123456789");
        // 连连分配的商户号
        cardTokenRequest.setMerchantId("20240906001537001");
        // 连连分配的站点号（二级商户号）
        cardTokenRequest.setSubMerchantId("1020240906085001");
        return cardTokenRequest;
    }
}
