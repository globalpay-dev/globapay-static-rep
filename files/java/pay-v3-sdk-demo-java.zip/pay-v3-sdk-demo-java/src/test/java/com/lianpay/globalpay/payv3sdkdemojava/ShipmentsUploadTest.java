package com.lianpay.globalpay.payv3sdkdemojava;

import com.lianpay.globalpay.ShipmentsService;
import com.lianpay.globalpay.domain.ApiResult;
import com.lianpay.globalpay.domain.bean.Shipment;
import com.lianpay.globalpay.domain.request.ShipmentRequest;
import com.lianpay.globalpay.enums.ApiResultCodeEnum;
import com.lianpay.globalpay.enums.CountryEnum;
import com.lianpay.globalpay.enums.CourierEnum;
import com.lianpay.globalpay.exception.HttpClientException;
import com.lianpay.globalpay.exception.ParamCheckFailException;
import com.lianpay.globalpay.exception.SignException;
import com.lianpay.globalpay.exception.VerifySignFailException;
import com.lianpay.globalpay.reader.MerchantPropertyReader;
import com.lianpay.globalpay.utils.JacksonUtils;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class ShipmentsUploadTest extends SpringBootTestSupport {
    private final MerchantPropertyReader merchant = new MerchantPropertyReader("/globalpay-merchant.properties");
    private final ShipmentsService shipmentsService = new ShipmentsService();

    @Test
    public void testShipmentsUpload() {
        System.out.println("物流上传接口详细请见：https://doc.lianlianpay.com/doc-api/open-api/logistics");
        ShipmentRequest shipmentRequest = buildShipmentRequest();
        ApiResult<?> apiResult = null;
        try {
            apiResult = shipmentsService.sendShipmentsRequest(shipmentRequest, merchant);
        } catch (ParamCheckFailException e) {
            System.out.println("参数校验异常:" + JacksonUtils.toJsonString(e.getValidateErrorList()));
        } catch (SignException e) {
            System.out.println("参数签名异常:" + e.getCode() + "," + e.getMessage());
        } catch (HttpClientException e) {
            System.out.println("http client调用异常:" + e.getCode() + "," + e.getMessage());
        } catch (VerifySignFailException e) {
            System.out.println("签名验证异常:" + e.getCode() + "," + e.getMessage());
        }
        if (apiResult != null && ApiResultCodeEnum.SUCCESS.name().equals(apiResult.getReturnCode())) {
            System.out.println("物流上传成功");
        } else {
            System.out.println("发起物流上传失败");
            System.out.println("物流上传返回结果为:" + JacksonUtils.toJsonString(apiResult));
        }
    }


    private ShipmentRequest buildShipmentRequest() {
        ShipmentRequest shipmentRequest = new ShipmentRequest();
        //商户订单号, 必填
        shipmentRequest.setMerchantTransactionId("2177786043495500");
        List<Shipment> shipments = new ArrayList<>();
        Shipment shipment = new Shipment();
        //发货国家缩写
        shipment.setCountry(CountryEnum.HK.getCode());
        //承运商编码，必填
        shipment.setCarrierCode(CourierEnum.fedex.getCode());
        //物流单号 ，必填
        shipment.setTrackingNo("913249132");
        shipments.add(shipment);
        shipmentRequest.setShipments(shipments);
        return shipmentRequest;
    }
}
