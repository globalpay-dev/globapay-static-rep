package com.lianpay.globalpay.payv3sdkdemojava;

import com.lianpay.globalpay.RefundNotifyService;
import com.lianpay.globalpay.domain.request.RefundNotifyRequest;
import com.lianpay.globalpay.exception.ParamCheckFailException;
import com.lianpay.globalpay.exception.VerifySignFailException;
import com.lianpay.globalpay.reader.MerchantPropertyReader;
import com.lianpay.globalpay.utils.JacksonUtils;
import org.junit.Test;

import java.util.Map;

public class RefundNotifyTest extends SpringBootTestSupport {
    private final MerchantPropertyReader merchant = new MerchantPropertyReader("/globalpay-merchant.properties");
    private final RefundNotifyService refundNotifyService = new RefundNotifyService();

    @Test
    public void testRefundNotify() {
        System.out.println("退款通知详细请见：https://doc.lianlianpay.com/doc-api/open-news/refund-result");
        Map<String, String> headers = JacksonUtils.parseObject("{\"Content-Type\":\"application/json\",\"sign-type\":\"RSA\",\"signature\":\"h89DA4WSF4lwZHHJj2QrKiCA249fJMk88RTt4yokCyR1yKTsbJuigv/C3wlCp+zubpSH9NqPu9wbGB7i1beCQMgvixc7PxxSTC3FNsXnaS//Ne6M3HHHhj0NalSX+jlG1yJdB4WQJECTIu9n0SyjDLLZzYDqiWvUDIXVAc+EvHzMKIFg6NXGUi1wptGOSxmIQbEi/KsYLmGVwiAjxnP+bWruc6QSxiPRoFaxyqLL/3LHupTNiLFSvHSp6N3Wt/JvEDQ17fgoKeDxqPhWwZNfVGD0YnCrgI6BtHROlbEvUikNLo96WLHOptjniP+LJZ0L5VFpm9QgdnjR1JJrJtoRSQ==\",\"timestamp\":\"20220114145402\",\"timezone\":\"Asia/Hong_Kong\"}", Map.class);
        String requestBody = "{\"ll_transaction_id\":\"2022011401103274\",\"merchant_transaction_id\":\"1921342567969400\",\"original_transaction_id\":\"1919457102744900\",\"refund_data\":{\"account_date\":\"20220114\",\"actual_refund_amount\":\"100.00\",\"actual_refund_currency_code\":\"USD\",\"exchange_rate\":\"1.00000000\",\"refund_amount\":\"100.00\",\"refund_currency_code\":\"USD\",\"refund_status\":\"RS\",\"refund_time\":\"20220114145402\",\"settlement_amount\":\"100.00\",\"settlement_currency_code\":\"USD\"}}";
        RefundNotifyRequest refundNotifyRequest = null;
        try {
            refundNotifyRequest = refundNotifyService.checkNotifySignAndGetRefundNotifyRequest(headers, requestBody, merchant);
        } catch (ParamCheckFailException e) {
            System.out.println("参数校验异常:" + JacksonUtils.toJsonString(e.getValidateErrorList()));
        } catch (VerifySignFailException e) {
            System.out.println("签名验证异常:" + e.getCode() + "," + e.getMessage());
        }
        System.out.println("退款通知数据：" + JacksonUtils.toJsonString(refundNotifyRequest));
        System.out.println("需要返回成功数据：" + JacksonUtils.toJsonString(refundNotifyService.getSuccessDealResponse()));
    }

}
