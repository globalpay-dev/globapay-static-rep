package com.lianpay.globalpay.payv3sdkdemojava;

import com.lianpay.globalpay.RefundQueryService;
import com.lianpay.globalpay.domain.ApiResult;
import com.lianpay.globalpay.domain.response.RefundResponse;
import com.lianpay.globalpay.enums.ApiResultCodeEnum;
import com.lianpay.globalpay.exception.HttpClientException;
import com.lianpay.globalpay.exception.ParamCheckFailException;
import com.lianpay.globalpay.exception.SignException;
import com.lianpay.globalpay.exception.VerifySignFailException;
import com.lianpay.globalpay.reader.MerchantPropertyReader;
import com.lianpay.globalpay.utils.JacksonUtils;
import org.junit.Test;

public class RefundQueryTest extends SpringBootTestSupport {
    private final MerchantPropertyReader merchant = new MerchantPropertyReader("/globalpay-merchant.properties");
    private final RefundQueryService refundQueryService = new RefundQueryService();

    @Test
    public void testRefundQuery() {
        System.out.println("退款查询接口详细请见：https://doc.lianlianpay.com/doc-api/open-api/refund-result");
        String merchantTransactionId = "2515126909474200";
        ApiResult<RefundResponse> refundResponseApiResult = null;
        try {
            refundResponseApiResult = refundQueryService.sendRefundQueryRequest(merchantTransactionId, merchant);
        } catch (ParamCheckFailException e) {
            System.out.println("参数校验异常:" + JacksonUtils.toJsonString(e.getValidateErrorList()));
        } catch (SignException e) {
            System.out.println("参数签名异常:" + e.getCode() + "," + e.getMessage());
        } catch (HttpClientException e) {
            System.out.println("http client调用异常:" + e.getCode() + "," + e.getMessage());
        } catch (VerifySignFailException e) {
            System.out.println("签名验证异常:" + e.getCode() + "," + e.getMessage());
        }
        if (refundResponseApiResult != null && ApiResultCodeEnum.SUCCESS.name().equals(refundResponseApiResult.getReturnCode())) {
            System.out.println("连连退款单号llTransactionId:[" + refundResponseApiResult.getOrder().getLlTransactionId()
                    + "]商户退款单号merchantTransactionId[" + refundResponseApiResult.getOrder().getMerchantTransactionId()
                    + "]订单状态[" + refundResponseApiResult.getOrder().getRefundData().getRefundStatus() + "]");
        } else {
            System.out.println("发起退款查询失败");
            System.out.println("退款查询返回结果为:" + JacksonUtils.toJsonString(refundResponseApiResult));
        }
    }
}
