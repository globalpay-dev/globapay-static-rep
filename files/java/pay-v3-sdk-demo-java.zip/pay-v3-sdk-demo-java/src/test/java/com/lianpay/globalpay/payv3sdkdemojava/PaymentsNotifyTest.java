package com.lianpay.globalpay.payv3sdkdemojava;

import com.lianpay.globalpay.PaymentNotifyService;
import com.lianpay.globalpay.domain.request.PaymentsNotifyRequest;
import com.lianpay.globalpay.exception.ParamCheckFailException;
import com.lianpay.globalpay.exception.VerifySignFailException;
import com.lianpay.globalpay.reader.MerchantPropertyReader;
import com.lianpay.globalpay.utils.JacksonUtils;
import org.junit.Test;

import java.util.Map;

public class PaymentsNotifyTest extends SpringBootTestSupport {
    private final MerchantPropertyReader merchant = new MerchantPropertyReader("/globalpay-merchant.properties");
    private final PaymentNotifyService paymentNotifyService = new PaymentNotifyService();

    @Test
    public void testPaymentNotify() {
        System.out.println("支付通知详细请见：https://doc.lianlianpay.com/doc-api/open-news/pay-result");
        Map<String, String> headers = JacksonUtils.parseObject("{\"Content-Type\":\"application/json\",\"sign-type\":\"RSA\",\"signature\":\"LmLh4VQArJQPQT7wtgqi5gfX6iBXzU8h8th9YO6nZIrNmpPmxz9iViaazhEkApTS8XmtkTvrHBKhN4ek7dLnmE3HR43lU9vsktx8L2wQblmzlCgV5pi5PJwNyJYdlZN8/C3nuGUmh2MOwVpmAH7qUD0Ql5cmU+y3gFzW0fiKzOkocdPWddmC5BgBtUV6YKMmEFLTjm0JXUlUpPXpHWO1GKXywcfv3cfpTHWkJS0gTo+el7VTkl+IPtSo4bDYopeUHnNYTaRA0EapyqgtERS+nM7Qg16yG6Vm4OQn3vclqxJoZGsi2kWwIe5B7NAoAcU3VF4d4LMyi3LLzjhGfkq1NQ==\",\"timestamp\":\"20220114142409\",\"timezone\":\"Asia/Hong_Kong\"}", Map.class);
        String requestBody = "{\"ll_transaction_id\":\"2022011401103220\",\"merchant_transaction_id\":\"1919457102744900\",\"payment_data\":{\"account_date\":\"20220114\",\"exchange_rate\":\"1.00000000\",\"payment_amount\":\"100.00\",\"payment_currency_code\":\"USD\",\"payment_status\":\"PS\",\"payment_time\":\"20220114142408\",\"settlement_amount\":\"100.00\",\"settlement_currency_code\":\"USD\"},\"payment_url\":\"https://celer-gateway.lianlianpay-inc.com/publish/2fc2e27296484fa4af98367e5d99f3d9\"}";
        PaymentsNotifyRequest paymentsNotifyRequest = null;
        try {
            paymentsNotifyRequest = paymentNotifyService.checkNotifySignAndGetPaymentsNotifyRequest(headers, requestBody, merchant);
        } catch (ParamCheckFailException e) {
            System.out.println("参数校验异常:" + JacksonUtils.toJsonString(e.getValidateErrorList()));
        } catch (VerifySignFailException e) {
            System.out.println("签名验证异常:" + e.getCode() + "," + e.getMessage());
        }
        System.out.println("支付通知数据：" + JacksonUtils.toJsonString(paymentsNotifyRequest));
        System.out.println("需要返回成功数据：" + JacksonUtils.toJsonString(paymentNotifyService.getSuccessDealResponse()));
    }
}
