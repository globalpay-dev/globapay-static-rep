package com.lianpay.globalpay.payv3sdkdemojava;

import com.lianpay.globalpay.PaymentsCancelService;
import com.lianpay.globalpay.domain.ApiResult;
import com.lianpay.globalpay.domain.response.CancelPayResponse;
import com.lianpay.globalpay.enums.ApiResultCodeEnum;
import com.lianpay.globalpay.exception.HttpClientException;
import com.lianpay.globalpay.exception.ParamCheckFailException;
import com.lianpay.globalpay.exception.SignException;
import com.lianpay.globalpay.exception.VerifySignFailException;
import com.lianpay.globalpay.reader.MerchantPropertyReader;
import com.lianpay.globalpay.utils.JacksonUtils;
import org.junit.Test;

public class PaymentsCancelTest extends SpringBootTestSupport {
    private final MerchantPropertyReader merchant = new MerchantPropertyReader("/globalpay-merchant.properties");
    private final PaymentsCancelService paymentsCancelService = new PaymentsCancelService();

    @Test
    public void testPaymentsCancel() {
        System.out.println("支付取消接口详细请见：https://doc.lianlianpay.com/doc-api/open-api/pay-cancel");
        String merchantTransactionId = "2277789015810500";
        ApiResult<CancelPayResponse> cancelPayResponseApiResult = null;
        try {
            cancelPayResponseApiResult = paymentsCancelService.sendPaymentCancelRequest(merchantTransactionId, merchant);
        } catch (ParamCheckFailException e) {
            System.out.println("参数校验异常:" + JacksonUtils.toJsonString(e.getValidateErrorList()));
        } catch (SignException e) {
            System.out.println("参数签名异常:" + e.getCode() + "," + e.getMessage());
        } catch (HttpClientException e) {
            System.out.println("http client调用异常:" + e.getCode() + "," + e.getMessage());
        } catch (VerifySignFailException e) {
            System.out.println("签名验证异常:" + e.getCode() + "," + e.getMessage());
        }
        if (cancelPayResponseApiResult != null
                && ApiResultCodeEnum.SUCCESS.name().equals(cancelPayResponseApiResult.getReturnCode())
                && cancelPayResponseApiResult.getOrder().getAllowCancel()) {
            System.out.println("商户交易单号merchantTransactionId[" + cancelPayResponseApiResult.getOrder().getMerchantTransactionId()
                    + "]是否取消成功[" + cancelPayResponseApiResult.getOrder().getAllowCancel() + "]");
        } else {
            System.out.println("发起支付取消失败");
            System.out.println("支付取消返回结果为:" + JacksonUtils.toJsonString(cancelPayResponseApiResult));
        }
    }
}


