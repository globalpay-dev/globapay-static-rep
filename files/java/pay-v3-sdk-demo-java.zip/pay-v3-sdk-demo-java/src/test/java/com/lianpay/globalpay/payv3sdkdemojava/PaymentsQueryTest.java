package com.lianpay.globalpay.payv3sdkdemojava;

import com.lianpay.globalpay.PaymentsQueryService;
import com.lianpay.globalpay.domain.ApiResult;
import com.lianpay.globalpay.domain.response.PaymentsResponse;
import com.lianpay.globalpay.enums.ApiResultCodeEnum;
import com.lianpay.globalpay.exception.HttpClientException;
import com.lianpay.globalpay.exception.ParamCheckFailException;
import com.lianpay.globalpay.exception.SignException;
import com.lianpay.globalpay.exception.VerifySignFailException;
import com.lianpay.globalpay.reader.MerchantPropertyReader;
import com.lianpay.globalpay.utils.JacksonUtils;
import org.junit.Test;

public class PaymentsQueryTest extends SpringBootTestSupport {
    private final MerchantPropertyReader merchant = new MerchantPropertyReader("/globalpay-merchant.properties");
    private final PaymentsQueryService paymentsQueryService = new PaymentsQueryService();

    @Test
    public void testPaymentsQuery() {
        System.out.println("支付查询接口详细请见：https://doc.lianlianpay.com/doc-api/open-api/pay-result");
        String merchantTransactionId = "2177786043495500";
        ApiResult<PaymentsResponse> payResponseApiResult = null;
        try {
            payResponseApiResult = paymentsQueryService.sendPaymentQueryRequest(merchantTransactionId, merchant);
            System.out.println(JacksonUtils.toJsonString(payResponseApiResult));
        } catch (ParamCheckFailException e) {
            System.out.println("参数校验异常:" + JacksonUtils.toJsonString(e.getValidateErrorList()));
        } catch (SignException e) {
            System.out.println("参数签名异常:" + e.getCode() + "," + e.getMessage());
        } catch (HttpClientException e) {
            System.out.println("http client调用异常:" + e.getCode() + "," + e.getMessage());
        } catch (VerifySignFailException e) {
            System.out.println("签名验证异常:" + e.getCode() + "," + e.getMessage());
        }
        if (payResponseApiResult != null && ApiResultCodeEnum.SUCCESS.name().equals(payResponseApiResult.getReturnCode())) {
            System.out.println("连连交易单号llTransactionId:[" + payResponseApiResult.getOrder().getLlTransactionId() + "]商户交易单号merchantTransactionId[" + payResponseApiResult.getOrder().getMerchantTransactionId()
                    + "]订单状态[" + payResponseApiResult.getOrder().getPaymentData().getPaymentStatus() + "]");
        } else {
            System.out.println("发起支付查询失败");
            System.out.println("支付查询返回结果为:" + JacksonUtils.toJsonString(payResponseApiResult));
        }
    }
}
