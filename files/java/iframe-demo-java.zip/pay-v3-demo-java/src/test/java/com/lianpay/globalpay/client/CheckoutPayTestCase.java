package com.lianpay.globalpay.client;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.lianpay.globalpay.PayConfig;
import com.lianpay.globalpay.PayDemoApplication;
import com.lianpay.globalpay.domain.Address;
import com.lianpay.globalpay.domain.ApiResult;
import com.lianpay.globalpay.domain.Customer;
import com.lianpay.globalpay.domain.MerchantOrderInfo;
import com.lianpay.globalpay.domain.PayRequest;
import com.lianpay.globalpay.domain.PayResponse;
import com.lianpay.globalpay.domain.Product;
import com.lianpay.globalpay.domain.Shipping;
import com.lianpay.globalpay.enums.CountryEnum;
import com.lianpay.globalpay.enums.CurrencyEnum;
import com.lianpay.globalpay.enums.CustomerTypeEnum;
import com.lianpay.globalpay.enums.MccEnum;
import com.lianpay.globalpay.enums.PaymentStatusEnum;
import com.lianpay.globalpay.enums.ShippingCycleEnum;
import com.lianpay.globalpay.utils.TimeZoneUtil;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = PayDemoApplication.class)
public class CheckoutPayTestCase {

	private String merchantId = "202006090000013002";
	private String timezone = CountryEnum.HK.getTimeZone();
	/**
	 * 支付成功后跳转地址，商户支付成功地址，这里模拟商户的支付成功页面  请模拟实现看PayController#paymentSuccess
	 * 127.0.0.1:8080调不通，需要改为商户的实际通知地址 
	 * 收银台模式需要制定该参数，iframe模式只需要商户在支付页面根据支付结果报文跳转相应地址
	 * @see com.lianpay.globalpay.controller.PayController#paymentSuccess
	 */
	private String redirectUrl = "http://127.0.0.1:8080/pay-v3-demo/pay/success";
	/**
	 * 支付成功后异步通知地址，这里模拟商户的接收异常通知请求  请看PayController#paymentSuccess
	 * @see com.lianpay.globalpay.controller.NotifyController#receivePaymentNotify
	 */
	private String notificationUrl = "http://12.0.0.1:8080/pay-v3-demo/notifications/payment";
    @Autowired
    private PayClient payClient;
    @Autowired
    private PayConfig payConfig;

    @Test
    public void testPaySuccess() {
        try {
        	System.out.println();
        	System.out.println("                           以下是外卡checkout模式的接入流程                                                             ");
        	System.out.println();
        	System.out.println("=================================================================================");
        	System.out.println("第一步 用户在商户页面选择外卡支付发起商户后端支付申请");
        	System.out.println("-------------商户签名信息配置放在src/main/resource/application.yml中-------------------");
        	System.out.println("以下是demo是模拟商户服务向连连发起支付申请请求及响应报文：");
        	ApiResult<PayResponse> response = payApplySuccess();
			if (!"SUCCESS".equalsIgnoreCase(response.getReturnCode())) {
                System.out.println("payment apply failed");
			    return;
			} else {
				System.out.println("连连交易单号llTransactionId:[" + 
						response.getOrder().getLlTransactionId() + 
						"]商户交易单号merchantTransactionId[" + 
						response.getOrder().getMerchantTransactionId() + "]");
			}
			System.out.println("=================================================================================");
			System.out.println("第二步 将 [" + response.getOrder().getPaymentUrl() + "]（此为模拟商户的支付页面）复制到浏览器打开");
			System.out.println("=================================================================================");
			System.out.println("第三步 在浏览器中按照以下案例测试");
			System.out.println("-----------------------支付成功案例----------------------");
			System.out.println("卡号：4000 0000 0000 0002 或者 5200 0000 0000 0007");
			System.out.println("有效期：12/30");
			System.out.println("cvv：123");
			System.out.println("-----------------------支付失败案例----------------------");
			System.out.println("卡号：4000 0000 1000 1112");
			System.out.println("有效期：11/20");
			System.out.println("cvv：123");
			System.out.println("=================================================================================");
			System.out.println("第四步 在浏览器输入支付信息，支付成功后,商户在支付页面根据支付结果报文，跳转支付成功地址");
			System.out.println("=================================================================================");
			System.out.println("第五步 支付成功后会收到连连的异步通知，通知地址接口中传入，详见notificationUrl");
			System.out.println("=================================================================================");
			System.out.println();
			System.out.println();
			System.out.println();
        } catch (Exception e) {
			e.printStackTrace();  
		}
    }
    
    
    private ApiResult<PayResponse> payApplySuccess() throws Exception {
        PayRequest request = new PayRequest();
        request.setBizCode("EC");
        request.setCountry("HK");
        request.setMerchantId(merchantId);
        //支付成功后跳转地址，商户支付成功地址，这里模拟商户的支付成功页面  请看PayController#paymentSuccess
        //iframe模式可以不传
        request.setRedirectUrl(redirectUrl);
        //支付成功后异步通知地址，这里模拟商户的接收异常通知请求  请看PayController#paymentSuccess
        request.setNotificationUrl(notificationUrl);
        String merchantTransactionId = String.valueOf(System.nanoTime());
        //商户发起支付交易的单号，保证唯一
        request.setMerchantTransactionId(merchantTransactionId);
        Address address = new Address();
        address.setCity("Bangkok");
        address.setCountry("HK");
        address.setDistrict("ruset");
        address.setLine2("test hong");
        address.setPostalCode("35627");
        address.setState("TH-19");
        address.setLine1("Avenida Paulista");
        Customer customer = new Customer();
        customer.setAddress(address);
        customer.setCustomerType(CustomerTypeEnum.I.name());
        customer.setFullName("zhang san");
        customer.setFirstName("zhang");
        customer.setLastName("san");
        request.setCustomer(customer);
        Product product = new Product();
        product.setCategory("clothes");
        product.setName("female clothes");
        product.setPrice(new BigDecimal("126.6"));
        product.setProductId("20001029398");
        product.setQuantity(1);
        product.setShippingProvider("DHL");
        product.setSku("sku-103848");
        product.setUrl("https://www.baidu.com");
        List<Product> products = Arrays.asList(product);
        Shipping shipping = new Shipping();
        Address shippingAddress = new Address();
        BeanUtils.copyProperties(address, shippingAddress);
        shipping.setAddress(shippingAddress);
        shipping.setName("zhangsan");
        shipping.setPhone("+55-2849384938");
        shipping.setCycle(ShippingCycleEnum.h48.getCode());
        MerchantOrderInfo merchantOrderInfo = MerchantOrderInfo.builder()
        		//此为商户系统的订单号，支付订单号和支付交易单号可以传一样
        		.merchantOrderId(merchantTransactionId) 
                .merchantOrderTime(TimeZoneUtil.getTimestampOfTimezone(timezone))
                .orderAmount(new BigDecimal("126.62"))
                .orderCurrencyCode(CurrencyEnum.USD.name())
                .orderDescription("测试订单描述")
                .products(products)
                .mcc(MccEnum.M5137.getCode())
                .shipping(shipping).build();
        request.setMerchantOrder(merchantOrderInfo);
        return payClient.pay(request, timezone);
    }
    
    private ApiResult<PayResponse> payQuery(String merchantTransactionId) throws Exception {
    	 return payClient.payQuery(merchantId, merchantTransactionId, timezone);
    }

    @Test
    public void testPayQuery() throws Exception {
        String merchantTransactionId = "363627689558604";
        ApiResult<PayResponse> response = payQuery(merchantTransactionId);
        String paymentStatus = Optional.ofNullable(response.getOrder().getPaymentData()).map(it -> it.getPaymentStatus()).orElse(null);
        if ("SUCCESS".equalsIgnoreCase(response.getReturnCode()) && PaymentStatusEnum.PS.name().equalsIgnoreCase(paymentStatus)) {
            System.out.println("payment result successful");
        } else if ("SUCCESS".equalsIgnoreCase(response.getReturnCode())) {
            System.out.println("payment apply successful");
        } else {
            System.out.println("payment apply failed");
        }
    }
}
