package com.lianpay.globalpay.utils;

import com.alibaba.fastjson.JSON;
import com.lianpay.globalpay.constants.AlgorithmConstant;
import com.lianpay.globalpay.enums.SignTypeEnum;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.text.DecimalFormat;
import java.util.*;

/***
 */
public class SignUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(SignUtil.class);
    private static String DEFAULT_KV_PAIR_SEPARATOR = "&";
    private static String DEFAULT_KV_SEPARATOR = "=";
    private static final DecimalFormat AMOUNT_DECIMAL_FORMAT = new DecimalFormat("#0.00");

    private SignUtil() {
    }

    public static String generateSignatureString(String jsonStr) throws Exception {
        return generateSignatureString(jsonStr, DEFAULT_KV_PAIR_SEPARATOR, DEFAULT_KV_SEPARATOR);
    }

    public static String generateSignatureString(String jsonStr, String kvPairSeparator, String kvSeparator) {
        if (StringUtils.isEmpty(jsonStr)) {
            throw new NullPointerException("Please check your parameter!The JSON string is empty.");
        }
        Map<String, Object> payment = JSON.parseObject(jsonStr);
        StringBuffer content = new StringBuffer();
        append(content, payment, kvPairSeparator, kvSeparator);
        return content.toString();
    }

    private static void append(StringBuffer content, Map<String, Object> sourceObj, String kvPairSeparator, String kvSeparator) {
        if (sourceObj == null) {
            return;
        }
        Map<String, Object> obj = sourceObj;
        if (obj.keySet().size() == 0) {
            return;
        }
        List<String> keyList = new ArrayList<String>(obj.keySet().size());
        for (String key : obj.keySet()) {
            keyList.add(key);
        }
        Collections.sort(keyList);
        for (String key : keyList) {
            Object value = obj.get(key);
            if(value == null){
            	continue;
            }
            if (value instanceof List) {
                for (int i = 0; i < ((List<?>) value).size(); i++) {
                    Object item = ((List<?>) value).get(i);
                    if (item instanceof Map) {
                        append(content, (Map<String, Object>) item, kvPairSeparator, kvSeparator);
                    }
                }
            } else if (value instanceof Map) {
                append(content, (Map<String, Object>) value, kvPairSeparator, kvSeparator);
            } else if (value instanceof String
                    || value instanceof Float
                    || value instanceof Double
                    || value instanceof Integer
                    || value instanceof Long
                    || value instanceof BigDecimal) {
                if (content.length() > 0) {
                    content.append(kvPairSeparator);
                }
                content.append(key);
                content.append(kvSeparator);
                if ((value instanceof BigDecimal 
                		|| value instanceof Integer
                		|| value instanceof Double
                		|| value instanceof Long)
                		&& key != null && 
                		(key.indexOf("amount") > 0 
                				|| key.indexOf("Amount") > 0 
                				|| key.indexOf("AMOUNT") > 0)) {
                	content.append(AMOUNT_DECIMAL_FORMAT.format(value));
                }else{
                	 content.append(value);
                }
            }
        }
    }
    
    private static void append(StringBuffer content, Map<String, Object> sourceObj) throws Exception {
        append(content, sourceObj, DEFAULT_KV_PAIR_SEPARATOR, DEFAULT_KV_SEPARATOR);
    }
    
    public static void checkSign(String sign, Map<String, Object> signContentMap, String rsaPublic) {
    	checkSign(sign, JSON.toJSONString(signContentMap), rsaPublic);
    }

    public static void checkSign(String sign, String signContentJson, String rsaPublic) {
        boolean isSignOk = false;
        try {
            String signContent = SignUtil.generateSignatureString(signContentJson);
            LOGGER.info("request-rsa_public[{}]srcKey[{}]sign[{}]", rsaPublic, signContent, sign);
            isSignOk = TraderRSAUtil.checkSign(rsaPublic, signContent, sign, AlgorithmConstant.SHA1_WITH_RSA);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        if (!isSignOk) {
            throw new RuntimeException("INVALID_SIGNATURE");
        }
    }

    public static void checkSign(String signature, String signContentJson,
                                 String kvPairSeparator, String kvSeparator,
                                 String signKey, SignTypeEnum signType,
                                 String signAlgo) {
        boolean isSignOk = false;
        try {
            String signContent = SignUtil.generateSignatureString(signContentJson, kvPairSeparator, kvSeparator);
            LOGGER.info("request-signKey[{}]srcKey[{}]sign[{}]", signKey, signContent, signature);
            if (SignTypeEnum.RSA == signType) {
                isSignOk = TraderRSAUtil.checkSign(signKey, signContent, signature, signAlgo);
            } else if (SignTypeEnum.HMAC == signType){
                String signatureByOurSide = null;
                if (AlgorithmConstant.MD5_WITH_HMAC.equalsIgnoreCase(signAlgo)) {
                    signatureByOurSide = DigestUtil.hmacMD5Digest(signContent, signKey);
                } else if (AlgorithmConstant.SHA1_WITH_HMAC.equalsIgnoreCase(signAlgo)) {
                    signatureByOurSide = DigestUtil.hmacSHA1Digest(signContent, signKey);
                } else if (AlgorithmConstant.SHA256_WITH_HMAC.equalsIgnoreCase(signAlgo)) {
                    signatureByOurSide = DigestUtil.hmacSHA256Digest(signContent, signKey);
                } else if (AlgorithmConstant.SHA512_WITH_HMAC.equalsIgnoreCase(signAlgo)) {
                    signatureByOurSide = DigestUtil.hmacSHA512Digest(signContent, signKey);
                }
                isSignOk = signatureByOurSide.equalsIgnoreCase(signature);
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        if (!isSignOk) {
            throw new RuntimeException("INVALID_SIGNATURE");
        }
    }

    public static String addSign(String signParamJsonString, String kvPairSeparator, String kvSeparator,
                                 String signKey, SignTypeEnum signType, String signAlgo) {
        String signContent = SignUtil.generateSignatureString(signParamJsonString, kvPairSeparator, kvSeparator);
        LOGGER.info("request-signKey[{}]srcKey[{}]", signKey, signContent);
        String signature = null;
        try {
            if (SignTypeEnum.RSA == signType) {
                signature = TraderRSAUtil.sign(signKey, signContent, signAlgo);
            } else if (SignTypeEnum.HMAC == signType){
                if (AlgorithmConstant.MD5_WITH_HMAC.equalsIgnoreCase(signAlgo)) {
                    signature = DigestUtil.hmacMD5Digest(signContent, signKey);
                } else if (AlgorithmConstant.SHA1_WITH_HMAC.equalsIgnoreCase(signAlgo)) {
                    signature = DigestUtil.hmacSHA1Digest(signContent, signKey);
                } else if (AlgorithmConstant.SHA256_WITH_HMAC.equalsIgnoreCase(signAlgo)) {
                    signature = DigestUtil.hmacSHA256Digest(signContent, signKey);
                } else if (AlgorithmConstant.SHA512_WITH_HMAC.equalsIgnoreCase(signAlgo)) {
                    signature = DigestUtil.hmacSHA512Digest(signContent, signKey);
                }
            }
            return signature;
        } catch (UnsupportedEncodingException e) {
            LOGGER.error("addSign exception", e);
            throw new RuntimeException(e.getMessage());
        } catch (NoSuchAlgorithmException e) {
            LOGGER.error("addSign exception", e);
            throw new RuntimeException(e.getMessage());
        } catch (InvalidKeyException e) {
            LOGGER.error("addSign exception", e);
            throw new RuntimeException(e.getMessage());
        } catch (InvalidKeySpecException e) {
            throw new RuntimeException(e.getMessage());
        } catch (SignatureException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    public static String addSign(String signParamJsonString, String rsaPrivate) throws Exception {
        String signContent = SignUtil.generateSignatureString(signParamJsonString);
        String sign = TraderRSAUtil.sign(rsaPrivate, signContent, AlgorithmConstant.SHA1_WITH_RSA);
        LOGGER.info("response-rsa_private[{}]srcKey[{}]sign[{}]", rsaPrivate, signContent, sign);
        return sign;
    }
}
