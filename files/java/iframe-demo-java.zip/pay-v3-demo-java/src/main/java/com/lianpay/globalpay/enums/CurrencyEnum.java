package com.lianpay.globalpay.enums;

import java.util.*;

/**
 * 币种枚举
 * @author zhanghao003  
 * @version  2.0.6
 * @date: 2019年5月16日 下午2:07:25
 * @since JDK 1.8
 */
public enum CurrencyEnum {
	
    /**
     * Currency of Brazil
     */
    BRL("986","BRL","R$","巴西里亚伊（雷亚尔）"),
    /**
     * Currency of USA
     */
    USD("840","USD","U$","美元"),
    /**
     * Currency of China
     */
    CNY("156","CNY","¥","人民币"),
    /**
     * 墨西哥比索Mexico Peso
     */
    MXN("484","MXN","MXN$","墨西哥比索"),
    /**
     * 澳大利亚元Australia Dollar
     */
    AUD("036","AUD","A$","澳元"),
    /**
     * 阿根廷比索Argentina Peso
     */
    ARS("032","ARS","₳","阿根廷比索"),
    /**
     * 马来西亚Malaysia Ringgit
     */
    MYR("458","MYR","RM","马来西亚林吉特"),
    /**
     * 新西兰New Zealand Dollar
     */
    NZD("554","NZD","$","新西兰元"),
    /**
     * 波兰Poland Zloty
     */
    PLN("985","PLN","zł","波兰兹罗提"),
    /**
     * 英镑Britain Pound
     */
    GBP("826","GBP","￡","英镑"),
    /**
     * 欧元Euro
     */
    EUR("978","EUR","€","欧元"),
    /**
     * 日圆Japan Yen
     */
    JPY("392","JPY","¥","日圆"),
    /**
     * 俄罗斯卢布Russia Ruble
     */
    RUB("643","RUB","руб","俄罗斯卢布"),
    /**
     * 瑞士法郎Switzerland Franc
     */
    CHF("756","CHF","₣","瑞士法郎"),
    /**
     * 哥伦比亚比索Colombia Peso
     */
    COP("170","COP","$","哥伦比亚比索"),
    /**
     * HongKongDollars
     */
    HKD("344","HKD","HK$","港元"),
    /**
     * 加拿大元
     */
    CAD("124","CAD","C$","加拿大元"),
    /**
     * 丹麦克朗
     */
    DKK("208","DKK","KR","丹麦克朗"),
    /**
     * 芬兰马克
     */
    FIM("246","FIM","₰","芬兰马克"),
    /**
     * 法国法郎
     */
    FRF("250","FRF","₣","法国法郎"),
    /**
     * 德国马克
     */
    DEM("276","DEM","ℳ","德国马克"),
    /**
     * 意大利里拉
     */
    ITL("380","ITL","₤","意大利里拉"),
    /**
     * 韩元
     */
    KRW("410","KRW","₩","韩元"),
    /**
     * 澳门元
     */
    MOP("446","MOP","MOP$","澳门元"),
    /**
     * 菲律宾比索
     */
    PHP("608","PHP","₱","菲律宾比索"),
    /**
     * 新加坡元
     */
    SGD("702","SGD","S$","新加坡元"),
    /**
     * 瑞典克朗
     */
    RKS("752","RKS","kr","瑞典克朗"),
    /**
     * 泰铢
     */
    THB("764","THB","฿","泰铢"),
    /**
     * 乌拉圭比索
     */
    UYU("858","UYU","$","乌拉圭比索")
    ;
    private String symbol;
    private String code;
    private String abbr;
    private String desc;
    CurrencyEnum(String code, String abbr, String symbol, String desc) {
    	this.code = code;
    	this.abbr = abbr;
    	this.symbol = symbol;
    	this.desc = desc;
    }
    private static final Map<String, CurrencyEnum> NAME_MAP = new HashMap<String, CurrencyEnum>();
    private static final Map<String, CurrencyEnum> CODE_MAP = new HashMap<String, CurrencyEnum>();
    private static final Map<String, CurrencyEnum> ABBR_MAP = new HashMap<String, CurrencyEnum>();

    static {
        for (CurrencyEnum currency : CurrencyEnum.values()) {
        	NAME_MAP.put(currency.name(), currency);
        	CODE_MAP.put(currency.code, currency);
        	ABBR_MAP.put(currency.abbr, currency);
        }
    }

    public static final boolean contains(String value) {
    	if(value != null){
    		if(NAME_MAP.containsKey(value.trim().toUpperCase())){
    			return true;
    		}
    		if(CODE_MAP.containsKey(value.trim())){
    			return true;
    		}
    		if(ABBR_MAP.containsKey(value.trim().toUpperCase())){
    			return true;
    		}
    	}
        return false;
    }
    
    public static final CurrencyEnum getEnumByValue(String value){
    	if (value == null) {
            return null;
        }
    	CurrencyEnum result = getEnumByName(value);
        if (result != null){
        	return result;
        }
        result = getEnumByCode(value);
        if (result != null){
        	return result;
        }
        return getEnumByAbbr(value);
    }
    
    public static final CurrencyEnum getEnumByName(String name){
    	if(name != null){
    		return NAME_MAP.get(name.trim().toUpperCase());
    	}
    	return null;
    }
    
    public static final CurrencyEnum getEnumByCode(String code){
    	if(code != null){
    		return CODE_MAP.get(code.trim());
    	}
    	return null;
    }
    
    public static final CurrencyEnum getEnumByAbbr(String abbr){
    	if(abbr != null){
    		return ABBR_MAP.get(abbr.trim());
    	}
    	return null;
    }
    
    public static final List<String> getNotContainsList(String... currencys){
    	Set<String> newSet = new HashSet<>(NAME_MAP.keySet());
    	if(currencys != null){
    		for(String currency : currencys){
    			if(currency != null){
    				newSet.remove(currency.trim());
    			}
    		}
    	}
    	return new ArrayList<String>(newSet);
    }
    
    /**
     * 通过CODE获取ABBR。156-->CNY
     * @param code
     * @return
     */
    public static final String getAbbrByCode(String code) {
        if (code != null) {
        	CurrencyEnum currencyEnum = getEnumByCode(code);
        	if (currencyEnum != null) {
        		return currencyEnum.getAbbr();
        	}
        }
        return null;
    }
    
    /**
     * 根据ABBR获取CODE。CNY-->156
     * @param code
     * @return
     */
    public static final String getCodeByAbbr(String abbr) {
    	if (abbr != null) {
         	CurrencyEnum currencyEnum = getEnumByAbbr(abbr);
         	if (currencyEnum != null) {
         		return currencyEnum.getCode();
         	}
        }
        return null;
    }

	public String getSymbol() {
		return symbol;
	}

	public String getCode() {
		return code;
	}

	public String getAbbr() {
		return abbr;
	}

	public String getDesc() {
		return desc;
	}
}
