package com.lianpay.globalpay.domain;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class BaseResponse implements Serializable {
	private static final long serialVersionUID = 112131212L;
	@JSONField(name = "return_code")
	@JsonProperty("return_code")
    private String returnCode;
	@JSONField(name = "return_msg")
	@JsonProperty("return_msg")
    private String returnMsg;
	@JSONField(name = "trace_id")
	@JsonProperty("trace_id")
    private String traceId;
    
    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getReturnMsg() {
        return returnMsg;
    }

    public void setReturnMsg(String returnMsg) {
        this.returnMsg = returnMsg;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }
}
