package com.lianpay.globalpay.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.lianpay.globalpay.domain.NotifyPayResponse;
import com.lianpay.globalpay.domain.PayResponse;
import com.lianpay.globalpay.domain.RefundResponse;
import com.lianpay.globalpay.utils.SignUtil;

/**
 * @author yanggx
 */
@Controller
@RequestMapping("/notifications")
public class NotifyController {

    String llPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1tG+qFHMMs7KrRvlrQandSHJEFQtg8N5C4Nm7FcODoW3ltK3JNW5tZHyzEd3aekycd9+UHSn6cegmjBhffEWz2CUeVEVZ3DKVRn4Mw7wjAXbqrYHVBUaEXEWWnRJVVhoJg1pr4mPjevHO63HIPHBUNZgrzXf0NnTNWKqEv2UD8qcRSXzfFfz2tJQQu67g6FINwUbWdpprBT4cHDf915dY5mdyTSxho8B6kfEhyud+kbWD17/5YHCGspR8O8CtPJzDFiG6WhDPDWG2m16ohQgk7G1zRHZC68x1Hfa3aDB4Vha3O5IoySDZMFpbNOA8VApc7kCDxJdANCpRPFjzLeQhwIDAQAB";

    @PostMapping("/payment")
    public ResponseEntity<NotifyPayResponse> receivePaymentNotify(@RequestBody PayResponse notify, HttpServletRequest request) {
        String signature = request.getHeader("signature");
        try {
            SignUtil.checkSign(signature, JSON.toJSONString(notify), llPublicKey);
        } catch (Exception e) {
            System.out.println("invalid signature");
        }
        // TODO 请检查金额币种后更新商户订单状态,根据paymentStatus状态区分 详见PaymentStatusEnum
        System.out.println(JSON.toJSONString(notify));
        //通知返回 httpcode:200   body : {"code":"200"} 连连才会判断为通知成功
        return ResponseEntity.status(HttpStatus.OK).body(new NotifyPayResponse("200","success"));
    }

    @PostMapping("/refund")
    public ResponseEntity<NotifyPayResponse> receiveRefundNotify(@RequestBody RefundResponse notify, HttpServletRequest request) {
        String signature = request.getHeader("signature");
        try {
            SignUtil.checkSign(signature, JSON.toJSONString(notify), llPublicKey);
        } catch (Exception e) {
            System.out.println("invalid signature");
        }
        // TODO 请检查金额币种后更新商户订单状态,根据paymentStatus状态区分 详见PaymentStatusEnum
        System.out.println(JSON.toJSONString(notify));
        //通知返回 httpcode:200   body : {"code":"200"} 连连才会判断为通知成功
        return ResponseEntity.status(HttpStatus.OK).body(new NotifyPayResponse("200","success"));
    }
}
