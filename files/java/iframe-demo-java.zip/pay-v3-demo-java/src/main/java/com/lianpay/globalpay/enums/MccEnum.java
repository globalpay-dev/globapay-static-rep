package com.lianpay.globalpay.enums;


import java.util.HashMap;
import java.util.Map;

/**
 * @author zhanghao003  
 */
public enum MccEnum {
    M5399(MerchantBizCodeEnum.PHYSICAL_SALE,   "5399",	"Testing"),
    M5998(MerchantBizCodeEnum.PHYSICAL_SALE,   "5998",	"Tent and awning shops"),
    M5045(MerchantBizCodeEnum.PHYSICAL_SALE,   "5045",	"Computers, computer peripheral equipment - not elsewhere classified"),
    M5251(MerchantBizCodeEnum.PHYSICAL_SALE,   "5251",	"Hardware shops"),
    M5533(MerchantBizCodeEnum.PHYSICAL_SALE,   "5533",	"Automotive parts and accessories outlets"),
    M5611(MerchantBizCodeEnum.PHYSICAL_SALE,   "5611",	"Men’s and boys’ clothing and accessory shops"),
    M5621(MerchantBizCodeEnum.PHYSICAL_SALE,   "5621",	"Women’s ready-to-wear shops"),
    M5631(MerchantBizCodeEnum.PHYSICAL_SALE,   "5631",	"Women’s accessory and speciality shops"),
    M5641(MerchantBizCodeEnum.PHYSICAL_SALE,   "5641",	"Children’s and infants’ wear shops"),
    M5655(MerchantBizCodeEnum.PHYSICAL_SALE,   "5655",	"Sports and riding apparel shops"),
    M5691(MerchantBizCodeEnum.PHYSICAL_SALE,   "5691",	"Men’s and women’s clothing shops"),
    M5712(MerchantBizCodeEnum.PHYSICAL_SALE,   "5712",	"Furniture, home furnishings and equipment shops and manufacturers, except appliances"),
    M5732(MerchantBizCodeEnum.PHYSICAL_SALE,   "5732",	"Electronic Sales"),
    M5945(MerchantBizCodeEnum.PHYSICAL_SALE,   "5945",	"Hobby, toy and game shops"),
    M5261(MerchantBizCodeEnum.PHYSICAL_SALE,   "5261",	"Lawn and garden supplies outlets, including nurseries"),
    M5661(MerchantBizCodeEnum.PHYSICAL_SALE,   "5661",	"Shoe shops"),
    M5946(MerchantBizCodeEnum.PHYSICAL_SALE,   "5946",	"Camera and photographic supply shops"),
    M5111(MerchantBizCodeEnum.PHYSICAL_SALE,   "5111",	"Stationery, office supplies and printing and writing paper"),

	/**
	 * Game digital entertainment
	 */
    M5816(MerchantBizCodeEnum.VIRTUAL_SALE, "5816", "Game digital entertainment"),
    /**
	 * Network virtual service
	 */
    M5815(MerchantBizCodeEnum.VIRTUAL_SALE, "5815", "Network virtual service"),
    
    /**
	 * Network virtual service
	 */
    M5310(MerchantBizCodeEnum.VIRTUAL_SALE, "5310", "To promote sales"),

    /**
	 * Travel ticket
	 */
    M4722(MerchantBizCodeEnum.VIRTUAL_SALE, "4722", "Travel ticket"),
    
    /**
	 * lottery
	 */
    M9406(MerchantBizCodeEnum.VIRTUAL_SALE, "9406", "lottery"),
    
    /**
	 * Intermediary/consulting services
	 */
    M7277(MerchantBizCodeEnum.VIRTUAL_SALE, "7277", "Intermediary/consulting services"),
    
    /**
	 * Life service
	 */
    M7230(MerchantBizCodeEnum.VIRTUAL_SALE, "7230", "Life service"),
    
    /**
   	 * More credit
   	 */
    M4814(MerchantBizCodeEnum.VIRTUAL_SALE, "4814", "More credit"),
    
    /**
   	 * More credit
   	 */
    M7997(MerchantBizCodeEnum.VIRTUAL_SALE, "7997", "Electronic gift card vouchers"),
    
    /**
   	 * Rental cars
   	 */
    M4121(MerchantBizCodeEnum.VIRTUAL_SALE, "4121", "Rental cars"),
    
    /**
   	 * The gas card is recharged
   	 */
    M5541(MerchantBizCodeEnum.VIRTUAL_SALE, "5541", "The gas card is recharged"),
    
    /**
   	 * Entertainment ticketing
   	 */
    M7922(MerchantBizCodeEnum.VIRTUAL_SALE, "7922", "Entertainment ticketing"),
    
    /**
   	 * Network social platform/Intellectual property rights
   	 */
    M7993(MerchantBizCodeEnum.VIRTUAL_SALE, "7993", "Entertainment ticketing/Intellectual property rights"),
    
    /**
   	 * Virtual class others
   	 */
    M7999(MerchantBizCodeEnum.VIRTUAL_SALE, "7999", "Virtual class others"),
    
    /**
   	 * Business travel tickets
   	 */
    //M4722(MerchantBizCodeEnum.VIRTUAL_SALE, "4722", "Business travel tickets"),
    
    /**
   	 * The hotel
   	 */
    M7011(MerchantBizCodeEnum.VIRTUAL_SALE, "7011", "The hotel"),
    
    /**
   	 * The insurance company
   	 */
    M6300(MerchantBizCodeEnum.VIRTUAL_SALE, "6300", "The insurance company"),
    
    /**
   	 * Technology development/software services
   	 */
    M5734(MerchantBizCodeEnum.VIRTUAL_SALE, "5734", "Technology development/software services"),
    
    /**
   	 * credit/Consumption in installment
   	 */
    M6012(MerchantBizCodeEnum.VIRTUAL_SALE, "6012", "credit/Consumption in installment"),
    
    /**
   	 * Car rental business
   	 */
    M3351(MerchantBizCodeEnum.VIRTUAL_SALE, "3351", "Car rental business"),
    
    /**
   	 * Rental business/The real estate
   	 */
    M6513(MerchantBizCodeEnum.VIRTUAL_SALE, "6513", "Rental business/The real estate"),
    
    /**
   	 * Logistics service
   	 */
    M4215(MerchantBizCodeEnum.VIRTUAL_SALE, "4215", "Logistics service"),
    
    /**
   	 * decorate
   	 */
    M7217(MerchantBizCodeEnum.VIRTUAL_SALE, "7217", "decorate"),
    
    /**
   	 * lease
   	 */
    M7394(MerchantBizCodeEnum.VIRTUAL_SALE, "7394", "decorate"),
    
    /**
   	 * Recycling business
   	 */
    M5931(MerchantBizCodeEnum.VIRTUAL_SALE, "5931", "Recycling business"),
    
    /**
   	 * Education/fees
   	 */
    M8220(MerchantBizCodeEnum.VIRTUAL_SALE, "8220", "Education/fees"),
    
    /**
   	 * Utility bill
   	 */
    M7392(MerchantBizCodeEnum.VIRTUAL_SALE, "7392", "Utility bill"),
    
    /**
   	 * Public welfare charity
   	 */
    M8398(MerchantBizCodeEnum.VIRTUAL_SALE, "8398", "Public welfare charity"),
    
    /**
   	 * Medical services
   	 */
    M5047(MerchantBizCodeEnum.VIRTUAL_SALE, "5047", "Medical services"),
    
    /**
   	 * Clothing accessories
   	 */
    M5137(MerchantBizCodeEnum.PHYSICAL_SALE, "5137", "Clothing accessories"),
    
    /**
   	 * Books/videos/stationery
   	 */
    M5192(MerchantBizCodeEnum.PHYSICAL_SALE, "5192", "Books/videos/stationery"),
    
    /**
   	 * Digital home appliances
   	 */
    M5722(MerchantBizCodeEnum.PHYSICAL_SALE, "5722", "Digital home appliances"),
    
    /**
   	 * Gifts/health care products
   	 */
    M5947(MerchantBizCodeEnum.PHYSICAL_SALE, "5947", "Gifts/health care products"),
    
    /**
   	 * drug
   	 */
    M5122(MerchantBizCodeEnum.PHYSICAL_SALE, "5122", "drug"),
    
    /**
   	 * drug
   	 */
    M5970(MerchantBizCodeEnum.PHYSICAL_SALE, "5970", "Collection/crafts"),
    
    /**
   	 * Food/agricultural products
   	 */
    M5499(MerchantBizCodeEnum.PHYSICAL_SALE, "5499", "Food/agricultural products"),
    
    /**
   	 * The direct selling company
   	 */
    M5964(MerchantBizCodeEnum.PHYSICAL_SALE, "5964", "The direct selling company"),
    
    /**
   	 * Home improvement
   	 */
//    M5712(MerchantBizCodeEnum.PHYSICAL_SALE, "5712", "Home improvement"),
    
    /**
   	 * Machinery and equipment
   	 */
    M5072(MerchantBizCodeEnum.PHYSICAL_SALE, "5072", "Machinery and equipment"),
    
    /**
   	 * Cosmetics/skin care
   	 */
    M5977(MerchantBizCodeEnum.PHYSICAL_SALE, "5977", "Cosmetics/skin care"),
    
    /**
   	 * jewelry
   	 */
    M5094(MerchantBizCodeEnum.PHYSICAL_SALE, "5094", "jewelry"),
    
    /**
   	 * Comprehensive shopping mall
   	 */
    M5311(MerchantBizCodeEnum.PHYSICAL_SALE, "5311", "Comprehensive shopping mall"),
    
    /**
   	 * Chemical goods
   	 */
    M5169(MerchantBizCodeEnum.PHYSICAL_SALE, "5169", "Chemical goods"),
    
    /**
   	 * wholesale
   	 */
    M5300(MerchantBizCodeEnum.PHYSICAL_SALE, "5300", "wholesale"),
    
    /**
   	 * Object class others
   	 */
    M5131(MerchantBizCodeEnum.PHYSICAL_SALE, "5131", "Object class others"),
    
    /**
   	 * Car sales
   	 */
    M5511(MerchantBizCodeEnum.PHYSICAL_SALE, "5511", "Car sales"),
    
    /**
   	 * Game digital entertainment
   	 */
    Mother(MerchantBizCodeEnum.VIRTUAL_SALE, "other", "Game digital entertainment");

    private static final Map<String, MccEnum> CODE_MAP = new HashMap<>();

    static {
        for (MccEnum cardBrandEnum : MccEnum.values()) {
            CODE_MAP.put(cardBrandEnum.code, cardBrandEnum);
        }
    }

    private MccEnum(MerchantBizCodeEnum bizCode, String code, String desc) {
		this.bizCode = bizCode;
		this.code = code;
		this.desc = desc;
	}

	public static final boolean contains(String value) {
        if (value != null) {
        	return CODE_MAP.containsKey(value.trim());
        }
        return false;
    }

    public static final MccEnum getEnumByValue(String value) {
        if (value == null) {
            return null;
        }
        return getEnumByCode(value);
    }

    public static final MccEnum getEnumByCode(String code) {
        if (code != null) {
            return CODE_MAP.get(code.trim());
        }
        return null;
    }
    MerchantBizCodeEnum bizCode;
    String code;
    String desc;

    public String getCode() {
        return code;
    }

	public MerchantBizCodeEnum getBizCode() {
		return bizCode;
	}

	public void setBizCode(MerchantBizCodeEnum bizCode) {
		this.bizCode = bizCode;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public void setCode(String code) {
		this.code = code;
	}
}
