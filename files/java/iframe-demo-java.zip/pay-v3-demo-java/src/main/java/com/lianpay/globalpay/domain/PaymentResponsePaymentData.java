package com.lianpay.globalpay.domain;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class PaymentResponsePaymentData implements Serializable {
	private static final long serialVersionUID = 8891781782121L;
	@JSONField(name = "payment_currency_code")
	@JsonProperty("payment_currency_code")
    private String paymentCurrencyCode;
	@JSONField(name = "payment_amount")
	@JsonProperty("payment_amount")
    private String paymentAmount;
	@JSONField(name = "exchange_rate")
	@JsonProperty("exchange_rate")
    private String exchangeRate;
	@JSONField(name = "payment_time")
	@JsonProperty("payment_time")
    private String paymentTime;
	@JSONField(name = "payment_status")
	@JsonProperty("payment_status")
    private String paymentStatus;
	@JSONField(name = "settlement_currency_code")
	@JsonProperty("settlement_currency_code")
    private String settlementCurrencyCode;
	@JSONField(name = "settlement_amount")
	@JsonProperty("settlement_amount")
    private String settlementAmount;
	@JSONField(name = "installments")
	@JsonProperty("installments")
    private String installments;
	@JSONField(name = "account_date")
	@JsonProperty("account_date")
    private String accountDate;

    public String getPaymentCurrencyCode() {
        return paymentCurrencyCode;
    }

    public void setPaymentCurrencyCode(String paymentCurrencyCode) {
        this.paymentCurrencyCode = paymentCurrencyCode;
    }

    public String getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(String paymentAmount) {
        this.paymentAmount = paymentAmount;
    }
    
    public String getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(String exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public String getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(String paymentTime) {
        this.paymentTime = paymentTime;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getSettlementCurrencyCode() {
        return settlementCurrencyCode;
    }

    public void setSettlementCurrencyCode(String settlementCurrencyCode) {
        this.settlementCurrencyCode = settlementCurrencyCode;
    }

    public String getSettlementAmount() {
        return settlementAmount;
    }

    public void setSettlementAmount(String settlementAmount) {
        this.settlementAmount = settlementAmount;
    }

    public String getInstallments() {
        return installments;
    }

    public void setInstallments(String installments) {
        this.installments = installments;
    }

    public String getAccountDate() {
        return accountDate;
    }

    public void setAccountDate(String accountDate) {
        this.accountDate = accountDate;
    }
}
