package com.lianpay.globalpay;

import lombok.Builder;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

@Component
public class PayConfig {
	
    @Value("${llp.api.baseUrl}")
	private String apiBaseUrl;

    @Value("${llp.merchants.directapi.id}")
    private String directApiMerchantId;
    @Value("${llp.merchants.directapi.privateKey}")
    private String directApiPrivateKey;
    @Value("${llp.merchants.directapi.publicKey}")
    private String directApiPublicKey;
    @Value("${llp.merchants.directapi.llPublicKey}")
    private String directApiLlPublicKey;

    @Value("${llp.merchants.cashier.id}")
    private String cashierMerchantId;
    @Value("${llp.merchants.cashier.privateKey}")
    private String cashierPrivateKey;
    @Value("${llp.merchants.cashier.publicKey}")
    private String cashierPublicKey;
    @Value("${llp.merchants.cashier.llPublicKey}")
    private String cashierLlPublicKey;
    
    @Value("${llp.merchants.iframe.id}")
    private String iframeMerchantId;
    @Value("${llp.merchants.iframe.privateKey}")
    private String iframePrivateKey;
    @Value("${llp.merchants.iframe.publicKey}")
    private String iframePublicKey;
    @Value("${llp.merchants.iframe.testPage}")
    private String iframeTestPage;
    
    @Value("${llp.merchants.iframe.llPublicKey}")
    private String iframeLlPublicKey;

    private Map<String, MerchantConfig> merchantConfig = new HashMap<>();

    @PostConstruct
    public void init() {
        merchantConfig.put(directApiMerchantId, MerchantConfig.builder().integrationModel("api")
                .llPublicKey(directApiLlPublicKey).privateKey(directApiPrivateKey).publicKey(directApiPublicKey)
                .merchantId(directApiMerchantId).build());
        merchantConfig.put(cashierMerchantId, MerchantConfig.builder().integrationModel("cashier")
                .publicKey(cashierPublicKey).privateKey(cashierPrivateKey).llPublicKey(cashierLlPublicKey)
                .merchantId(cashierMerchantId).build());
        merchantConfig.put(iframeMerchantId, MerchantConfig.builder().integrationModel("iframe")
                .publicKey(iframePublicKey).privateKey(iframePrivateKey).llPublicKey(iframeLlPublicKey)
                .merchantId(iframeMerchantId).build());
    }

    public MerchantConfig getMerchantConfig(String merchantId) {
        return merchantConfig.get(merchantId);
    }

    public String getIframeTestPage(String key){
    	return String.format(iframeTestPage, key);
    }
    
    public String getApiBaseUrl(){
    	return apiBaseUrl;
    }
    
    @Data
    @Builder
    public static class MerchantConfig {
        private String merchantId;
        private String publicKey;
        private String privateKey;
        private String llPublicKey;
        private String integrationModel;
        private String symmetricKey;
    }
}
