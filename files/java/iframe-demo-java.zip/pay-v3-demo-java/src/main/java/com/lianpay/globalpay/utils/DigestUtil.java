package com.lianpay.globalpay.utils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class DigestUtil {

    private final static String DIGEST_ALGORITHM_HMACMD5 = "HmacMD5";

    private final static String DIGEST_ALGORITHM_HMACSHA1 = "HmacSHA1";

    private final static String DIGEST_ALGORITHM_HMAC256 = "HmacSHA256";

    private final static String DIGEST_ALGORITHM_HMAC512 = "HmacSHA512";


    /**
     * HMAC-MD5 摘要算法
     * @param msg
     * @param secretKey
     * @return
     */
    public static String hmacMD5Digest(String msg, String secretKey) throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
        return hmacDigest(msg, secretKey, DIGEST_ALGORITHM_HMACMD5);
    }

    /**
     * HMAC-SHA1 摘要算法
     * @param msg
     * @param secretKey
     * @return
     */
    public static String hmacSHA1Digest(String msg, String secretKey) throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
        return hmacDigest(msg, secretKey, DIGEST_ALGORITHM_HMACSHA1);
    }

    /**
     * HMAC-SHA256 摘要算法
     * @param msg
     * @param secretKey
     * @return
     */
    public static String hmacSHA256Digest(String msg, String secretKey) throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
        return hmacDigest(msg, secretKey, DIGEST_ALGORITHM_HMAC256);
    }

    /**
     * HMAC-SHA512 摘要算法
     * @param msg
     * @param secretKey
     * @return
     */
    public static String hmacSHA512Digest(String msg, String secretKey) throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
        return hmacDigest(msg, secretKey, DIGEST_ALGORITHM_HMAC512);
    }

    private static String hmacDigest(String msg, String secretKey, String algorithm) throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
        String digest = null;
        try {
            SecretKeySpec key = new SecretKeySpec((secretKey).getBytes("UTF-8"), algorithm);
            Mac mac = Mac.getInstance(algorithm);
            mac.init(key);

            byte[] bytes = mac.doFinal(msg.getBytes("ASCII"));

            StringBuffer hash = new StringBuffer();
            for (int i = 0; i < bytes.length; i++) {
                String hex = Integer.toHexString(0xFF & bytes[i]);
                if (hex.length() == 1) {
                    hash.append('0');
                }
                hash.append(hex);
            }
            digest = hash.toString();
        } catch (UnsupportedEncodingException |InvalidKeyException | NoSuchAlgorithmException e) {
            throw e;
        }
        return digest;
    }
    
    public static void main(String[] args){
    	System.out.println(System.currentTimeMillis());
    }
}
