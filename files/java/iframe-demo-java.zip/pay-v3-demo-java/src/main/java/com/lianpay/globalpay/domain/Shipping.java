package com.lianpay.globalpay.domain;

import java.io.Serializable;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Shipping implements Serializable {
	private static final long serialVersionUID = 112131212L;
	@JSONField(name = "name")
    @JsonProperty("name")
    private String name;
	@JSONField(name = "phone")
    @JsonProperty("phone")
    private String phone;
	@JSONField(name = "address")
    @JsonProperty("address")
    private Address address;
    @JsonProperty(value = "cycle")
    @JSONField(name = "cycle")
    private String cycle;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

	public String getCycle() {
		return cycle;
	}

	public void setCycle(String cycle) {
		this.cycle = cycle;
	}
}
