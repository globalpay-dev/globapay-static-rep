package com.lianpay.globalpay.domain;

import java.io.Serializable;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Customer implements Serializable {
	private static final long serialVersionUID = 112131212L;
	@JSONField(name = "customer_type")
	@JsonProperty("customer_type")
    private String customerType;
	@JSONField(name = "first_name")
	@JsonProperty("first_name")
    private String firstName;
	@JSONField(name = "last_name")
    private String lastName;
	@JSONField(name = "full_name")
    private String fullName;
	@JSONField(name = "gender")
    private String gender;
	@JSONField(name = "id_type")
    private String idType;
	@JSONField(name = "id_no")
    private String idNo;
	@JSONField(name = "email")
    private String email;
	@JSONField(name = "phone")
    private String phone;
	@JSONField(name = "company")
    private String company;
	@JSONField(name = "address")
    private Address address;

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }
    
    public String getIdNo() {
        return idNo;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
    
    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
}
