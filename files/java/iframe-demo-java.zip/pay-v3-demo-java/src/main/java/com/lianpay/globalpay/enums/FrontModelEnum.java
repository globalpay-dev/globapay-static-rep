package com.lianpay.globalpay.enums;

import java.util.Arrays;

public enum FrontModelEnum {
    DEFAULT("DEFAULT", "默认"),
    IFRAME("IFRAME", "iFrame");

    private final String code;
    private final String desc;

    public static FrontModelEnum getByCode(String code) {
        return Arrays.stream(FrontModelEnum.values())
                .filter(frontModelEnum -> frontModelEnum.getCode().equals(code))
                .findFirst()
                .orElse(FrontModelEnum.DEFAULT);
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    FrontModelEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
