package com.lianpay.globalpay.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PaymentRequestPaymentData implements Serializable {
	private static final long serialVersionUID = 8891781782121L;
	@JSONField(name = "payment_currency_code")
	@JsonProperty("payment_currency_code")
    private String paymentCurrencyCode;
	@JSONField(name = "payment_amount")
	@JsonProperty("payment_amount")
    private BigDecimal paymentAmount;
	@JSONField(name = "exchange_token")
	@JsonProperty("exchange_token")
    private String exchangeToken;
	@JSONField(name = "exchange_rate")
	@JsonProperty("exchange_rate")
    private BigDecimal exchangeRate;
	@JSONField(name = "settlement_currency_code")
	@JsonProperty("settlement_currency_code")
    private String settlementCurrencyCode;
	@JSONField(name = "installments")
	@JsonProperty("installments")
    private Integer installments;
	@JSONField(name = "card")
	@JsonProperty("card")
    private CardInfo card;

    public String getPaymentCurrencyCode() {
        return paymentCurrencyCode;
    }

    public void setPaymentCurrencyCode(String paymentCurrencyCode) {
        this.paymentCurrencyCode = paymentCurrencyCode;
    }

    public BigDecimal getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(BigDecimal paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public String getExchangeToken() {
        return exchangeToken;
    }

    public void setExchangeToken(String exchangeToken) {
        this.exchangeToken = exchangeToken;
    }

    public BigDecimal getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(BigDecimal exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public String getSettlementCurrencyCode() {
        return settlementCurrencyCode;
    }

    public void setSettlementCurrencyCode(String settlementCurrencyCode) {
        this.settlementCurrencyCode = settlementCurrencyCode;
    }

    public Integer getInstallments() {
        return installments;
    }

    public void setInstallments(Integer installments) {
        this.installments = installments;
    }

    public CardInfo getCard() {
        return card;
    }

    public void setCard(CardInfo card) {
        this.card = card;
    }
}
