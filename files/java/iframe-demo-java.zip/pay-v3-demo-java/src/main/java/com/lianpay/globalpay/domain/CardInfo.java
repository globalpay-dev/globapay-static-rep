package com.lianpay.globalpay.domain;

import java.io.Serializable;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CardInfo implements Serializable {
	private static final long serialVersionUID = 112131212L;
	@JSONField(name = "holder_name")
	@JsonProperty("holder_name")
    private String holderName;
	@JSONField(name = "id_type")
	@JsonProperty("id_type")
    private String idType;
	@JSONField(name = "id_no")
	@JsonProperty("id_no")
    private String idNo;
	@JSONField(name = "card_no")
	@JsonProperty("card_no")
    private String cardNo;
	@JSONField(name = "card_type")
	@JsonProperty("card_type")
    private String cardType;
	@JSONField(name = "bank_code")
	@JsonProperty("bank_code")
    private String bankCode;
	@JSONField(name = "card_brand")
	@JsonProperty("card_brand")
    private String cardBrand;
	@JSONField(name = "card_expiration_year")
	@JsonProperty("card_expiration_year")
    private String cardExpirationYear;
	@JSONField(name = "card_expiration_month")
	@JsonProperty("card_expiration_month")
    private String cardExpirationMonth;
	@JSONField(name = "cvv")
	@JsonProperty("cvv")
    private Integer cvv;
	@JSONField(name = "billing_address")
	@JsonProperty("billing_address")
    private Address billingAddress;
    @JSONField(name = "card_token")
    @JsonProperty("card_token")
    private String cardToken;

    public String getHolderName() {
        return holderName;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNo() {
        return idNo;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getCardBrand() {
        return cardBrand;
    }

    public void setCardBrand(String cardBrand) {
        this.cardBrand = cardBrand;
    }
    
    public String getCardExpirationYear() {
        return cardExpirationYear;
    }

    public void setCardExpirationYear(String cardExpirationYear) {
        this.cardExpirationYear = cardExpirationYear;
    }

    public String getCardExpirationMonth() {
        return cardExpirationMonth;
    }

    public void setCardExpirationMonth(String cardExpirationMonth) {
        this.cardExpirationMonth = cardExpirationMonth;
    }

    public Integer getCvv() {
        return cvv;
    }

    public void setCvv(Integer cvv) {
        this.cvv = cvv;
    }
   
    public Address getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(Address billingAddress) {
        this.billingAddress = billingAddress;
    }

    public String getCardToken() {
        return cardToken;
    }

    public void setCardToken(String cardToken) {
        this.cardToken = cardToken;
    }
}
