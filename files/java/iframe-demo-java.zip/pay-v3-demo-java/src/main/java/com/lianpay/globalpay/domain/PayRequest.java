package com.lianpay.globalpay.domain;

import java.io.Serializable;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PayRequest implements Serializable {
	private static final long serialVersionUID = 8891781782121L;
	@JSONField(name = "merchant_transaction_id")
	@JsonProperty("merchant_transaction_id")
    private String merchantTransactionId;
	@JSONField(name = "merchant_id")
	@JsonProperty("merchant_id")
    private String merchantId;
	@JSONField(name = "sub_merchant_id")
	@JsonProperty("sub_merchant_id")
    private String subMerchantId;
	@JSONField(name = "payment_method")
	@JsonProperty("payment_method")
    private String paymentMethod;
	@JSONField(name = "biz_code")
	@JsonProperty("biz_code")
    private String bizCode;
	@JSONField(name = "additional_info")
	@JsonProperty("additional_info")
    private String additionalInfo;
	@JSONField(name = "notification_url")
	@JsonProperty("notification_url")
    private String notificationUrl;
	@JSONField(name = "redirect_url")
	@JsonProperty("redirect_url")
    private String redirectUrl;
	@JSONField(name = "cancel_url")
	@JsonProperty("cancel_url")
    private String cancelUrl;
	@JSONField(name = "country")
	@JsonProperty("country")
    private String country;
	@JSONField(name = "front_model")
	@JsonProperty("front_model")
    private String frontModel;
    @JSONField(name = "customer")
    @JsonProperty("customer")
    private Customer customer;
    @JSONField(name = "merchant_order")
    @JsonProperty("merchant_order")
    private MerchantOrderInfo merchantOrder;
    @JSONField(name = "payment_data")
    @JsonProperty("payment_data")
    private PaymentRequestPaymentData paymentData;

    public String getMerchantTransactionId() {
        return merchantTransactionId;
    }

    public void setMerchantTransactionId(String merchantTransactionId) {
        this.merchantTransactionId = merchantTransactionId;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getSubMerchantId() {
        return subMerchantId;
    }

    public void setSubMerchantId(String subMerchantId) {
        this.subMerchantId = subMerchantId;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getBizCode() {
        return bizCode;
    }

    public void setBizCode(String bizCode) {
        this.bizCode = bizCode;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getNotificationUrl() {
        return notificationUrl;
    }

    public void setNotificationUrl(String notificationUrl) {
        this.notificationUrl = notificationUrl;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    public String getCancelUrl() {
        return cancelUrl;
    }

    public void setCancelUrl(String cancelUrl) {
        this.cancelUrl = cancelUrl;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public MerchantOrderInfo getMerchantOrder() {
        return merchantOrder;
    }

    public void setMerchantOrder(MerchantOrderInfo merchantOrder) {
        this.merchantOrder = merchantOrder;
    }

    public PaymentRequestPaymentData getPaymentData() {
        return paymentData;
    }

    public void setPaymentData(PaymentRequestPaymentData paymentData) {
        this.paymentData = paymentData;
    }

	public String getFrontModel() {
		return frontModel;
	}

	public void setFrontModel(String frontModel) {
		this.frontModel = frontModel;
	}
}
