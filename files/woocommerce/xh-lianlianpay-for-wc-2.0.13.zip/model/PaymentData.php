<?php
class PaymentData
{
    public $card;
}