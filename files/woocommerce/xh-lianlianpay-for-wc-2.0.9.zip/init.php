<?php
/*
 * Plugin Name: LianlianPay for WooCommerce
 * Description: Accept Credit Cards using LianLianPay.
 * Version: 2.0.9
 * Author: LianLian Global 
 * Author URI:https://acquiring.lianlianpay.com/
 * Text Domain: LianlianPay for WooCommerce
 * WC tested up to: 9.9.9
 */
if (! defined ( 'ABSPATH' )) exit (); // Exit if accessed directly

if (! defined ( 'XH_LIANLIANPAY' )) define ( 'XH_LIANLIANPAY', 'XH_LIANLIANPAY' ); else return;

define('XH_LIANLIANPAY_FILE',__FILE__);
define('XH_LIANLIANPAY_VERSION','1.0.1');
define('XH_LIANLIANPAY_PAYMENT_ID', 'xh-lianlianpay-payment-wc');
define('XH_LIANLIANPAY_DIR',rtrim(plugin_dir_path(XH_LIANLIANPAY_FILE),'/'));
define('XH_LIANLIANPAY_URL',rtrim(plugin_dir_url(XH_LIANLIANPAY_FILE),'/'));
define('XH_LIANLIANOAY_ASSERTS',rtrim(plugin_dir_path(XH_LIANLIANPAY_FILE),'/assets/'));
// define('XH_LIANLIANPAY_SANDBOX_STATIC_URL','https://secure-checkout.lianlianpay-inc.com/test2/llpay.min.js');
define('XH_LIANLIANPAY_SANDBOX_STATIC_URL','https://gacashier.lianlianpay-inc.com/sandbox2/llpay.min.js');
define('XH_LIANLIANPAY_PRODUCTION_STATIC_URL','https://secure-checkout.lianlianpay.com/v2/llpay.min.js');
// define('XH_LIANLIANPAY_SANDBOX_API_URL','http://192.168.130.58:9999/v3/merchants');
define('XH_LIANLIANPAY_SANDBOX_API_URL','https://celer-api.LianLianpay-inc.com/v3/merchants');
define('XH_LIANLIANPAY_PRODUCTION_API_URL','https://gpapi.lianlianpay.com/v3/merchants');
add_filter ( 'plugin_action_links_'.plugin_basename(XH_LIANLIANPAY_FILE),'xh_lianlianpay_payment_plugin_action_links',10,1 );

if(!class_exists('WC_Payment_Gateway')){
    return;
}

function xh_LIANLIANPAY_payment_plugin_action_links($links) {
    return array_merge ( array (
        'settings' => '<a href="' . admin_url ('admin.php?page=wc-settings&tab=checkout&section='.XH_LIANLIANPAY_PAYMENT_ID) . '">Setting</a>'
    ), $links );
}

require_once  'class-xh-lianlianpay-wc-payment-gateway.php';
global $LianlianPay;
$LianlianPay= new LianlianPay ();
