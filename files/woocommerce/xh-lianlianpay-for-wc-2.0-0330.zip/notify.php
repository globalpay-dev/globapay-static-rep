<?php 
define('WP_USE_THEMES', false);
require_once('../../../wp-load.php');

global $woocommerce;
$notify_body = file_get_contents("php://input");
$signature = $_SERVER['HTTP_SIGNATURE'];
$notify_body = preg_replace('/:\s*([0-9]*\.?[0-9]+)/', ': "$1"', $notify_body);
$notifyMsg = json_decode($notify_body, true);
global $LianlianPay;
$order_id=$notifyMsg['merchant_transaction_id'];
$order = wc_get_order($order_id);
if(!$order||(method_exists($order, 'is_paid')?$order->is_paid():in_array($order->get_status(),  array( 'processing', 'completed' )))){
    echo json_encode(['code'=>200,'msg'=>"success"]);
	exit;
}
error_log("进入异步通知");
if (empty($signature)) {
    error_log("签名为空");
    echo json_encode(['code'=>401,'msg'=>"error"]);
} else {
    error_log("进行通知");

    if ($notifyMsg['payment_data']['exchange_rate']) {
        $notifyMsg['payment_data']['exchange_rate'] = sprintf('%.8f', $notifyMsg['payment_data']['exchange_rate']);
    }
    $notifyMsg['payment_data']['payment_amount'] = sprintf('%.2f', $notifyMsg['payment_data']['payment_amount']);
    if ($notifyMsg['payment_data']['settlement_amount']) {
        $notifyMsg['payment_data']['settlement_amount'] = sprintf('%.2f', $notifyMsg['payment_data']['settlement_amount']);
    }
    $check_result = $LianlianPay->verifySignForLianlian($notifyMsg, $signature, $LianlianPay->get_option('public_key'));
    if (!$check_result) {
        echo json_encode(['code'=>401,'msg'=>"error"]);
    } else {
        
        $payment_status = $notifyMsg['payment_data']['payment_status'];
        if ($payment_status == 'PS') {
            $woocommerce->cart->empty_cart();
            //$order->payment_complete ($notifyMsg['ll_transaction_id']);
            $order->update_status("processing");
            echo json_encode(['code'=>200,'msg'=>"success"]);
        }
    }
}