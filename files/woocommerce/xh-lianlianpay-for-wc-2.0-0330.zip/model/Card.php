<?php
class Card
{
    public $billing_address;
    public $holder_name;
    public $card_token;
}