<?php

/**
 * @Author: chengzh
 * @Date:   2021-08-03 19:47:50
 * @Last Modified by:   chengzh
 * @Last Modified time: 2021-08-06 15:46:49
 */

if (!defined('ABSPATH')) {
  exit;
}
require_once 'abstract-xh-lianlianpay-wc-payment-gateway.php';
class LianlianPay extends Abstract_XH_LianlianPay_Payment_Gateway
{

    public $token;
  /**
   * LianlianPay constructor.
   *
   */
  public function __construct()
  {

    //定义类属性
    $this->id = XH_LIANLIANPAY_PAYMENT_ID;//支付网关插件ID
    $this->icon = '';//将显示在结帐页面上您的网关名称附近的图标的URL
    $this->has_fields = true;//如果您需要自定义信用卡形式
    $this->method_title = 'LianlianPay';
    $this->method_description = 'LianlianPay'; // 将显示在选项页面上


    //初始化设置
    $this->init_form_fields();// 具有所有选项字段的方法
    $this->init_settings(); // Load the settings

    //将选项附加到类属性
    $this->title = $this->get_option('title');
    $this->description = $this->get_option('description');
    $this->instructions  = $this->get_option('instructions');
    $this->enabled = $this->get_option('enabled');

    $this->testmode = 'yes' === $this->get_option( 'testmode' );
    $this->private_key = $this->get_option( 'private_key' );
    $this->public_key = $this->get_option( 'public_key' );

    //这个动作挂钩将LianLianPay注册为WooCommerce支付网关
    add_filter('woocommerce_payment_gateways', array($this, 'woocommerce_add_gateway'));

    //这个动作挂钩保存选项设置
    add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

    //我们需要自定义JavaScript以获得令牌
    add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );
  }

  public function woocommerce_add_gateway($methods)
  {
    $methods[] = $this;
    return $methods;
  }

  /**
   * 插件选项
   *
   */
  function init_form_fields()
  {
    $this->form_fields = array(
      'enabled' => array(
        'title' => "Enable/Disable",
        'type' => 'checkbox',
        'default' => 'no',
        'section' => 'default',
        'description'=>'Enable LianLianPay Gateway'
      ),
      'testmode' => array(
        'title' => "TestMode",
        'type' => 'checkbox',
        'default' => 'no',
        'section' => 'default',
        'description'=>'Enable TestMode'
      ),
      'title' => array(
        'title' => "name",
        'type' => 'text',
        'default' =>  "LianLian Credit/Debit Payment",
        'desc_tip' => true,
        'description'=>'This controls the title which the user sees during checkout.',
        'css' => 'width:400px',
        'section' => 'default'
      ),
      'description' => array(
        'title' => "describe",
        'type' => 'textarea',
        'desc_tip' => true,
        'css' => 'width:400px',
        'section' => 'default'
      ),
      'instructions' => array(
        'title'       => "instructions",
        'type'        => 'textarea',
        'css' => 'width:400px',
        'default'     => '',
        'section' => 'default'
      ),
      'merchant_id' => array(
        'title' => 'merchant_id',
        'type' => 'text',
        'default' =>  "",
        'css' => 'width:400px',
        'section' => 'default'
      ),
      'private_key' => array(
        'title' => "private_key",
        'type' => 'textarea',
        'default' =>  "",
        'css' => 'width:400px',
        'section' => 'default'
      ),
      'public_key' => array(
        'title' => "public_key",
        'type' => 'textarea',
        'default' =>  "",
        'css' => 'width:400px',
        'section' => 'default'
      )
      // 'mcc' => array(
      //   'title' => 'mcc',
      //   'default' => '5137',
      //   'type' => 'text',
      //   'css' => 'width:400px',
      //   'section' => 'default'
      // )
    );
  }


  /**
   * 自定义CSS和JS
   */
  public function payment_scripts() {
    error_log("payment_scripts\n");

    // 我们需要JavaScript仅在购物车/结帐页面上处理令牌，对吗？
   if ( ! is_cart() && ! is_checkout() && ! isset( $_GET['pay_for_order'] ) ) {
      return;
    }

    // 如果我们的付款网关被禁用，无需引入JavaScript
    if ( 'no' === $this->enabled ) {
      return;
    }

    // 如果没有设置API密钥，无需引入JavaScript
    if ( empty( $this->private_key ) || empty( $this->public_key ) ) {
       wc_add_notice(  "Please set private_key or public_key of lianlianpay", 'error' );
      return;
    }

    $result = $this->getToken();
    error_log(json_encode($result));
    if ($result['return_code'] != "SUCCESS" && empty($result['order'])) {
        wc_add_notice(  $result['return_message'], 'error' );
      return;
    }
    $this->update_option('description',$result['order']);

    // 这是我们在您的插件目录中使用的自定义js，它和llpay.js 一起工作
    wp_register_script( 'woocommerce_llpay', plugins_url( 'assets/js/llpay.js', __FILE__ ), array( 'jquery' ) );

    // 在大多数支付处理器中，您必须使用PUBLIC KEY来获得令牌
    wp_localize_script( 'woocommerce_llpay', 'llpay_params', array(
        'key' =>  $this->get_option('description')
    ) );
    wp_enqueue_script( 'woocommerce_llpay' );
  }

  /**
   * 自定义信用卡表格
   */
  public function payment_fields() {
    global $woocommerce;
    $total =  $woocommerce->cart->total;
    $currency_code = get_woocommerce_currency();
    error_log("payment_fields\n");

    if ($this->testmode == 'yes') {
      $js_url = XH_LIANLIANPAY_SANDBOX_STATIC_URL;
    } else {
      $js_url = XH_LIANLIANPAY_PRODUCTION_STATIC_URL;
    }

    // 如果希望您的自定义支付网关支持它，请添加此操作挂钩
   // do_action( 'woocommerce_credit_card_form_start', $this->id );
    echo '
        <div id="set-token"></div>
        <div id="set-payment_method"></div>
        <!-- 集成LLPAY的Iframe. -->
        <div class="llpay-iframe">
          <div>
            <div id="card-element"></div>
          </div>
        </div>
        <div style="display: none!important;">
          <Button id="submit-btn">Pay</Button>
        </div>
       <script src="'.$js_url.'"></script>
       <script>
            var style = {
        base: {
            // 如若修改，请修改 \'   \'之间的内容
            // 背景颜色， 不建议修改
            backgroundColor: \'#fff\',
            // 边框颜色
            bolderColor: \'#ddd\',
            // 字体颜色
            color: \'#666\',
            // 字体大小，最好别超过 16px
            fontSize: \'14px\',
            // 字体粗细：400或600或900
            fontWeight: \'400\',
            // 字体风格
            fontFamily: \'Roboto, Open Sans, Segoe UI, sans-serif\',
            // 字体平滑度，不建议修改
            fontSmoothing: \'antialiased\',
            // 当用户输入数字时，初始化的字体会上移，此处是设置上移的文字
            // 上移字体大小，此处不建议改
            floatLabelSize: \'12px\',
            // 上移字体颜色
            floatLabelColor: \'#666\',
            // 上移字体粗细
            floatLabelWeight: \'bold\',
        },
    };
    // 构建一个元素实例. 默认为生产环境不用传env参数
    var card = LLP.elements().create(\'card\', {
        token:"'. $this->get_option('description').'",
        style: style,
        apiType: "", 
        merchantUrl: window.location.href,
        transactionInfo: {
          totalPrice:"'.$total.'",
          currencyCode: "'.$currency_code.'",
        }
    });
    // 将构建的元素实例插入到#card-element的div中。如果用户希望得到loading的状态返回，则需要加then。
    card.mount(\'#card-element\').then(function(result) {});
       </script>
        ';
    // 我建议使用Inique ID，因为其他网关可能已经使用#ccNo, #expdate, #cvc
    // do_action( 'woocommerce_credit_card_form_end', $this->id );
  }



  /**
   * 自定义字段验证
   *
   */
  public function validate_fields() {
    error_log("validate_fields\n");
    return true;
  }


  /**
   * 处理付款
   * @param int $order_id
   * @return array
   */
  public function process_payment($order_id)
  {
    global $woocommerce;
    error_log("process_payment\n");
    $order = wc_get_order($order_id);
    if (!$order) {
      return array(
        'result'   => 'success',
        'redirect' => wc_get_checkout_url()
      );
    }
    if ((method_exists($order, 'is_paid') ? $order->is_paid() : in_array($order->get_status(),  array('processing', 'completed')))) {
        // 空购物车
        $woocommerce->cart->empty_cart();
        return array(
            'result'   => 'success',
            'redirect' => $this->get_return_url($order)
          );
    }

    error_log( 'card_token:'.$_POST['llpay_token']);
    $result = $this->generate_lianlianpay_order($order,$_POST['llpay_token'],$_POST['llpay_payment_method']);
    error_log(json_encode($result));
    if ($result['return_code'] != "SUCCESS" && $result['return_code'] != "PAYMENT_COMPLETED") {
      //判断是否支付失败,支付失败在前端提示

      // 多语言后续需优化
      $error = array(
        "payment_data.card.holder_name" => "cardholder's name is invalid",
        "payment_data.card.card_brand" => "card brand is invalid",
        "payment_data.card.card_no" => "card number is invalid",
        "payment_data.card.card_expiration_year" => "card expires date is invalid",
        "payment_data.card.card_expiration_month" => "card expires date is invalid",
        "payment_data.card.billing_address.city" => "city in billing address is invalid",
        "payment_data.card.billing_address.state" => "state in billing address is invalid",
        "payment_data.card.billing_address.country" => "country in billing address is invalid",
        "payment_data.card.billing_address.postal_code" => "postal code in billing address is invalid",
        "merchant_order.shipping.address.city" => "city in shipping address is invalid",
        "merchant_order.shipping.address.state" => "state in shipping address is invalid",
        "merchant_order.shipping.address.country" => "country in shipping address is invalid",
        "merchant_order.shipping.address.postal_code" => "postal code in shipping address is invalid"
      );

      $error_message = "Sorry, please check your inputs and try again.<br />";
      $error_status = true;
      foreach ($error as $key => $value) {
        if (strpos($result['return_message'], $key) !== false) {
          $error_message = $error_message.$value."<br />";
          // error_log($value);
          $error_status = false;
        }
      }
      // error_log($error_status);
      if($error_status !== false){
        wc_add_notice($result['return_message'], 'error' );
      }else{
        wc_add_notice($error_message , 'error' );
      }

      // wc_add_notice(  $result['return_message'], 'error' );
      return;
    }

    //判断是否要走3DS,如果是需要3DS跳转到连连收银台
      if(!empty($result['order']['3ds_status']) && $result['order']['3ds_status'] == "CHALLENGE"){
          return array(
              'result' => 'success',
              'redirect' =>  $result['order']['payment_url']
          );
      }

      error_log(json_encode($result));

    //支付成功跳转到支付成功页面
    if ($result['return_code'] = "SUCCESS" || $result['return_code'] = "PAYMENT_COMPLETED") {
      // $order->update_status("completed");
      // 空购物车
      $woocommerce->cart->empty_cart();
      error_log("支付成功");
      // 重定向到“感谢页面”
      return array(
          'result' => 'success',
          'redirect' => $this->get_return_url($order)
      );
    }
    return array(
        'result' => 'success',
        'redirect' => $order->get_checkout_payment_url( $order )
    );
  }


  public function get_notify_url()
  {
    return XH_LIANLIANPAY_URL . '/notify.php';
  }


}
