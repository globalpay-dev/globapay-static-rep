<?php
class Product
{
    // public $product_id;
    // public $name;
    // public $description;
    // public $price;
    // public $quantity;
    // public $category;
    // public $sku;
    // public $url;
    // public $shipping_provider;
    public $product_id = "";
    public $name = "";
    public $description = "";
    public $price = "";
    public $quantity = "";
    public $category = "";
    public $sku = "";
    public $url = "";
    public $shipping_provider = "other";
}