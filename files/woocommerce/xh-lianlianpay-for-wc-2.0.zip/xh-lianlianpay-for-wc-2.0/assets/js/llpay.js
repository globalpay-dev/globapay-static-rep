
// version: 2.0.11
var checkout_form, order_form;

var tokenRequest = function() {
    // 判断选择支付方式
    let selectFlag = !document.getElementsByClassName('payment_method_xh-lianlianpay-payment-wc')[1].style.display;
    if(selectFlag){
        document.getElementById('set-token').innerHTML = '<input id="llpay_token" name="llpay_token" type="hidden" value="">';
        document.getElementById('set-payment_method').innerHTML = '<input id="llpay_payment_method" name="llpay_payment_method" type="hidden" value="inter_credit_card">';
        console.log('tokenRequest');
        // 这将是一个支付网关功能，处理来自表单的所有信用卡数据，
        // 并在成功时触发successCallback()，而在失败时触发errorCallback
        LLP.getValidateResult().then(res => {
            if (res && !res.validateResult) {
                console.log('校验不通过，支付取消')
            }else {
                LLP.confirmPay().then(function (result) {
                    if (result && result.data) {
                        checkout_form.find('#llpay_token').val(result.data);
                    
                        order_form.find('#llpay_token').val(result.data);
                        checkout_form.find("#llpay_payment_method").val('inter_credit_card');
                        order_form.find("#llpay_payment_method").val('inter_credit_card');
                        // console.log(result.data);
                        successCallback(result.data);
                    }else{
                        alert('Failed to acquire card token, please try again later.')
                    }
                });
            }
        });
        return false;
    }
};

var successCallback = function(data) {
    
   
    // 事件解绑
    // 提交表单
    // checkout_form.off( 'checkout_place_order', tokenRequest );
    checkout_form.submit();
    // 订单失败后支付
    // order_form.off('click', '#place_order', tokenRequest);
    order_form.submit();
};

var googlepayListeningCardToken = function () {
  LLP.openListeningLLpayCardToken &&
    LLP.openListeningLLpayCardToken(function (result) {
        document.getElementById("set-token").innerHTML =
        '<input id="llpay_token" name="llpay_token" type="hidden" value="">'; 
        document.getElementById('set-payment_method').innerHTML = '<input id="llpay_payment_method" name="llpay_payment_method" type="hidden" value="google_pay">';
      if (result && result?.code === 200000 && result?.data) {
        checkout_form.find("#llpay_token").val(result.data);

        order_form.find("#llpay_token").val(result.data);

        checkout_form.find("#llpay_payment_method").val('google_pay');
        order_form.find("#llpay_payment_method").val('google_pay');
        // console.log(result.data);
        successCallback(result.data); 
      } else {
        alert("Failed to acquire card token, please try again later.");
      }
    });
};

jQuery(function($){
    checkout_form = $( 'form.woocommerce-checkout' );
    order_form = $( 'form#order_review' );
    // checkout_form.on( 'checkout_place_order', tokenRequest);
    checkout_form.on('click','#place_order', tokenRequest);
    // 处理订单支付失败后，在订单页再次发起支付；
    order_form.on('click', '#place_order', tokenRequest);
    setTimeout(()=>{
        googlepayListeningCardToken();
    }, 100)
    
});
