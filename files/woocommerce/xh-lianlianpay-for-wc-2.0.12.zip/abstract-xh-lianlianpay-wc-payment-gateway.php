<?php
require_once "model/Address.php";
require_once "model/Card.php";
require_once "model/PayRequest.php";
require_once "model/Customer.php";
require_once "model/MerchantOrderInfo.php";
require_once "model/PaymentData.php";
require_once "model/Product.php";
require_once "model/Shipping.php";

abstract class Abstract_XH_LianlianPay_Payment_Gateway extends WC_Payment_Gateway
{

    /**
     * 获取商户Token
     * @return mixed
     */
    public function getToken(){
        if ($this->get_option ( 'testmode' ) == 'yes') {
            $pay_url =XH_LIANLIANPAY_SANDBOX_API_URL.'/'.$this->get_option('merchant_id').'/token';
        } else {
            $pay_url = XH_LIANLIANPAY_PRODUCTION_API_URL.'/'.$this->get_option('merchant_id').'/token';
        }
        $timestamp = date("YmdHis", time());
        $pay_request = new PayRequest();
        $pay_request->merchant_id = $this->get_option('merchant_id');
        $pay_request->timestamp = $timestamp;
        $data_s = $this->object_to_array($pay_request);
        $signature = $this->signForLianlian($data_s, $this->get_option('private_key'));
        $header = array(
            'sign-type: ' . 'RSA',
            'timestamp: ' .$timestamp,
            'timezone: ' . date_default_timezone_get(),
            'Content-Type: ' . 'application/json',
            'signature: ' . $signature
        );
        error_log("获取token入参");
        error_log(json_encode($data_s));
        error_log(json_encode($signature));
        error_log("获取header数据");
        error_log(json_encode($header));

        $response = $this->post($pay_url, $header, $pay_request,'GET');
        return $response;

    }


    /**
     * 创单支付
     * @param $order
     * @param $card_token
     * @return mixed
     */
    public function generate_lianlianpay_order($order,$card_token)
    {
        $order_id = method_exists($order, 'get_id') ? $order->get_id() : $order->id;
        $total = number_format($order->get_total(), 2, '.', '');
        $time = date('YmdHis', time());
        $billing = $order->get_data()["billing"];
        $pay_request = new PayRequest();
        $pay_request->merchant_id = $this->get_option('merchant_id');
        $pay_request->biz_code = 'EC';
        $pay_request->country = $billing['country'];
        //支付成功后异步通知地址，这里模拟商户的接收异常通知请求  请看PayController#paymentSuccess
        $pay_request->notification_url = $this->get_notify_url();
        $pay_request->redirect_url = $this->get_return_url($order);
        //商户发起支付交易的单号，保证唯一
        $pay_request->merchant_transaction_id = $order_id;
        //国际信用iframe 创单时需要手动制定支付方式inter_credit_card
        $pay_request->payment_method = 'inter_credit_card';
        $pay_request->front_model = 'IFRAME';
        $address = new Address();
        $address->city = is_numeric($billing['city']) ? 'NULL' : $billing['city'];
        $address->country = $billing['country'];
        $address->district = empty($billing['address_1']) ? 'default district' : $this->utf8_substr($billing['address_1'], 0, 64);
        $address->line1 = empty($billing['address_1']) ? 'default line1' : $this->utf8_substr($billing['address_1'], 0, 256);
        $address->line2 = empty($billing['address_2']) ? 'default line2' : $this->utf8_substr($billing['address_2'], 0, 256);
        $address->state = empty($billing['state']) ? 'default state' : $this->utf8_substr($billing['state'], 0, 64);
        $address->postal_code = empty($billing['postcode']) ? (strcmp($billing['country'], 'HK') == 0 ? '999077' : '00000') : $billing['postcode'];
        $customer = new Customer();
        $customer->address = $address;
        $customer->customer_type = 'I';
        $customer->full_name = $this->utf8_substr($billing['last_name'] . ' ' . $billing['first_name'], 0, 128);
        $customer->first_name = empty($billing['first_name']) ? '' : $this->utf8_substr($billing['first_name'], 0, 64);
        $customer->last_name = empty($billing['last_name']) ? '' : $this->utf8_substr($billing['last_name'], 0, 64);
        $customer->email=  $billing['email'];
        $customer->phone=  empty($billing['phone']) ? '' : $this->utf8_substr($billing['phone'], 0, 32);
        $pay_request->customer = $customer;
        $products = $this->get_order_products($order);
        $shipping = new Shipping();
        $shipping->address = $address;
        $shipping->name = $this->utf8_substr($billing['last_name'] . ' ' . $billing['first_name'], 0, 128);
        $shipping->phone = empty($billing['phone']) ? '' : $this->utf8_substr($billing['phone'], 0, 32);
        $shipping->cycle = '48h';

        $merchant_order_info = new MerchantOrderInfo();
        //此为商户系统的订单号，支付订单号和支付交易单号可以传一样
        $merchant_order_info->merchant_order_id = $order_id;
        $merchant_order_info->merchant_order_time = $time;
        $merchant_order_info->order_amount = $total;
        $merchant_order_info->order_currency_code = $order->get_currency();
        $merchant_order_info->order_description = $this->utf8_substr($this->get_order_title($order), 0, 256);
        $merchant_order_info->products = $products;
        // $merchant_order_info->mcc = $this->get_option('mcc');
        $merchant_order_info->shipping = $shipping;
       	//$merchant_order_info->merchant_user_no=  get_current_user_id();
        if (get_current_user_id() === 0) {

        } else {
	        $merchant_order_info->merchant_user_no=  get_current_user_id();
        }
	    $pay_request->merchant_order = $merchant_order_info;

        $card = new Card();
        $card->holder_name= $this->utf8_substr($billing['last_name'] . ' ' . $billing['first_name'], 0, 128);
        $card->billing_address = $address;
        $card->card_token = $card_token;
        $payment_data = new PaymentData();
        $payment_data->card = $card;
        $pay_request->payment_data = $payment_data;
        //$pay_request->timestamp = $time;
        if ($this->get_option ( 'testmode' ) == 'yes') {
            $pay_url =XH_LIANLIANPAY_SANDBOX_API_URL.'/'.$this->get_option('merchant_id').'/payments';
        } else {
            $pay_url =XH_LIANLIANPAY_PRODUCTION_API_URL.'/'.$this->get_option('merchant_id').'/payments';
        }
        $data_r = $this->object_to_array($pay_request);
        $signature = $this->signForLianlian($data_r, $this->get_option('private_key'));
	// error_log("打印签名");
	// error_log(json_encode($signature));
        $header = array(
            'sign-type: ' . 'RSA',
            'timestamp: ' .$time,
            'timezone: ' . date_default_timezone_get(),
            'Content-Type: ' . 'application/json',
            'signature: ' . $signature
        );
        error_log("=====发送请求=====");
        error_log(json_encode( $pay_request));
        $response = $this->post($pay_url, $header, $pay_request,'POST');
        return $response;
    }

    protected function utf8_substr($str,$start=0) {
        if(empty($str)){
            return false;
        }
        if (function_exists('mb_substr')){
            if(func_num_args() >= 3) {
                $end = func_get_arg(2);
                return mb_substr($str,$start,$end,'utf-8');
            }
            else {
                mb_internal_encoding("UTF-8");
                return mb_substr($str,$start);
            }

        }
        else {
            $null = "";
            preg_match_all("/./u", $str, $ar);
            if(func_num_args() >= 3) {
                $end = func_get_arg(2);
                return join($null, array_slice($ar[0],$start,$end));
            }
            else {
                return join($null, array_slice($ar[0],$start));
            }
        }
    }

    protected function get_order_products($order)
    {
        error_log("===========订单信息========");
        $productList = array();
        foreach ($order->get_items() as $item) {
            $item_data = $item->get_data();
            if(wc_get_product($item_data['variation_id'])){
                error_log("====存在变体====");
                $product = wc_get_product($item_data['variation_id']);
            }else{
                error_log("====唯一产品，无变体====");
                $product = wc_get_product($item_data['product_id']);
            }
            error_log($product);
            $tmp = new Product();
            if (isset($item_data['name']) && !empty($item_data['name'])) {
                $tmp->name = $this->utf8_substr($item_data['name'], 0, 512);
            }
            if (isset($item_data['product_id']) && !empty($item_data['product_id'])) {
                $tmp->product_id = $this->utf8_substr($item_data['product_id'], 0, 64);
            }
            if (!empty($product->get_price())) {
                //$tmp->price = $product->get_price();
                $tmp->price = number_format($product->get_price(), 2, '.', '');
            }
            if (isset($item_data['quantity']) && !empty($item_data['quantity'])) {
                $tmp->quantity = floor($item_data['quantity']);
            }
            // if (!empty($product->get_sku())) {
            $tmp->sku = $product->get_sku() === "" ? "default_sku" : $this->utf8_substr($product->get_sku(), 0, 128);
            // }
            if(!empty($product->get_description())){
                $tmp->description =  $this->utf8_substr($product->get_description(),0,128);
            }
            $category = wc_get_product_category_list($item_data['product_id']) === "" ? "default_category" : wc_get_product_category_list($item_data['product_id']);
            if(!empty($category)){
                $category = htmlspecialchars_decode($category);
                $tmp->category =  preg_replace("/<a[^>]*>(.*?)<\/a>/is",'$1',$category) ;
                $tmp->category = $this->utf8_substr($tmp->category, 0, 64);
            }
            $tmp->shipping_provider = $order->get_shipping_method() === "" ? "other" : $this->utf8_substr($order->get_shipping_method(), 0, 64);
            $tmp->url = $this->utf8_substr(get_permalink( $tmp->product_id ), 0, 256);
            $productList[] = $tmp;
        }
        return $productList;
    }

    public function object_to_array($obj)
    {
        $_arr = is_object($obj) ? get_object_vars($obj) : $obj;
        $arr = null;
        foreach ($_arr as $key => $val) {
            $val = (is_array($val)) || is_object($val) ? $this->object_to_array($val) : $val;
            $arr[$key] = $val;
        }
        return $arr;
    }

    public function signForLianlian(&$data, $privateKey)
    {
	$signContent = $this->genSignContent($data);
	
	return $this->genSign($signContent, $privateKey);
    }

    public function verifySignForLianlian(&$data, $sign, $pubKey)
    {
        return $this->verifySign($this->genSignContent($data), $sign, $pubKey);
    }
    /**
     * 清除格式
     * @param $key
     * @return string
     */
    public function clearFormat($key)
    {
        $key = str_replace('-----BEGIN RSA PRIVATE KEY-----', '', $key);
        $key = str_replace('-----END RSA PRIVATE KEY-----', '', $key);
        $key = str_replace('-----BEGIN PRIVATE KEY-----', '', $key);
        $key = str_replace('-----END PRIVATE KEY-----', '', $key);
        $key = str_replace('-----BEGIN RSA PUBLIC KEY-----', '', $key);
        $key = str_replace('-----END RSA PUBLIC KEY-----', '', $key);
        $key = str_replace('-----BEGIN PUBLIC KEY-----', '', $key);
        $key = str_replace('-----END PUBLIC KEY-----', '', $key);
        $key = str_replace(PHP_EOL, '', $key);
        $key = preg_replace("/\s/", "", $key);
        $key = trim($key);
        return $key;
    }   

    /**
     * 生成签名内容
     * @param $req
     * @return string
     */
    private function genSignContent(&$req)
    {
        $arr = array($req);
        $strs = array();
        ksort($arr);
        $this->items(0, $arr, $strs);
        $msg = implode('&', $strs);
        return $msg;
    }

    /**
     * 递归深度优先排序
     * @param $x
     * @param $y
     * @param $strs
     */
    private function items($x, $y, &$strs)
    {
        if (is_array($y)) {
            ksort($y);
            foreach ($y as $key => $value) {
                $this->items($key, $value, $strs);
            }
            return;
        }
        if($y === null){
        return;
        }
        $strs[] = $x . "=" . $y;
    }

    /**
     * 生成签名
     * @param $toSign
     * @param $privateKey
     * @return string
     */
    public function genSign($toSign, $privateKey)
    {
        $privateKey = $this->clearFormat($privateKey); 
	//这里他是拼接成和pem文件一样的格式
        $privateKey = "-----BEGIN RSA PRIVATE KEY-----\n" .
            wordwrap($privateKey, 64, "\n", true) .
            "\n-----END RSA PRIVATE KEY-----";
        $key = openssl_get_privatekey($privateKey);
        openssl_sign($toSign, $signature, $key);
        openssl_free_key($key);
        $sign = base64_encode($signature);
        return $sign;
    }

    /**
     * 验证签名
     * @param $data
     * @param $sign
     * @param $pubKey
     * @return bool
     */
    public function verifySign($data, $sign, $pubKey)
    {
        $pubKey = $this->clearFormat($pubKey);  
        $sign = base64_decode($sign);
        $pubKey = "-----BEGIN PUBLIC KEY-----\n" .
            wordwrap($pubKey, 64, "\n", true) .
            "\n-----END PUBLIC KEY-----";

        $key = openssl_pkey_get_public($pubKey);
        $result = openssl_verify($data, $sign, $key, OPENSSL_ALGO_SHA1) === 1;
        return $result;
    }

    /**
     * 发送请求
     * @param $url
     * @param $headers
     * @param $request
     * @return mixed
     */
    public function post($url, $headers, $request,$type)
    {
        $header_res = [];
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $type);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($request));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HEADERFUNCTION,
            function ($curl, $header) use (&$header_res) {
                $len = strlen($header);
                $header = explode(':', $header, 2);
                if (count($header) < 2) // ignore invalid headers
                    return $len;
                $header_res[strtolower(trim($header[0]))][] = trim($header[1]);
                return $len;
            }
        );
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        $response_data = curl_exec($curl);
        $httpStatusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $error = curl_error($curl);
        curl_close($curl);
        $response = json_decode($response_data, true);
        $return_code = $response['return_code'];
        //接口调用失败
        if ($return_code != 'SUCCESS') {
            return $response;
        }
        // 测试环境不做签名校验
        if ($this->get_option ( 'testmode' ) == 'no') {
            // 接口返回数据错误
            if (empty($header_res['signature'][0])) {
                $response['return_message']='warning! no signature, contact LianLianPay';
                return $response;
            }
            $check = $this->verifySignForLianlian($response, $header_res['signature'][0], $this->get_option('public_key'));
            if (!$check) {
                $response['return_message']='warning! signature error, contact LianLianPay';
                return $response;
            }
        }
        return $response;
    }

    /**
     * @param WC_Order $order
     * @param INT $limit
     * @param string $trimmarker
     * @return string
     */
    public function get_order_title($order, $limit = 32, $trimmarker = '...')
    {
        $title = "";
        $order_items = $order->get_items();
        if ($order_items) {
            $qty = count($order_items);
            foreach ($order_items as $item_id => $item) {
                $title .= "{$item['name']}";
                break;
            }
            if ($qty > 1) {
                $title .= '...';
            }
        }

        $title = mb_strimwidth($title, 0, $limit, 'utf-8');
        return apply_filters('xh-payment-get-order-title', $title, $order);
    }

    abstract function get_notify_url();
}
