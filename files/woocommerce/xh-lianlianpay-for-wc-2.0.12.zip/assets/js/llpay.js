
// version: 2.0.11
var checkout_form, order_form;

var tokenRequest = function() {
    // 判断选择支付方式
    let selectFlag = !document.getElementsByClassName('payment_method_xh-lianlianpay-payment-wc')[1].style.display;
    if(selectFlag){
        console.log('tokenRequest');
        // 这将是一个支付网关功能，处理来自表单的所有信用卡数据，
        // 并在成功时触发successCallback()，而在失败时触发errorCallback
        LLP.getValidateResult().then(res => {
            if (res && !res.validateResult) {
                console.log('校验不通过，支付取消')
            }else {
                LLP.confirmPay().then(function (result) {
                    if (result) {
                        checkout_form.find('#llpay_token').val(result.data);
                    
                        order_form.find('#llpay_token').val(result.data);
                        // console.log(result.data);
                        successCallback(result.data);
                    }
                });
            }
        });
        return false;
    }
};

var successCallback = function(data) {
    
   
    // 事件解绑
    // 提交表单
    // checkout_form.off( 'checkout_place_order', tokenRequest );
    checkout_form.submit();
    // 订单失败后支付
    // order_form.off('click', '#place_order', tokenRequest);
    order_form.submit();
};

jQuery(function($){
    checkout_form = $( 'form.woocommerce-checkout' );
    order_form = $( 'form#order_review' );

    // checkout_form.on( 'checkout_place_order', tokenRequest);
    checkout_form.on('click','#place_order', tokenRequest);
    // 处理订单支付失败后，在订单页再次发起支付；
    order_form.on('click', '#place_order', tokenRequest);
    
});
