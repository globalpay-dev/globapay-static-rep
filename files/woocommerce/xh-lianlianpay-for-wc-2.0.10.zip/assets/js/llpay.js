
var checkout_form;

var tokenRequest = function() {
    // 判断选择支付方式
    let selectFlag = !document.getElementsByClassName('payment_method_xh-lianlianpay-payment-wc')[1].style.display;
    if(selectFlag){
        console.log('tokenRequest');
        // 这将是一个支付网关功能，处理来自表单的所有信用卡数据，
        // 并在成功时触发successCallback()，而在失败时触发errorCallback
        LLP.getValidateResult().then(res => {
            if (res && !res.validateResult) {
                console.log('校验不通过，支付取消')
            }else {
                LLP.confirmPay().then(function (result) {
                    // console.log('result',result)
                    if (result) {
                        checkout_form.find('#llpay_token').val(result.data);
                        // console.log(result.data);
                        successCallback(result.data);
                    }
                });
            }
        });
        return false;
    }
};

var successCallback = function(data) {
    // console.log("successCallback");
    // console.log(data);
    // 停用tokenRequest函数事件
    checkout_form.off( 'checkout_place_order', tokenRequest );
    // 现在提交表单
    checkout_form.submit();
};

jQuery(function($){
    checkout_form = $( 'form.woocommerce-checkout' );
    checkout_form.on( 'checkout_place_order', tokenRequest);
});
