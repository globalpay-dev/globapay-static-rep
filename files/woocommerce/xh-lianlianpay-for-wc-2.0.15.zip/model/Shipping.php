<?php
class Shipping
{
    // public $name;
    // public $phone;
    // public $address;
    // public $cycle;
    public $name = "";
    public $phone = "";
    public $address;
    public $cycle = "";
}