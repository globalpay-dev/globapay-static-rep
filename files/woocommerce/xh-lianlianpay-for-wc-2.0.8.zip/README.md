# 版本迭代：
## 2.0.6  
兼容不同的支付方式，包括stripe、paypal

## 2.0.7  
1、移除MCC；
2、当商户不设置sku时，买家仍可发起支付

## 2.0.8
1、解决php版本过低，导致的页面提示Notice

php版本：7.3+
WooCommerce版本：5.6+
wordpress版本：5.8.3+

