<?php
class Customer
{
    // public $customer_type;
    // public $first_name;
    // public $last_name;
    // public $full_name;
    // public $gender;
    // public $id_type;
    // public $id_no;
    // public $email;
    // public $phone;
    // public $company;
    // public $address;
    public $customer_type="";
    public $first_name="";
    public $last_name="";
    public $full_name="";
    public $gender;
    public $id_type;
    public $id_no;
    public $email="";
    public $phone="";
    public $company="";
    public $address;
}