 === LianLian Pay Plugin for Woocommerce ===
Contributors: Lianlian Pay
Tags: payment, paymentgateway, woocommerce, ecommerce, sofortbanking, paysafecard,Wechatpay, alipay, tenpay
Requires at least: 4.0
Tested up to: 5.5.1
Stable tag: 1.0.0
License: The MIT License (MIT)

Official Lianlianpay module for WordPress WooCommerce.

== Description ==
LianLian pay specializes in all-in-one payment solutions with customized products and services offfered in Thailand, who is digging into different vertical areas of the industry, and customizes exclusive industry payment solutions according to the pain points of each.

== Payment method ==
* Credit/Debit card

== How to contact us ==
* Official website: <https://www.lianlianpay.co.th/>
* Technical support team: <cs@lianlianpay.co.th>

== Installation ==

1. Upload the Lianlianpay folder to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin of `Lianlian pay for Woocommerce` through the 'Plugins' screen in WordPress
3. Click `Settings` under `Lianlian pay for Woocommerce` plugin.
4. Fill in your `Merchant ID`` Public Key` and `Secret Key`, Click `Save changes`.

== Screenshots ==

1. Screenshot 1 - Lianlian pay  Settings Page

== Changelog ==

= 1.0.0 =
* Initial stable release

== Upgrade Notice==

= 1.0.0 =
Initial stable release

