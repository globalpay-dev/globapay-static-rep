<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

include_once( 'class-wc-gateway-lianlian-response.php' );


/**
 * Handles responses from Lianlian Notify
 */
class WC_Gateway_Lianlian_Notify_Handler extends WC_Gateway_Lianlian_Response {
	/**
	 * Constructor
	 */
	public function __construct( $sandbox = false) {

            add_action( 'woocommerce_api_wc_gateway_lianlian', array( $this, 'check_response') );


		$this->sandbox = $sandbox;

	}

    public function check_response() {

        $params = array();
        foreach ($_POST as $key => $value) {
            if($key=='signature')
                continue;
            $params[$key] = $value;
        }

        //$_POST  = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
        if (empty($params)) {
            $params_str = file_get_contents("php://input");
            $params = json_decode($params_str, true);
        }

        if ( ! empty( $params )) {

            $posted = wp_unslash($params);
            $status = sanitize_text_field($posted['payment_data']['payment_status']);
            if ($status =='PS') {
                $merchantOrderId = sanitize_text_field($posted['merchant_transaction_id']);
                if ($this->validate_notify($params)) {
                    WC_Gateway_Lianlian_Response::payment_complete($merchantOrderId);
                    //error_log('{"return_message": Success}');
                    echo '{"code": 200, "msg": "success"}';
                    exit;
                } else {
                    wc_add_notice( 'sign error', 'error' );
                    //error_log('sign error: ');
                    WC_Gateway_Lianlian_Response::payment_on_hold($merchantOrderId);
                    echo '{"code": 401, "msg": "error"}';
                    exit;
                }
            }
        }
    }


	/**
	 * Check Lianlian notify validity
	 */
	public function validate_notify($params) {
		
		WC_Gateway_Lianlian::log( 'Checking Notify response is valid' );
		$lianlian = new WC_Gateway_Lianlian();
		$merchantId = $lianlian->get_option('merchant_id');
		$publicKey = $lianlian->get_option('public_key');

        //$sign = sanitize_text_field($_POST['signature']);
        $sign = $_SERVER['HTTP_SIGNATURE'];

        //ksort($params);

        //$check_msg = urldecode(http_build_query( $params, '', '&', PHP_QUERY_RFC3986 ));

        $params['payment_data']['payment_amount'] = sprintf('%.2f', $params['payment_data']['payment_amount']);
        if ($params['payment_data']['exchange_rate']) {
            $params['payment_data']['exchange_rate'] = sprintf('%.8f', $params['payment_data']['exchange_rate']);
        }
        if ($params['payment_data']['settlement_amount']) {
            $params['payment_data']['settlement_amount'] = sprintf('%.2f', $params['payment_data']['settlement_amount']);
        }

        $check_msg = $this->createLinkstring($params);
        $signature = $this->rsa_verify($check_msg, $sign, $publicKey);
		
		return $signature;
	}

    function createLinkstring(array $para) {
        ksort($para);
        $arg  = $this->linkString($para);
        $arg = substr($arg,0,strlen($arg)-1);
        // if(get_magic_quotes_gpc()){$arg = stripslashes($arg);}
        return $arg;
    }

    function linkString(array $para) {
        $arg  = "";
        foreach ($para as $key => $val) {
            if (is_array($val)) {
                ksort($val);
                $arg .= $this->linkString($val);
            } else {
                $arg .= $key . "=" . $val . "&";
            }
        }
        return $arg;
    }
	
	private function rsa_verify($data, $sign, $pubKey, $sign_type=OPENSSL_ALGO_SHA1)
    {

        $pubKey = $this->clearFormat($pubKey);
        $pubKey = chunk_split($pubKey, 64, "\n");
        $key = "-----BEGIN PUBLIC KEY-----\n$pubKey-----END PUBLIC KEY-----\n";
      
        $res = openssl_get_publickey($key);
        $result = openssl_verify($data, base64_decode($sign), $res, $sign_type);

	    openssl_free_key($res);

	    return $result;
    }

    /**
     * @param $key
     * @return string
     */
    public function clearFormat($key)
    {
        $key = str_replace('-----BEGIN RSA PRIVATE KEY-----', '', $key);
        $key = str_replace('-----END RSA PRIVATE KEY-----', '', $key);
        $key = str_replace('-----BEGIN PRIVATE KEY-----', '', $key);
        $key = str_replace('-----END PRIVATE KEY-----', '', $key);
        $key = str_replace('-----BEGIN RSA PUBLIC KEY-----', '', $key);
        $key = str_replace('-----END RSA PUBLIC KEY-----', '', $key);
        $key = str_replace('-----BEGIN PUBLIC KEY-----', '', $key);
        $key = str_replace('-----END PUBLIC KEY-----', '', $key);
        $key = str_replace(PHP_EOL, '', $key);
        $key = preg_replace("/\s/", "", $key);
        $key = trim($key);
        return $key;
    }


	/**
	 * Send a notification to the user handling orders.
	 * @param  string $subject
	 * @param  string $message
	 */
	private function send_email_notification( $subject, $message ) {
		$new_order_settings = get_option( 'woocommerce_new_order_settings', array() );
		$mailer             = WC()->mailer();
		$message            = $mailer->wrap_message( $subject, $message );

		$mailer->send( ! empty( $new_order_settings['recipient'] ) ? $new_order_settings['recipient'] : get_option( 'admin_email' ), $subject, $message );
	}
}
?>
