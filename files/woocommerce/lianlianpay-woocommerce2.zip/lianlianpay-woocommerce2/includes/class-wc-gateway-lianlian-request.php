<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
include_once('class-wc-gateway-lianlian-order.php');

/**
 * Generates requests to send to Lianlian
 */
class WC_Gateway_Lianlian_Request
{

    /**
     * Stores line items to send to Lianlian
     * @var array
     */
    protected $line_items = array();

    /**
     * Pointer to gateway making the request
     * @var WC_Gateway_Lianlian
     */
    protected $gateway;

    /**
     * Endpoint for requests from Lianlian
     * @var string
     */
    protected $notify_url;

    /**
     * Endpoint for requests from Lianlian
     * @var string
     */
    protected $setUrl;

    /**
     * Constructor
     * @param WC_Gateway_Lianlian $gateway
     */
    public function __construct($gateway)
    {
        $this->gateway = $gateway;
        $this->notify_url = WC()->api_request_url('WC_Gateway_Lianlian');
    }


    /**
     * Get the Lianlian request URL for an order
     * @param WC_Order $order
     * @param boolean $sandbox
     * @return string
     */
    public function get_request_url($order, $sandbox = false, $url_redirect)
    {

        $merchantId = $this->gateway->get_merchantid();

        if ($sandbox) {
            $this->setURL = 'https://celer-api.lianlianpay-inc.com/v3/merchants/' . $merchantId . '/payments';
        } else {
            $this->setURL = 'https://gpapi.lianlianpay.com/v3/merchants/' . $merchantId . '/payments';
        }

        $redirectUrl = $this->get_lianlian_args($order, false, $url_redirect);

        return $redirectUrl;

    }

    /**
     * Get Lianlian Args for passing to PP
     *
     * @param WC_Order $order
     * @return array
     */
    public function get_lianlian_args($order, $sandbox = false, $url_redirect)
    {

        $order = new WC_Gateway_Lianlian_Order($order);

        error_log($order->shipping_address_1);
        //error_log(WC()->customer->get_shipping_city());

        WC_Gateway_Lianlian::log('Generating payment form for order ' . $order->get_order_number() . '. Notify URL: ' . $this->notify_url);

        $order_total = number_format($order->order_total, 2, '.', '');
        $order_time = $order->get_date_created()->format('YmdHis');
        $offset = get_option('gmt_offset');
        //$timezone = timezone_name_from_abbr("", $offset, 0);
        $timezone = 'UTC';

        $lianlian = new WC_Gateway_Lianlian();

        $privateKey = $this->gateway->get_privatekey();

        $data = array(
            'merchant_transaction_id' => $order->get_id(),
            'merchant_id' => $this->gateway->get_merchantid(),
            'merchant_order' => array(
                'merchant_order_id' => $order->get_id(),
                'merchant_order_time' => $order_time,
                'order_amount' => $order_total,
                'order_currency_code' => get_woocommerce_currency(),
                'mcc' => $this->gateway->get_mcc(),
                'products' => $this->get_order_products_args($order),
                'shipping' => $this->get_shipping_args($order)
            ),
            'notification_url' => $this->notify_url,
            'redirect_url' => $url_redirect,
            'country' => $this->gateway->get_country(),
            'customer' => $this->get_customer_args($order),
            'payment_data' => array(
                'card' => array('billing_address' => $this->get_billing_address_args($order))
            )
        );


        $payBody = json_encode($data);

        error_log($payBody);

        $paymentOrderSign = $this->signMap($data, $privateKey);


        $url = esc_url($this->setURL);

        $headers = array(
            'sign-type' => 'RSA',
            'signature' => $paymentOrderSign,
            //'timestamp' => $order_time,
            //'timestamp' => date('YmdHis'),
            'timestamp' => gmdate('YmdHis'),
            'timezone' => $timezone
        );

        error_log($headers['timestamp']);

        return $this->post($url, $payBody, $headers);
    }

    protected function get_order_products_args($order)
    {
        $productList = array();
        foreach ($order->get_items() as $item) {
            $item_data = $item->get_data();
            $product = wc_get_product($item_data['product_id']);
            error_log(json_encode($item_data));
            #$item_sku[] = $product->get_sku();
            #error_log(json_encode($item_sku));
            #error_log($item['product_id']);
            #error_log($item['variation_id']);

            #$product_id = $item['product_id'];
            #$product_variation_id = $item['variation_id'];
            #if ($product_variation_id) {
            #    $product = new WC_Product($item['variation_id']);
            #} else {
            #    $product = new WC_Product($item['product_id']);
            #}

            $tmp = array();
            if (isset($item_data['name']) && !empty($item_data['name'])) {
                $tmp['name'] = $item_data['name'];
            }
            if (isset($item_data['product_id']) && !empty($item_data['product_id'])) {
                $tmp['product_id'] = $item_data['product_id'];
            }
            #if (isset($item_data['subtotal']) && !empty($item_data['subtotal'])) {
            #    $tmp['price'] = number_format($item_data['subtotal'], 2);
            #}
            if (!empty($product->get_price())) {
                $tmp['price'] = $product->get_price();
            }
            if (isset($item_data['quantity']) && !empty($item_data['quantity'])) {
                $tmp['quantity'] = floor($item_data['quantity']);
            }
            if (!empty($product->get_sku())) {
                $tmp['sku'] = $product->get_sku();
            }
            $productList[] = $tmp;
        }
        return $productList;
    }

    protected function signMap($params, $privateKey)
    {
        ksort($params);
        $prestr = $this->createLinkstring($params);
        $sign = "";
        $prestr = stripslashes($prestr);
        $sign = $this->rsa_sign($prestr, $privateKey);
        return $sign;
    }

    protected function createLinkstring($para)
    {
        $arg = "";
        $arg = $this->linkString($para);
        $arg = substr($arg, 0, strlen($arg) - 1);
        // if (get_magic_quotes_gpc()) {
        //     $arg = stripslashes($arg);
        // }
        return $arg;
    }

    protected function linkString($para)
    {
        $arg = "";
        foreach ($para as $key => $val) {
            if (is_array($val)) {
                ksort($val);
                $arg .= $this->linkString($val);
            } else {
                $arg .= $key . "=" . $val . "&";
            }
        }
        return $arg;
    }

    private function rsa_sign($data, $priKey, $sign_type = OPENSSL_ALGO_SHA1)
    {
        $priKey = $this->clearFormat($priKey);
        $priKey = chunk_split($priKey, 64, "\n");
        $key = "-----BEGIN RSA PRIVATE KEY-----\n$priKey-----END RSA PRIVATE KEY-----\n";
        $sign = '';
        // $res = openssl_get_privatekey($priKey);
        if (openssl_sign($data, $sign, $key, OPENSSL_ALGO_SHA1)) {
            openssl_free_key(openssl_get_privatekey($key));
            $sign = base64_encode($sign);
        } else {
            error_log('open ssl not passed!');
        }

        return $sign;
    }

    /**
     * @param $key
     * @return string
     */
    public function clearFormat($key)
    {
        $key = str_replace('-----BEGIN RSA PRIVATE KEY-----', '', $key);
        $key = str_replace('-----END RSA PRIVATE KEY-----', '', $key);
        $key = str_replace('-----BEGIN PRIVATE KEY-----', '', $key);
        $key = str_replace('-----END PRIVATE KEY-----', '', $key);
        $key = str_replace('-----BEGIN RSA PUBLIC KEY-----', '', $key);
        $key = str_replace('-----END RSA PUBLIC KEY-----', '', $key);
        $key = str_replace('-----BEGIN PUBLIC KEY-----', '', $key);
        $key = str_replace('-----END PUBLIC KEY-----', '', $key);
        $key = str_replace(PHP_EOL, '', $key);
        $key = preg_replace("/\s/", "", $key);
        $key = trim($key);
        return $key;
    }


    private function post($url = '', $params = '', array $headers = array())
    {
        if (empty($url) || empty($params)) {
            return '{}';
        }

        $header = array(
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
        );

        if (!empty($headers)) {
            $header = array_merge($header, $headers);
        }

        $jsonData = $params;
        $postUrl = $url;

        $args = array(
            'method' => 'POST',
            'timeout' => 30,
            'headers' => $header,
            'httpversion' => '1.0',
            'sslverify' => false,
            'blocking' => true,
            'body' => $jsonData,
            'cookies' => array()
        );

        $data = wp_remote_post($postUrl, $args);
        $httpCode = wp_remote_retrieve_response_code($data);

        if (is_wp_error($data) || $httpCode != 200) {
            error_log('wp_remote_post failed: ' . json_encode($data));
        }

        $response = wp_remote_retrieve_body($data);
        $checkResponse = json_decode($response, true);

        $result = array();
        $result['http_code'] = $httpCode;
        $result['request'] = $jsonData;
        $result['response'] = $response;

        if ($result != null && $checkResponse['return_code'] == 'SUCCESS') {
            return $checkResponse['order']['payment_url'];
        } else {
            wc_add_notice('Response Failed ', 'error');
            wc_add_notice($response, 'error');
            return get_permalink(function_exists('wc_get_page_id') ? wc_get_page_id('checkout') : wc_get_page_id('checkout'));
        }
    }


    /**
     * Get shipping args for Lianlian request
     * @param WC_Order $order
     * @return array
     */
    protected function get_shipping_args($order)
    {
        $order = new WC_Gateway_Lianlian_Order($order);
        $shipping_args = array();

        $customer = WC()->customer;

        //if ( 'yes' == $this->gateway->get_option( 'send_shipping' ) ) {
        //$shipping_args['address_override'] = $this->gateway->get_option( 'address_override' ) === 'yes' ? 1 : 0;
        //$shipping_args['no_shipping']      = 0;

        // If we are sending shipping, send shipping address instead of billing
        //$shipping_args['first_name']       = $order->shipping_first_name;
        //$shipping_args['last_name']        = $order->shipping_last_name;
        $shipping_args['name'] = $customer->get_shipping_first_name() . $customer->get_shipping_last_name();
        //$shipping_args['company']          = $order->shipping_company;
        $postal_code = $customer->get_shipping_postcode() ? str_replace('-', '', $customer->get_shipping_postcode()) : '';
        $shipping_args['address'] = array(
            'line1' => $customer->get_shipping_address_1(),
            'line2' => $customer->get_shipping_address_2(),
            'district' => $customer->get_shipping_city(),
            'city' => $customer->get_shipping_city(),
            'state' => $customer->get_shipping_state(),
            'country' => $customer->get_shipping_country(),
            'postal_code' => $postal_code,
        );
        $shipping_args['phone'] = $customer->get_billing_phone();
        $shipping_args['cycle'] = 'other';
        //$shipping_args['address1']         = $order->shipping_address_1;
        //$shipping_args['address2']         = $order->shipping_address_2;
        //$shipping_args['city']             = $order->shipping_city;
        //$shipping_args['state']            = $this->get_Lianlian_state( $order->shipping_country, $order->shipping_state );
        //$shipping_args['country']          = $order->shipping_country;
        //$shipping_args['zip']              = $order->shipping_postcode;
        //} else {
        //$shipping_args['no_shipping']      = 1;
        //}

        return $shipping_args;
    }

    protected function get_billing_address_args($order)
    {
        $order = new WC_Gateway_Lianlian_Order($order);
        $customer = WC()->customer;

        $postal_code = $customer->get_shipping_postcode() ? str_replace('-', '', $customer->get_shipping_postcode()) : '';
        return array(
            'line1' => $customer->get_shipping_address_1(),
            'line2' => $customer->get_shipping_address_2(),
            'district' => $customer->get_shipping_city(),
            'city' => $order->get_billing_city(),
            'state' => $order->get_billing_state(),
            'country' => $order->get_billing_country(),
            'postal_code' => $postal_code,
        );;
    }

    protected function get_customer_args($order)
    {
        $customer = WC()->customer;
        $postal_code = $customer->get_shipping_postcode() ? str_replace('-', '', $customer->get_shipping_postcode()) : '';
        return array(
            'customer_type' => 'I',
            'full_name' => $customer->get_shipping_first_name() . ' ' . $customer->get_shipping_last_name(),
            'first_name' => $customer->get_shipping_first_name(),
            'last_name' => $customer->get_shipping_last_name(),
            'email' => $customer->get_billing_email(),
            'address' => array(
                'line1' => $customer->get_shipping_address_1(),
                'line2' => $customer->get_shipping_address_2(),
                'district' => $customer->get_shipping_city(),
                'city' => $customer->get_shipping_city(),
                'state' => $customer->get_shipping_state(),
                'country' => $customer->get_shipping_country(),
                'postal_code' => $postal_code,
            )
        );
    }

    /**
     * Get line item args for Lianlian request
     * @param WC_Order $order
     * @return array
     */
    protected function get_line_item_args($order)
    {
        /**
         * Try passing a line item per product if supported
         */
        if ((!wc_tax_enabled() || !wc_prices_include_tax()) && $this->prepare_line_items($order)) {

            $line_item_args = $this->get_line_items();
            $line_item_args['tax_cart'] = $order->get_total_tax();

            if ($order->get_total_discount() > 0) {
                $line_item_args['discount_amount_cart'] = round($order->get_total_discount(), 2);
            }

            /**
             * Send order as a single item
             *
             * For shipping, we longer use shipping_1 because Lianlian ignores it if *any* shipping rules are within Lianlian, and Lianlian ignores anything over 5 digits (999.99 is the max)
             */
        } else {

            $this->delete_line_items();

            $this->add_line_item($this->get_order_item_names($order), 1, number_format($order->get_total() - round($order->get_total_shipping() + $order->get_shipping_tax(), 2), 2, '.', ''), $order->get_order_number());
            $this->add_line_item(sprintf(__('Shipping via %s', 'woocommerce'), ucwords($order->get_shipping_method())), 1, number_format($order->get_total_shipping() + $order->get_shipping_tax(), 2, '.', ''));

            $line_item_args = $this->get_line_items();
        }

        return $line_item_args;
    }

    /**
     * Get order item names as a string
     * @param WC_Order $order
     * @return string
     */
    protected function get_order_item_names($order)
    {
        $item_names = array();

        foreach ($order->get_items() as $item) {
            $item_names[] = $item['name'] . ' x ' . $item['qty'];
        }

        return implode(', ', $item_names);
    }

    /**
     * Get order item names as a string
     * @param WC_Order $order
     * @param array $item
     * @return string
     */
    protected function get_order_item_name($order, $item)
    {
        $item_name = $item['name'];
        $item_meta = new WC_Order_Item_Meta($item['item_meta']);

        if ($meta = $item_meta->display(true, true)) {
            $item_name .= ' ( ' . $meta . ' )';
        }

        return $item_name;
    }

    /**
     * Return all line items
     */
    protected function get_line_items()
    {
        return $this->line_items;
    }

    /**
     * Remove all line items
     */
    protected function delete_line_items()
    {
        $this->line_items = array();
    }

    /**
     * Get line items to send to Lianlian
     *
     * @param WC_Order $order
     * @return bool
     */
    protected function prepare_line_items($order)
    {
        $order = new WC_Gateway_Lianlian_Order($order);
        $this->delete_line_items();
        $calculated_total = 0;

        // Products
        foreach ($order->get_items(array('line_item', 'fee')) as $item) {
            if ('fee' === $item['type']) {
                $line_item = $this->add_line_item($item['name'], 1, $item['line_total']);
                $calculated_total += $item['line_total'];
            } else {
                $product = $order->get_product_from_item($item);
                $line_item = $this->add_line_item($this->get_order_item_name($order, $item), $item['qty'], $order->get_item_subtotal($item, false), $product->get_sku());
                $calculated_total += $order->get_item_subtotal($item, false) * $item['qty'];
            }

            if (!$line_item) {
                return false;
            }
        }

        // Shipping Cost item - Lianlian only allows shipping per item, we want to send shipping for the order
        if ($order->get_total_shipping() > 0 && !$this->add_line_item(sprintf(__('Shipping via %s', 'woocommerce'), $order->get_shipping_method()), 1, round($order->get_total_shipping(), 2))) {
            return false;
        }

        // Check for mismatched totals
        if (wc_format_decimal($calculated_total + $order->get_total_tax() + round($order->get_total_shipping(), 2) - round($order->get_total_discount(), 2), 2) != wc_format_decimal($order->get_total(), 2)) {
            return false;
        }

        return true;
    }

    /**
     * Add Lianlian Line Item
     * @param string $item_name
     * @param integer $quantity
     * @param integer $amount
     * @param string $item_number
     * @return bool successfully added or not
     */
    protected function add_line_item($item_name, $quantity = 1, $amount = 0, $item_number = '')
    {
        $index = (sizeof($this->line_items) / 4) + 1;

        if (!$item_name || $amount < 0 || $index > 9) {
            return false;
        }

        $this->line_items['item_name_' . $index] = html_entity_decode(wc_trim_string($item_name, 127), ENT_NOQUOTES, 'UTF-8');
        $this->line_items['quantity_' . $index] = $quantity;
        $this->line_items['amount_' . $index] = $amount;
        $this->line_items['item_number_' . $index] = $item_number;

        return true;
    }

    /**
     * Get the state to send to Lianlian
     * @param string $cc
     * @param string $state
     * @return string
     */
    protected function get_Lianlian_state($cc, $state)
    {
        if ('US' === $cc) {
            return $state;
        }

        $states = WC()->countries->get_states($cc);

        if (isset($states[$state])) {
            return $states[$state];
        }

        return $state;
    }
}

?>
