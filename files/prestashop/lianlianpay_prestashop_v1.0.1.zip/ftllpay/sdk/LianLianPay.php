<?php

use Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\RedirectionExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;

include __DIR__ . '/LianLianSign.php';

class LianLianPay
{
    const SANDBOX_ENDPOINT = 'https://celer-api.LianLianpay-inc.com';
    const ENDPOINT = 'https://gpapi.lianlianpay.com';
    const HTTP_GET = 'GET';
    const HTTP_POST = 'POST';

    private $data;
    /**
     * @var false|string 商户号
     */
    private $merchantId;
    /**
     * @var false|string
     */
    private $privateKey;
    /**
     * @var false|string
     */
    private $publicKey;

    public function __construct()
    {
        $this->merchantId = Configuration::get('FTLLPAY_MERCHANT_ID');
        $this->privateKey = Configuration::get('FTLLPAY_PRIVATE_KEY');
        $this->publicKey = Configuration::get('FTLLPAY_PUBLIC_KEY');
    }


    /**
     * 取环境服务器域名
     * @return string
     */
    private function getEndPoint()
    {
        return (bool)Configuration::get('FTLLPAY_ENABLED_SANDBOX') === true ? LianLianPay::SANDBOX_ENDPOINT : LianLianPay::ENDPOINT;
    }

    /**
     * 取iframe初始化token
     * @throws Exception
     */
    public function getToken()
    {
        $url = $this->getEndPoint() . '/v3/merchants/' . $this->merchantId . '/token';
        try {
            $data = ['timestamp' => time(), 'merchant_id' => $this->merchantId];
            $header = array(
                'timestamp: ' . $data['timestamp'],
                'signature: ' . (new LianLianSign())->signForLianlian($data, $this->privateKey)
            );
            return $this->httpRequest($url, $header, $data);
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 清洗数据
     * @param $data
     * @return mixed
     */
    private function getClearData($data)
    {
        foreach ($data as $key => $value) {
            if (empty($value)) {
                unset($data[$key]);
            }
            if (is_array($value)) {
                $data[$key] = $this->getClearData($value);
            }
        }
        return $data;
    }

    /**
     * 开始发起支付
     * @return mixed
     * @throws Exception
     */
    public function pay($params)
    {
        $data = $this->getClearData(array_merge([
            'merchant_id' => $this->merchantId,
            'sub_merchant_id' => trim(Configuration::get('FTLLPAY_SUB_MERCHANT_ID')),
            'country' => Tools::strtoupper(Configuration::get('FTLLPAY_MERCHANT_COUNTRY'))
        ], $this->data));
        $url = $this->getEndPoint() . '/v3/merchants/' . $this->merchantId . '/payments';
        try {
            $header = array(
                'sign-type: ' . 'RSA',
                'timestamp: ' . date("YmdHis", time()),
                'timezone: ' . date_default_timezone_get(),
                'Content-Type: ' . 'application/json',
                'signature: ' . (new LianLianSign())->signForLianlian($data, $this->privateKey)
            );
            return $this->httpRequest($url, $header, $data, self::HTTP_POST);
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    public function queryPay($merchant_transaction_id)
    {
        $url = $this->getEndPoint() . '/v3/merchants/' . $this->merchantId . '/payments/' . $merchant_transaction_id;
        $data = [
            'merchant_id' => $this->merchantId,
            'merchant_transaction_id' => $merchant_transaction_id
        ];
        $header = array(
            'sign-type: ' . 'RSA',
            'timestamp: ' . date("YmdHis", time()),
            'timezone: ' . date_default_timezone_get(),
            'Content-Type: ' . 'application/json',
            'signature: ' . (new LianLianSign())->signForLianlian($data, $this->privateKey)
        );
        try {
            return $this->HttpRequest($url, $header, $data);
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 上传更新快递号
     * @param $merchant_transaction_id
     * @param $shipments
     * @return mixed
     * @throws Exception
     */
    public function updateShipments($merchant_transaction_id, $shipments)
    {
        $url = $this->getEndPoint() . '/v3/merchants/' . $this->merchantId . '/payments/' . $merchant_transaction_id . '/shipments';
        $data = $this->getClearData([
            'merchant_transaction_id' => $merchant_transaction_id,
            'merchant_id' => $this->merchantId,
            'sub_merchant_id' => Configuration::get('FTLLPAY_SUB_MERCHANT_ID'),
            'shipments' => [
                $shipments
            ]
        ]);
        try {
            $header = array(
                'sign-type: ' . 'RSA',
                'timestamp: ' . date("YmdHis", time()),
                'timezone: ' . date_default_timezone_get(),
                'Content-Type: ' . 'application/json',
                'signature: ' . (new LianLianSign())->signForLianlian($data, $this->privateKey)
            );
            return $this->httpRequest($url, $header, $data, self::HTTP_POST);
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @param $url
     * @param $headers
     * @param $request array 需要post的数据
     * @param $method  string 方法
     * @return mixed
     */
    public function HttpRequest($url, $headers, $request, $method = self::HTTP_GET)
    {
        $header_res = [];
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        if ($method === self::HTTP_POST) {
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($request));
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HEADERFUNCTION,
            function ($curl, $header) use (&$header_res) {
                $len = strlen($header);
                $header = explode(':', $header, 2);
                if (count($header) < 2) // ignore invalid headers
                    return $len;

                $header_res[strtolower(trim($header[0]))][] = trim($header[1]);
                return $len;
            }
        );

        $response_data = curl_exec($curl);
        curl_close($curl);
        return json_decode($response_data, true);
    }

    /**
     * 验证异步通知
     * @param $notifyMsg
     * @param $signature
     * @return bool
     */
    public function checkNotify($notifyMsg, $signature)
    {
        $sign_tool = new LianLianSign();
        return $sign_tool->verifySignForLianlian($notifyMsg, $signature, $this->publicKey);
    }

    /**
     * 返回订单的支付状态
     * @param $payment_status
     * @return false|int
     */
    public static function getOrderState($payment_status)
    {
        switch ($payment_status) {
            case 'PS':
                return (int)Configuration::get('PS_OS_PAYMENT');
            case 'PC':
                return (int)Configuration::get('PS_OS_CANCELED');
            case 'WP':
                return (int)Configuration::get('PS_OS_CHEQUE');
            case 'PP':
                return (int)Configuration::get('PS_LLPAY_PROCESS');
            case 'RS':
                return (int)Configuration::get('PS_OS_REFUND');
            case 'PF':
            case 'CB':
                return (int)Configuration::get('PS_OS_ERROR');
        }
        return false;
    }

    public static function getStateNameArray()
    {
        return [
            'IN' => 'Payment Initialize(初始化支付)',
            'WP' => 'Waiting Payment(待用户支付)',
            'PP' => 'Payment Processing(等待支付结果)',
            'PC' => 'Payment Cancel(支付过期或者取消)',
            'PS' => 'Payment Success(支付成功)',
            'PF' => 'Payment Failed(支付失败)',
            'RP' => 'Refund Processing(等待退款结果)',
            'RS' => 'Refund Success(全部退款成功)',
            'PR' => 'Partial Refund(部分退款成功)',
            'CB' => 'Charge Back(争议拒付)',
        ];
    }

    /**
     * 设置账单地址
     * @param int $id_address_invoice
     * @return void
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public function setInvoiceAddress($id_address_invoice)
    {
        $this->data['customer']['address'] = $this->getAddress($id_address_invoice);
        $this->data['payment_data']['card']['billing_address'] = $this->getAddress($id_address_invoice);
    }

    /**
     * 取地址信息
     * @param $id
     * @return array
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    private function getAddress($id)
    {
        $address = new Address($id);
        $state = new State($address->id_state);
        $country = new Country($address->id_country);
        return [
            'line1' => $address->address1,
            'line2' => $address->address2,
            'city' => $address->city,
            'state' => $state->iso_code,
            'country' => $country->iso_code,
            'postal_code' => (int)$address->postcode === 0 ? '123456' : $address->postcode
        ];
    }

    /**
     * 设置商户订单信息
     * @param array $data
     * @return void
     */
    public function setMerchantOrder(array $data)
    {
        $this->data['merchant_transaction_id'] = $data['merchant_order_id'];
        $this->data['merchant_order'] = $data;
    }

    /**
     * 设置商品数据
     * @param array $products
     * @return void
     * @throws PrestaShopException
     */
    public function setProducts($products)
    {
        $tmp = [];
        foreach ($products as $product) {
            $tmp[] = [
                'product_id' => $product['id_product'],
                'name' => Tools::link_rewrite($product['product_name']),
                'price' => $product['product_price_wt'],
                'quantity' => (int)$product['product_quantity'],
                'url' => Context::getContext()->link->getProductLink($product['id_product']),
                'sku' => $product['reference'] ? $product['reference'] : 'default_sku',
                'shipping_provider' => 'Other'
            ];
        }
        $this->data['merchant_order']['products'] = $tmp;
    }

    /**
     * 设置配送方式
     * @param int $id_address_delivery
     * @return void
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public function setShipping($id_address_delivery)
    {
        $delivery = new Address($id_address_delivery);
        $this->data['merchant_order']['shipping'] = [
            'first_name' => $delivery->firstname,
            'last_name' => $delivery->lastname,
            'name' => $delivery->firstname . ' ' . $delivery->lastname,
            'phone' => $delivery->phone_mobile ? $delivery->phone_mobile : $delivery->phone,
            'cycle' => 'other',
            'address' => $this->getAddress($id_address_delivery)
        ];
    }

    /**
     * 设置用户
     * @param int $id_customer
     * @return void
     */
    public function setCustomer($id_customer)
    {
        $customer = new Customer($id_customer);
        $this->data['customer'] = array_merge($this->data['customer'], [
            'customer_type' => 'I',
            'first_name' => $customer->firstname,
            'last_name' => $customer->lastname,
            'full_name' => $customer->firstname . $customer->lastname,
            'email' => $customer->email,
        ]);
        $this->data['payment_data']['card']['holder_name'] = $customer->firstname . $customer->lastname;
    }

    /**
     * 设置支付方式
     * @param string $method
     * @return void
     */
    public function setPaymentMethod($method)
    {
        $this->data['payment_method'] = $method;
    }

    /**
     * 设置请求的card token
     * @param $card_token
     * @return void
     */
    public function setCardToken($card_token)
    {
        $this->data['payment_data']['installments'] = 1;
        $this->data['payment_data']['card']['card_token'] = $card_token;
    }

    /**
     * @param $notify_url
     * @return void
     */
    public function setNotifyUrl($notify_url)
    {
        $this->data['notification_url'] = $notify_url;
    }

    /**
     * @param $redirect_url
     * @return void
     */
    public function setRedirectUrl($redirect_url)
    {
        $this->data['redirect_url'] = $redirect_url;
    }
}