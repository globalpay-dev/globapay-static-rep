let lltoken;
let button;
let buttonContainer;
let isOrderDetail = false;
let llpay_message;

$(document).ready(function () {
    let pay_again_button = document.getElementById('pay_again_button');
    if (pay_again_button === null) {
        //为订单详情页面
        button = document.getElementById('payment-confirmation').getElementsByTagName('button')[0]
        $('input[data-module-name="ftllpay_radio"]').change(function () {
            if (lltoken === undefined) {
                getTokenAjax();
            }
        })
    } else {
        pay_again_button.addEventListener('click', function () {
            pay_again_button.style.display = 'none'
            button = document.getElementById('merchant-button')
            isOrderDetail = true;
            getTokenAjax()
        })
    }
})

function getTokenAjax() {
    llpay_message = document.getElementById('llpay_message');
    $.ajax({
        url: ajax_url,
        data: {
            ajax: true,
            action: 'getToken'
        },
        method: 'post',
        dataType: 'json',
    }).then((json) => {
        if (json.return_code.toLowerCase() === 'success') {
            lltoken = json.order;
            showHtml()
        } else {
            llpay_message.textContent = json.return_message
            llpay_message.classList.add('alert-danger')
            llpay_message.style.display = '';
        }
    })
}

function showHtml() {
    var style = {
        base: {
            backgroundColor: '#f8f8f8',
            bolderColor: '#f1f1f1',
            color: '#bcbcbc',
            fontWeight: '400',
            fontFamily: 'Roboto, Open Sans, Segoe UI, sans-serif',
            fontSize: '14px',
            fontSmoothing: 'antialiased',
            floatLabelSize: '12px',
            floatLabelColor: '#333333',
            floatLabelWeight: '100',
        },
    };
// 初始化收银台
    const elements = LLP.elements();
    const card = elements.create('card', {
        token: lltoken,
        style: style,
        apiType: '',
        merchantUrl: window.location.href,
    });
    card.mount('#llpay-card-element');
    if (isOrderDetail) {
        button.style.display = ''
    }

    const form = document.getElementById('merchant-payment-form');
    button.addEventListener('click', function (ev) {
        ev.preventDefault();
        LLP.getValidateResult().then((res) => {
            if (res && !res.validateResult) {
                $(button).removeClass("disabled").removeAttr('disabled')
            } else {
                LLP.confirmPay().then(function (result) {
                    if (result && result.data) {
                        let card_token = result.data;
                        document.getElementById('llpay_token').value = card_token;
                        sendOrder();
                        //form.submit();
                    }
                });
            }
        });
    });
}

function sendOrder() {
    let id_cart = document.getElementById('llpay_id_cart').getAttribute('value');
    if (id_cart) {
        let llpay_token = $('#llpay_token').val()
        $.ajax({
            url: ajax_url,
            data: {
                ajax: true,
                action: 'sendOrder',
                id_cart: id_cart,
                llpay_token
            },
            method: 'post',
            dataType: 'json',
        }).then((res) => {
            if (res['3ds_status'] === true) {
                $('#llpay_payment_url').attr('href', res.payment_url)
                $('#llpay_payment_url')[0].click()
                // window.open(res.payment_url)
            } else {
                if (res.payment_url) {
                    llpay_message.textContent = res.message
                    llpay_message.classList.add('alert-success')
                    llpay_message.classList.remove('alert-danger')
                    llpay_message.style.display = '';
                    window.location.href = res.payment_url
                } else {
                    llpay_message.innerText = res.message;
                    llpay_message.classList.remove('alert-success')
                    llpay_message.classList.add('alert-danger')
                    llpay_message.style.display = '';
                }
            }
        })
        $(button).removeClass("disabled").removeAttr('disabled')
    } else {
        llpay_message.textContent = 'Can not pay it'
        llpay_message.classList.remove('alert-success')
        llpay_message.classList.add('alert-danger')
        llpay_message.style.display = '';
    }
}

