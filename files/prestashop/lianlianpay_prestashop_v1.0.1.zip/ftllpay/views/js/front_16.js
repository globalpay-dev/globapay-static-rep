let lltoken;
let llpay_message;

$(document).on('click', '#ftllpay_payment_area', function () {
    if (lltoken === undefined) {
        getTokenAjax()
    }
})

function getTokenAjax() {
    $.ajax({
        url: ajax_url,
        data: {
            ajax: true,
            action: 'getToken'
        },
        method: 'post',
        dataType: 'json',
    }).then((json) => {
        llpay_message = document.getElementById('llpay_message');
        if (json.return_code.toLowerCase() === 'success') {
            lltoken = json.order;
            showHtml()
        } else {
            llpay_message.textContent = json.return_message
            llpay_message.classList.add('alert-danger')
            llpay_message.style.display = '';
        }
    })
}

function showHtml() {
    var style = {
        base: {
            backgroundColor: '#f8f8f8',
            bolderColor: '#f1f1f1',
            color: '#bcbcbc',
            fontWeight: '400',
            fontFamily: 'Roboto, Open Sans, Segoe UI, sans-serif',
            fontSize: '14px',
            fontSmoothing: 'antialiased',
            floatLabelSize: '12px',
            floatLabelColor: '#333333',
            floatLabelWeight: '100',
        },
    };
// 初始化收银台
    const elements = LLP.elements();
    const card = elements.create('card', {
        token: lltoken,
        style: style,
        apiType: '',
        merchantUrl: window.location.href,
    });
    card.mount('#llpay-card-element');
    let pay_again_button = document.getElementById('pay_again_button');
    if (pay_again_button !== null) {
        pay_again_button.style.display = 'none'
    }

    $('#merchant-button').removeClass('hidden')
    const form = document.getElementById('merchant-payment-form');
    const getCardTokenButton = document.getElementById('merchant-button');
    getCardTokenButton.addEventListener('click', function (ev) {
        ev.preventDefault();
        LLP.getValidateResult().then((res) => {
            if (res && !res.validateResult) {

            } else {
                LLP.confirmPay().then(function (result) {
                    if (result && result.data) {
                        let card_token = result.data;
                        document.getElementById('llpay_token').value = card_token;
                        //form.submit();
                        sendOrder()
                    }
                });
            }
        });
    });
}

function sendOrder() {
    let id_cart = document.getElementById('llpay_id_cart').getAttribute('value');
    if (id_cart) {
        let llpay_token = $('#llpay_token').val()
        $.ajax({
            url: ajax_url,
            data: {
                ajax: true,
                action: 'sendOrder',
                id_cart: id_cart,
                llpay_token
            },
            method: 'post',
            dataType: 'json',
        }).then((res) => {
            if (res['3ds_status'] === true) {
                $('#llpay_payment_url').attr('href', res.payment_url)
                $('#llpay_payment_url')[0].click()
                //window.location.href = res.payment_url
            } else {
                if (res.payment_url) {
                    llpay_message.textContent = res.message
                    llpay_message.classList.add('alert-success')
                    llpay_message.classList.remove('alert-danger')
                    llpay_message.style.display = '';
                    window.location.href = res.payment_url
                } else {
                    llpay_message.innerText = res.message;
                    llpay_message.classList.remove('alert-success')
                    llpay_message.classList.add('alert-danger')
                    llpay_message.style.display = '';
                }
            }
        })
    } else {
        llpay_message.textContent = 'Can not pay it'
        llpay_message.classList.remove('alert-success')
        llpay_message.classList.add('alert-danger')
        llpay_message.style.display = '';
    }
}