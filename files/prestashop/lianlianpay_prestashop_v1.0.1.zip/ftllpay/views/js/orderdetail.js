function getTokenAjax() {
    $.ajax({
        url: ajax_url,
        data: {
            ajax: true,
            action: 'getToken'
        },
        method: 'post',
        dataType: 'json',
    }).then((json) => {
        if (json.return_code.toLowerCase() === 'success') {
            lltoken = json.order;
            showHtml()
        } else {
            alert(json.return_message)
        }
    })
}

function showHtml() {
    var style = {
        base: {
            backgroundColor: '#f8f8f8',
            bolderColor: '#f1f1f1',
            color: '#bcbcbc',
            fontWeight: '400',
            fontFamily: 'Roboto, Open Sans, Segoe UI, sans-serif',
            fontSize: '14px',
            fontSmoothing: 'antialiased',
            floatLabelSize: '12px',
            floatLabelColor: '#333333',
            floatLabelWeight: '100',
        },
    };
// 初始化收银台
    const elements = LLP.elements();
    const card = elements.create('card', {
        token: lltoken,
        style: style,
        apiType: '',
        merchantUrl: window.location.href,
    });
    card.mount('#llpay-card-element');

    const form = document.getElementById('merchant-payment-form');
    const getCardTokenButton = $('#payment-confirmation button[type=submit]')[0];
    getCardTokenButton.addEventListener('click', function (ev) {
        ev.preventDefault();
        LLP.getValidateResult().then((res) => {
            if (res && !res.validateResult) {
                $(button).removeClass("disabled").removeAttr('disabled')
            } else {
                LLP.confirmPay().then(function (result) {
                    if (result && result.data) {
                        let card_token = result.data;
                        document.getElementById('llpay_token').value = card_token;
                        sendOrder();
                        //form.submit();
                    }
                });
            }
        });
    });
}

function sendOrder() {
    let llpay_token = $('#llpay_token').val()
    $.ajax({
        url: ajax_url,
        data: {
            ajax: true,
            action: 'sendOrder',
            id_cart: id_cart,
            llpay_token
        },
        method: 'post',
        dataType: 'json',
    }).then((res) => {
        if (res['3ds_status'] === true) {
            $('#llpay_payment_url').attr('href', res.payment_url)
            $('#llpay_payment_url')[0].click()
            // window.open(res.payment_url)
        } else {
            if (res.payment_url) {
                $('#llpay_message').text(res.message).attr('class', 'alert alert-success')
                window.location.href = res.payment_url
            } else {
                $('#llpay_message').text(res.message).attr('class', 'alert alert-danger')
            }
            //window.location.href = res.payment_url
            console.log(res)
        }
    })
    $(button).removeClass("disabled").removeAttr('disabled')
}