<?php

class LianLianPayClass
{
    /**
     * @param $transaction_id
     * @param $reference
     * @return array|bool|object|null
     */
    public static function getPaymentByTransactionId($transaction_id, $reference)
    {
        $query = new DbQuery();
        $query->select('*')
            ->from('order_payment')
            ->where('transaction_id=\'' . pSQL($transaction_id) . '\' AND order_reference=\'' . pSQL($reference) . '\'');
        return Db::getInstance()->getRow($query);
    }
}