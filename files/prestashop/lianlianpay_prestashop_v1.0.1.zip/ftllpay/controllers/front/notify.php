<?php

class FtllpayNotifyModuleFrontController extends ModuleFrontController
{
    public function postProcess()
    {
        $notify_body = file_get_contents("php://input");
        $signature = $_SERVER['HTTP_SIGNATURE'];
        $notify_body = preg_replace('/:\s*([0-9]*\.?[0-9]+)/', ': "$1"', $notify_body);
        $notifyMsg = json_decode($notify_body, true);
        if (empty($signature)) {
            //没有签名
            die(json_encode(['code' => 401, 'msg' => 'not find signature']));
        } else {
            $sdk = new LianLianPay();
            $check_result = $sdk->checkNotify($notifyMsg, $signature);
            if (!$check_result) {
                //验签失败
                die(json_encode(['code' => 401, 'msg' => 'check notify failed']));
            } else {
                if (isset($notifyMsg['payment_data']) && isset($notifyMsg['payment_data']['payment_status'])) {
                    //返回有状态
                    $payment_status = $notifyMsg['payment_data']['payment_status'];
                    $state = LianLianPay::getOrderState($payment_status);
                    if ($state) {
                        $out_num = explode('_', $notifyMsg['merchant_transaction_id']);
                        $order = new Order($out_num[1]);
                        if ((int)$order->getCurrentState() !== (int)$state) {
                            $this->module->changeOrderState(
                                $order,
                                $state,
                                $notifyMsg['payment_data']['payment_amount'],
                                $notifyMsg['ll_transaction_id']
                            );
                            die(json_encode(['code' => 200, 'msg' => 'success']));
                        }
                    } else {
                        die(json_encode(['code' => 400, 'msg' => 'check notify failed']));
                    }
                } elseif (isset($notifyMsg['refund_data']) && isset($notifyMsg['refund_data']['refund_status'])) {
                    //退款状态
                    $refund_status = $notifyMsg['refund_data']['refund_status'];
                    if ($refund_status === 'PS') {
                        $out_num = explode('_', $notifyMsg['merchant_transaction_id']);
                        $order = new Order($out_num[1]);
                        if ((int)$order->getCurrentState() !== (int)Configuration::get('PS_OS_REFUND')) {
                            $this->module->changeOrderState(
                                $order,
                                (int)Configuration::get('PS_OS_REFUND'),
                                $notifyMsg['payment_data']['payment_amount']
                            );
                            die(json_encode(['code' => 200, 'msg' => 'success']));
                        }
                    }
                    die(json_encode(['code' => 400, 'msg' => 'check notify failed']));
                }
            }
        }
        die();
    }
}