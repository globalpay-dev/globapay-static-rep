<?php

/**
 * 2007-2022 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2022 PrestaShop SA
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */
class FtllpayValidationModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        $this->setTemplate('module:ftllpay/views/templates/front/validation.tpl');
    }

    /**
     * This class should be use by your Instant Payment
     * Notification system to validate the order remotely
     */
    public function postProcess()
    {
        if (Tools::getIsset('ajax')) {
            switch (Tools::getValue('action')) {
                case 'getToken':
                    $this->getToken();
                    break;
                case 'sendOrder':
                    $this->sendOrder();
                    break;
            }
        }
        if ($this->module->active == false) {
            die;
        }
        if (!($this->module instanceof Ftllpay)) {
            Tools::redirect('index.php?controller=order&step=1');

            return;
        }
    }

    public function sendOrder()
    {
        $id_cart = Tools::getValue('id_cart');
        if (version_compare(_PS_VERSION_, '1.7.0.0', '>=')) {
            $id_order = Order::getIdByCartId($id_cart);
        } else {
            $id_order = Order::getOrderByCartId($id_cart);
        }
        if ($id_order) {
            $order = new Order($id_order);
        } else {
            $cart = new Cart($id_cart);
            if (!$cart->id || count($cart->getProducts()) === 0) {
                Tools::redirect('index.php?controller=order&step=1');
            }

            if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
                Tools::redirect('index.php?controller=order&step=1');

                return;
            }
            // Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
            $authorized = false;
            foreach (Module::getPaymentModules() as $module) {
                if ($module['name'] == 'ftllpay') {
                    $authorized = true;
                    break;
                }
            }
            if (!$authorized) {
                die($this->module->l('This payment method is not available.'));
            }
            $customer = $this->context->customer;

            if (!Validate::isLoadedObject($customer)) {
                Tools::redirect('index.php?controller=order&step=1');
                return;
            }

            $currency = $this->context->currency;
            $total = (float)$cart->getOrderTotal(true, Cart::BOTH);

            if ($this->module->validateOrder(
                (int)$cart->id,
                (int)Configuration::get('PS_OS_CHEQUE'),
                $total,
                'Credit/Debit Card',
                null,
                [],
                (int)$currency->id,
                false,
                $customer->secure_key
            )) {
                if (version_compare(_PS_VERSION_, '1.7.0.0', '>')) {
                    $order = Order::getByCartId($cart->id);
                } else {
                    $order = new Order(OrderCore::getOrderByCartId($cart->id));
                }
            }
        }
        $this->apiPay($order);
    }

    /**
     * @param $order Order
     * @return void
     * @throws PrestaShopException
     */
    private function apiPay($order)
    {
        $detailUrl = $this->context->link->getModuleLink($this->module->name, 'redirect', ['id_order' => $order->id]);
        $sdk = new LianLianPay();
        $sdk->setNotifyUrl($this->context->link->getModuleLink('ftllpay', 'notify'));
        $sdk->setRedirectUrl($detailUrl);
        $sdk->setMerchantOrder([
            'merchant_order_id' => $order->reference . '_' . $order->id,
            'merchant_order_time' => date('YmdHis', strtotime($order->date_add)),
            'order_amount' => Tools::ps_round($order->total_paid_tax_incl, 2),
            'order_currency_code' => Configuration::get('FTLLPAY_ENABLED_SANDBOX') ? 'USD' : $this->context->currency->iso_code,
        ]);
        $sdk->setProducts($order->getProducts());
        $sdk->setShipping($order->id_address_delivery);
        $sdk->setInvoiceAddress($order->id_address_invoice);
        $sdk->setCustomer($order->id_customer);
        $sdk->setPaymentMethod('inter_credit_card');
        $sdk->setCardToken(Tools::getValue('llpay_token'));
        $response = $sdk->pay('id_module=' . $this->module->id . '&id_order=' . $order->id);
        if (Tools::strtolower($response['return_code']) === 'success') {
            if (isset($response['order']['3ds_status']) && isset($response['order']['payment_url'])) {
                //需要3ds认证
                die(json_encode(['3ds_status' => true, 'payment_url' => $response['order']['payment_url']]));
            } else {
                $states = LianLianPay::getStateNameArray();
                $state = $response['order']['payment_data']['payment_status'];
                if (in_array($state, ['PC', 'PS', 'PP'])) {
                    //这三个状态可以跳转到订单列表
                    die(json_encode(['message' => $states[$state], 'payment_url' => $detailUrl]));
                } else {
                    die(json_encode(['message' => $states[$state]]));
                }
            }
        } else {
            PrestaShopLogger::addLog($response['return_message'], 1, null, 'Lian Lian', $order->id);
            die(json_encode(['message' => $response['return_message']]));
        }
    }

    /**
     * @return void
     */
    private function getToken()
    {
        $sdk = new LianLianPay();
        try {
            $token = $sdk->getToken();
            if (Tools::strtolower($token['return_code']) !== 'success') {
                PrestaShopLogger::addLog(
                    $token['return_message'] . '-' . $token['trace_id'] . ' Lian Lian pay'
                );
            }
        } catch (Exception $e) {
            $token['return_code'] = 'failed';
            $token['return_message'] = $this->module->l('net work error');
        }
        die(json_encode($token));
    }
}
