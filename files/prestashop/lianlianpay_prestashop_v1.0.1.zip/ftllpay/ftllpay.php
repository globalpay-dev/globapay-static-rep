<?php
/**
 * 2007-2022 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2022 PrestaShop SA
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

/*
 支付成功
不走3DS，直接返回成功
4200000000000000

不走3DS，第一步返回进行中，通过pay_query返回成功
5250548692069390

走3DS1.0
4711100000000000
走3DS2.0无感模式
4066330000000004
走3DS2.0挑战模式
4938730000000001
支付失败

不走3DS
5424184049821670
走3DS1.0
5487971631330522
走3DS2.0挑战模式
5512459816707531
 */
if (!defined('_PS_VERSION_')) {
    exit;
}
include __DIR__ . '/sdk/LianLianPay.php';
include __DIR__ . '/classes/LianLianPayClass.php';

class Ftllpay extends PaymentModule
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'ftllpay';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->author = 'feitu';
        $this->need_instance = 0;

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Credit/Debit Card');
        $this->description = $this->l('连连国际是连连数字旗下子品牌。连连数字成立于2009年，目前已在中国、中国香港、美国、英国、新加坡、泰国、巴西等国家和地区获得了60余张支付类牌照及相关资质。连连全球收单是连连国际推出的跨境收单服务，专注为跨境商户连接全球主流支付方式，让出海支付更简单。');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        $this->currencies = true;
        $this->currencies_mode = 'checkbox';
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        if (extension_loaded('curl') == false) {
            $this->_errors[] = $this->l('You have to enable the cURL extension on your server to install this module');
            return false;
        }

        return parent::install() &&
            $this->registerHook('header') &&
            $this->registerHook('payment') &&
            $this->registerHook('actionAdminOrdersTrackingNumberUpdate') &&
            $this->registerHook('paymentReturn') &&
            $this->registerHook('displayOrderDetail') &&
            $this->registerHook('paymentOptions') &&
            $this->installOrderStatus();
    }

    protected function installOrderStatus()
    {
        if ((bool)Configuration::get('PS_LLPAY_PROCESS') == false) {
            $order_status = new OrderState();
            $order_status->module_name = $this->name;
            $order_status->invoice = false;
            $order_status->paid = true;
            $order_status->send_email = false;
            $order_status->color = '#4169E1';
            $order_status->unremovable = true;
            $order_status->hidden = false;
            $order_status->logable = false;
            $order_status->delivery = false;
            $order_status->shipped = false;
            $order_status->pdf_invoice = false;
            $order_status->pdf_delivery = false;
            foreach (Language::getLanguages() as $lang) {
                $order_status->name[$lang['id_lang']] = 'Payment Processing';
            }
            try {
                $order_status->save();
                Tools::copy(__DIR__ . '/logo.gif', _PS_TMP_IMG_DIR_ . $order_status->id . '.gif');
                Tools::copy(__DIR__ . '/logo.gif', _PS_ORDER_STATE_IMG_DIR_ . $order_status->id . '.gif');
                return Configuration::updateValue('PS_LLPAY_PROCESS', $order_status->id);
            } catch (Exception $e) {
                PrestaShopLogger::addLog($e->getMessage(), 1, null, 'ftllpay');
                return false;
            }
        }

        return true;
    }

    public function uninstall()
    {
        return parent::uninstall();
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        /**
         * If values have been submitted in the form, process.
         */
        if (((bool)Tools::isSubmit('submitFtllpayModule')) == true) {
            $this->postProcess();
        }

        $this->context->smarty->assign('module_dir', $this->_path);

//        $output = $this->context->smarty->fetch($this->local_path . 'views/templates/admin/configure.tpl');

        return $this->renderForm();
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitFtllpayModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        $country = json_decode(file_get_contents(__DIR__ . '/country.json'), true);
        array_unshift($country, ['code' => '', 'name' => $this->l('---Select---')]);
        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon - cogs',
                ),
                'input' => array(
                    array(
                        'type' => 'switch',
                        'label' => $this->l('沙盒模式'),
                        'name' => 'FTLLPAY_ENABLED_SANDBOX',
                        'is_bool' => true,
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => true,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => false,
                                'label' => $this->l('Disabled')
                            )
                        ),
                        'desc' => $this->l('正式使用时请关闭')
                    ),
                    array(
                        'col' => 3,
                        'type' => 'text',
                        'name' => 'FTLLPAY_MERCHANT_ID',
                        'required' => 'true',
                        'label' => $this->l('商户号'),
                        'desc' => $this->l('打开LianLian Pay商家后端，点击“我的信息”菜单中的“商户信息”页面，复制“商户编号”，粘贴在此设置项中。')
                    ),
                    array(
                        'col' => 3,
                        'type' => 'text',
                        'name' => 'FTLLPAY_SUB_MERCHANT_ID',
                        'label' => $this->l('子商户号'),
                        'desc' => $this->l('子商户号,如果没有请留空'),
                    ),
                    array(
                        'col' => 3,
                        'type' => 'select',
                        'class' => 'chosen',
                        'name' => 'FTLLPAY_MERCHANT_COUNTRY',
                        'label' => $this->l('商户收单国家'),
                        'required' => 'true',
                        'options' => array(
                            'query' => $country,
                            'id' => 'code',
                            'name' => 'name'
                        ),
                        'desc' => $this->l('收单国家,如不确定，请与客户经理确认')
                    ),
                    array(
                        'type' => 'textarea',
                        'name' => 'FTLLPAY_PRIVATE_KEY',
                        'required' => 'true',
                        'label' => $this->l('商户私钥'),
                        'desc' => $this->l('打开LianLian Pay商家后端，点击“商户服务”菜单中的“秘钥”页面，复制“商户公钥”，然后参照此文档介绍生成Private key：https://doc.lianlianpay.com/pay-guide/flow-step/lianlian-key-config')
                    ),
                    array(
                        'type' => 'textarea',
                        'name' => 'FTLLPAY_PUBLIC_KEY',
                        'required' => 'true',
                        'label' => $this->l('LianLianpay公钥'),
                        'desc' => $this->l('打开LianLian Pay商家后端，点击“商户服务”菜单中的“秘钥”页面，复制“LianLianPay公钥”，粘贴在此设置项中。')
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return array(
            'FTLLPAY_ENABLED_SANDBOX' => Configuration::get('FTLLPAY_ENABLED_SANDBOX'),
            'FTLLPAY_MERCHANT_ID' => Configuration::get('FTLLPAY_MERCHANT_ID'),
            'FTLLPAY_SUB_MERCHANT_ID' => Configuration::get('FTLLPAY_SUB_MERCHANT_ID'),
            'FTLLPAY_MERCHANT_COUNTRY' => Configuration::get('FTLLPAY_MERCHANT_COUNTRY'),
            'FTLLPAY_PRIVATE_KEY' => Configuration::get('FTLLPAY_PRIVATE_KEY'),
            'FTLLPAY_PUBLIC_KEY' => Configuration::get('FTLLPAY_PUBLIC_KEY'),
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            if (in_array($key, ['FTLLPAY_PRIVATE_KEY', 'FTLLPAY_PUBLIC_KEY'])) {
                Configuration::updateValue($key, $this->clearKeyString(Tools::getValue($key)));
            } else {
                Configuration::updateValue($key, trim(Tools::getValue($key)));
            }
        }
    }

    private function clearKeyString($string)
    {
        $str = preg_replace('/\s/', '', $string);
        $str = preg_replace('/-{1,5}[A-Z]*-{1,5}/', '', $str);
        return $str;
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookHeader()
    {
        if (in_array(Tools::getValue('controller'), ['order', 'orderopc', 'orderdetail'])) {
            Media::addJsDef([
                'ajax_url' => $this->context->link->getModuleLink($this->name, 'validation'),
                'id_cart' => $this->context->cart->id
            ]);
            if (version_compare(_PS_VERSION_, '1.7.0.0', '>=')) {
                if ((bool)Configuration::get('FTLLPAY_ENABLED_SANDBOX') === true) {
                    $this->context->controller->registerJavascript('llpay_js', $this->_path . 'views/js/llpay-dev.min.js');
                } else {
                    $this->context->controller->registerJavascript('llpay_js', $this->_path . 'views/js/llpay.min.js');
                }
                $this->context->controller->addJS($this->_path . 'views/js/front.js');
            } else {
                if ((bool)Configuration::get('FTLLPAY_ENABLED_SANDBOX') === true) {
                    $this->context->controller->addJS($this->_path . 'views/js/llpay-dev.min.js');
                } else {
                    $this->context->controller->addJS($this->_path . 'views/js/llpay.min.js');
                }
                $this->context->controller->addJS($this->_path . 'views/js/front_16.js');
            }
        }
        $this->context->controller->addCss($this->_path . 'views/css/front.css');
    }

    /**
     * This method is used to render the payment button,
     * Take care if the button should be displayed or not.
     */
    public function hookPayment($params)
    {
        if (!$this->active && !$this->checkRequired()) {
            return;
        }
        if (!$this->checkCurrency($params['cart'])) {
            return;
        }
        $this->smarty->assign('id_cart', $this->context->cart->id);

        return $this->display(__FILE__, 'views/templates/hook/payment.tpl');
    }

    /**
     * This hook is used to display the order confirmation page.
     */
    public function hookPaymentReturn($params)
    {
        if ($this->active == false)
            return;
        /* @var $order OrderCore */
        if (version_compare(_PS_VERSION_, '1.7.0.0', '>=')) {
            $order = $params['order'];
        } else {
            $order = $params['objOrder'];
        }

        if ($order->getCurrentOrderState()->id != Configuration::get('PS_OS_ERROR'))
            $this->smarty->assign('status', 'ok');
        $this->smarty->assign(array(
            'id_order' => $order->id,
            'reference' => $order->reference,
            'params' => $params,
            'products' => $order->getProducts(),
            'order' => $order,
            'total' => Tools::displayPrice($order->total_paid_real, new Currency($order->id_currency), false),
        ));
        if (version_compare(_PS_VERSION_, '1.7.0.0', '<')) {
            return $this->display(__FILE__, 'views/templates/hook/confirmation_16.tpl');
        }
    }

    /**
     * Return payment options available for PS 1.7+
     *
     * @param array Hook parameters
     *
     * @return array|null
     */
    public function hookPaymentOptions($params)
    {
        if (!$this->active && !$this->checkRequired()) {
            return;
        }
        if (!$this->checkCurrency($params['cart'])) {
            return;
        }
        $option = new \PrestaShop\PrestaShop\Core\Payment\PaymentOption();
        $option->setCallToActionText($this->l('Credit/Debit Card'))
            ->setForm($this->generateForm())
            ->setModuleName('ftllpay_radio');
        return [
            $option
        ];
    }

    private function checkRequired()
    {
        return Configuration::get('FTLLPAY_MERCHANT_ID') &&
            Configuration::get('FTLLPAY_MERCHANT_COUNTRY') &&
            Configuration::get('FTLLPAY_PRIVATE_KEY') &&
            Configuration::get('FTLLPAY_PUBLIC_KEY');
    }

    protected function generateForm()
    {
        $this->context->smarty->assign([
            'id_cart' => $this->context->cart->id
        ]);
        return $this->context->smarty->fetch('module:ftllpay/views/templates/front/payment_form.tpl');
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);
        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @param $order Order
     * @param $state
     * @param $ll_transaction_id
     * @param $amount
     * @return void
     * @throws PrestaShopException
     */
    public function changeOrderState($order, $state, $amount, $ll_transaction_id = false)
    {
        $order->current_state = $state;
        if ((int)$state === (int)Configuration::get('PS_OS_PAYMENT')) {
            $order->total_paid_real = $amount;
        }
        $order->save();
        $history = new OrderHistory();
        $history->id_order = $order->id;
        $history->id_order_state = $state;
        $history->add();

        if ($ll_transaction_id &&
            !LianLianPayClass::getPaymentByTransactionId($ll_transaction_id, $order->reference)) {
            $orderPayment = new OrderPayment();
            $orderPayment->order_reference = $order->reference;
            $orderPayment->id_currency = $order->id_currency;
            $orderPayment->payment_method = 'Credit/Debit Card';
            $orderPayment->transaction_id = $ll_transaction_id;
            $currency = new Currency($order->id_currency);
            $orderPayment->amount = $amount;
            $orderPayment->conversion_rate = $currency->conversion_rate;
            $orderPayment->save();
        }
    }

    /**
     * 上传更新
     * @param $params
     * @return void
     */
    public function hookActionAdminOrdersTrackingNumberUpdate($params)
    {
        /* @var $order Order */
        $order = $params['order'];
        if ($order->module == 'ftllpay') {
            $sdk = new LianLianPay();
            if (version_compare(_PS_VERSION_, '1.7.0.0', '>=')) {
                $orderCarrier = Tools::getAllValues();
                $tracking_no = $orderCarrier['update_order_shipping']['tracking_number'];
            } else {
                $orderCarrier = $_POST;
                $tracking_no = $orderCarrier['tracking_number'];
            }
            try {
                $sdk->updateShipments($order->reference . '_' . $order->id, [
                    'carrier_code' => 'Other',
                    'tracking_no' => $tracking_no
                ]);
            } catch (Exception $e) {
                PrestaShopLogger::addLog($e->getMessage(), 1, null, 'Lian Lian', $order->id);
            }
        }
    }

    public function hookDisplayOrderDetail($params)
    {
        /* @var $order Order */
        $order = $params['order'];
        $this->_clearCache('module:ftllpay/views/templates/front/payment_form.tpl', $this->getCacheId('llpay_order_detail'));
        if (!$order->hasBeenPaid()) {
            $this->context->smarty->assign([
                'order_detail' => true,
                'id_cart' => $order->id_cart
            ]);
            if (version_compare(_PS_VERSION_, '1.7.0.0', '>=')) {
                return $this->context->smarty->fetch('module:ftllpay/views/templates/front/payment_form.tpl', $this->getCacheId('llpay_order_detail'));
            } else {
                return $this->display(__FILE__, 'views/templates/hook/payment.tpl', $this->getCacheId('llpay_order_detail'));
            }
        }
    }

}
